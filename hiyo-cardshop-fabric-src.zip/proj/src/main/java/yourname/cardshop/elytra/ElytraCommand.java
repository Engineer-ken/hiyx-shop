package yourname.cardshop.elytra;

import java.util.List;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import yourname.cardshop.util.Cmd;
import yourname.cardshop.util.Sender;

public class ElytraCommand implements Cmd {
    private final ElytraManager em;
    public ElytraCommand(ElytraManager em) { this.em = em; }

    @Override
    public boolean run(Sender s, String[] args) {
        if (!s.isPlayer()) { s.msg("§cプレイヤーのみ実行できます。"); return true; }
        ServerPlayer p = s.player();
        ItemStack hand = p.getMainHandItem();
        if (!hand.is(Items.ELYTRA)) { s.msg("§cエリトラを手に持って実行してください。"); return true; }
        s.msg(em.register(p, hand) ? "§aこのエリトラをあなた名義で登録しました。" : "§c登録に失敗しました。");
        return true;
    }

    @Override
    public List<String> tab(Sender s, String[] a) { return List.of(); }
}
