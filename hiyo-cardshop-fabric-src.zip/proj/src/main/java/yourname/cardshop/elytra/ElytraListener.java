package yourname.cardshop.elytra;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.util.Mc;

/** エリトラ飛行の開始チェックと距離課税(イベントの代わりに、飛行中のプレイヤーだけを毎tick見る)。 */
public class ElytraListener {
    private final ElytraManager em;
    private final CardManager cm;
    private final Map<UUID, Track> tracks = new HashMap<>();

    private static final class Track { Object level; double x, z; }

    public ElytraListener(ElytraManager em, CardManager cm) { this.em = em; this.cm = cm; }

    public void tick(ServerPlayer p) {
        UUID id = p.getUUID();
        if (!p.isFallFlying()) { if (!tracks.isEmpty()) tracks.remove(id); return; }
        Track t = tracks.get(id);
        if (t == null) {
            // 飛行開始: 登録済みか / 飛行税分の残高があるか
            if (!em.isRegistered(p.getItemBySlot(EquipmentSlot.CHEST))) {
                p.stopFallFlying();
                Mc.msg(p, "§cこのエリトラは登録されていません。/elytra register で登録してください。");
                return;
            }
            double tax = CardShopMod.cfg().getDouble("elytra-tax-amount", 780.0);
            if (cm.getBalance(id) < tax) {
                p.stopFallFlying();
                Mc.msg(p, "§c飛行税(" + tax + "円)分の残高が無いため飛行できません。");
                return;
            }
            t = new Track();
            t.level = p.level(); t.x = p.getX(); t.z = p.getZ();
            tracks.put(id, t);
            return;
        }
        if (t.level != p.level()) { t.level = p.level(); t.x = p.getX(); t.z = p.getZ(); return; }
        double dx = p.getX() - t.x, dz = p.getZ() - t.z;
        t.x = p.getX(); t.z = p.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        if (horizontal <= 0.0) return;
        em.accumulate(p, horizontal);
        if (p.isFallFlying() && cm.getBalance(id) <= 0.0) {
            p.stopFallFlying();
            Mc.msg(p, "§c残高が尽きたため強制着地しました。");
        }
    }

    public void forget(UUID id) { tracks.remove(id); }
}
