package yourname.cardshop.elytra;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.bank.CentralBank;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.util.Mc;

public class ElytraManager {
    private static final String K_OWNER = "elytra_owner";
    private final CardManager cardManager;
    private final CentralBank centralBank;
    private final Map<UUID, Double> pendingDistance = new HashMap<>();

    public ElytraManager(CardManager cardManager, CentralBank centralBank) { this.cardManager = cardManager; this.centralBank = centralBank; }

    public boolean isRegistered(ItemStack e) {
        if (e == null || e.isEmpty()) return false;
        return Mc.tagGet(e, K_OWNER) != null || Mc.legacyString(e, K_OWNER) != null;
    }
    public UUID getOwner(ItemStack e) {
        if (!isRegistered(e)) return null;
        String raw = Mc.tagGet(e, K_OWNER);
        if (raw == null) raw = Mc.legacyString(e, K_OWNER);
        try { return UUID.fromString(raw); } catch (Exception ex) { return null; }
    }
    public boolean register(ServerPlayer p, ItemStack e) {
        if (e == null || e.isEmpty()) return false;
        Mc.tagSet(e, K_OWNER, p.getUUID().toString());
        return true;
    }

    public void accumulate(ServerPlayer p, double horizontal) {
        double per = CardShopMod.cfg().getDouble("elytra-tax-distance", 1000.0);
        double tax = CardShopMod.cfg().getDouble("elytra-tax-amount", 780.0);
        double total = pendingDistance.getOrDefault(p.getUUID(), 0.0) + horizontal;
        while (total >= per) {
            if (cardManager.removeBalance(p.getUUID(), tax)) {
                centralBank.absorb(tax);
                Mc.msg(p, "§7飛行税として " + tax + "円 が引き落とされました。");
                total -= per;
                continue;
            }
            Mc.msg(p, "§c飛行税の残高が不足しています。着陸してください。");
            p.stopFallFlying();
            break;
        }
        pendingDistance.put(p.getUUID(), total);
    }
    public void resetDistance(ServerPlayer p) { pendingDistance.remove(p.getUUID()); }
}
