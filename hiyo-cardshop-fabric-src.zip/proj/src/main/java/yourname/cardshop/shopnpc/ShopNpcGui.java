package yourname.cardshop.shopnpc;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.util.Gui;
import yourname.cardshop.util.Mc;

/** 店NPCのGUI。クリック=1個 / Shift+クリック=1スタック(購入)・まとめて(売却)。 */
public class ShopNpcGui {
    private final ShopNpcManager shopNpcManager;
    private final CardManager cardManager;

    public ShopNpcGui(ShopNpcManager shopNpcManager, CardManager cardManager) {
        this.shopNpcManager = shopNpcManager;
        this.cardManager = cardManager;
    }

    public void open(ServerPlayer player, UUID npcId) {
        ShopNpc npc = shopNpcManager.get(npcId);
        if (npc == null) { Mc.msg(player, "§cこのNPCは店を開いていません。"); return; }
        String title = trim(Mc.nameOf(npc.getFounder()) + " の店", 32);
        Gui.open(player, title, 6, g -> fill(g, npcId));
    }

    private void fill(Gui g, UUID npcId) {
        ShopNpc npc = shopNpcManager.get(npcId);
        if (npc == null) return;
        int n = 0;
        for (ShopNpc.StockEntry e : npc.getEntries()) {
            if (e.getPrice() == null || e.getAmount() <= 0) continue;
            if (n >= 27) break;
            ItemStack s = e.getTemplate().copyWithCount(1);
            Mc.addLore(s, List.of("", "§7単価: §a" + fmt(e.getPrice()) + "円", "§7在庫: §f" + e.getAmount(),
                    "§eクリック=1個 §7/ §eShift+クリック=1スタック購入"));
            final UUID eid = e.getId();
            g.set(n++, s, (p, right, shift) -> {
                ShopNpc cur = shopNpcManager.get(npcId);
                if (cur == null) return;
                ShopNpc.StockEntry se = cur.getEntryById(eid);
                if (se == null) Mc.msg(p, "§cこの商品は売り切れです。");
                else handleBuyFromNpc(p, cur, se, shift);
                g.refresh();
            });
        }
        n = 27;
        for (Map.Entry<String, Double> b : npc.getBuyPrices().entrySet()) {
            if (n >= 54) break;
            Item it = Mc.item(b.getKey());
            if (it == null) continue;
            ItemStack s = new ItemStack(it, 1);
            List<String> lore = new ArrayList<>();
            lore.add("§7買取価格: §a" + fmt(b.getValue()) + "円");
            lore.add("§e手に持ってクリック=1個 §7/ §eShift+クリック=まとめて売却");
            Mc.setLore(s, lore);
            final String mat = b.getKey();
            g.set(n++, s, (p, right, shift) -> {
                ShopNpc cur = shopNpcManager.get(npcId);
                if (cur == null) return;
                handleSellToNpc(p, cur, mat, shift);
                g.refresh();
            });
        }
    }

    private void handleBuyFromNpc(ServerPlayer player, ShopNpc npc, ShopNpc.StockEntry entry, boolean shift) {
        Double priceObj = entry.getPrice();
        if (priceObj == null || entry.getAmount() <= 0) { Mc.msg(player, "§cこの商品は売り切れです。"); return; }
        double price = priceObj;
        ItemStack template = entry.getTemplate();
        double bal = cardManager.getBalance(player.getUUID());
        int amount = 1;
        if (shift) {
            int stock = entry.getAmount();
            int affordable = price > 0.0 ? (int) Math.floor((bal + 1.0E-9) / price) : stock;
            int space = freeSpace(player, template);
            int maxStack = template.getMaxStackSize();
            amount = Math.max(0, Math.min(Math.min(stock, maxStack), Math.min(affordable, space)));
            if (amount <= 0) { Mc.msg(player, "§c購入できる数量がありません(残高・在庫・空きスペースを確認してください)。"); return; }
        } else {
            if (bal < price) { Mc.msg(player, "§c残高が足りません。"); return; }
            if (freeSpace(player, template) < 1) { Mc.msg(player, "§cインベントリに空きがありません。"); return; }
        }
        ItemStack give = template.copyWithCount(amount);
        player.getInventory().add(give);
        int leftover = give.getCount();
        amount -= leftover;
        if (amount <= 0) { Mc.msg(player, "§cインベントリに空きがありません。"); return; }
        double total = price * amount;
        cardManager.removeBalance(player.getUUID(), total);
        distributeToOwners(npc, total);
        npc.removeStock(entry, amount);
        shopNpcManager.save();
        ShopTradeLog.log("BUY", player, npc, Mc.itemName(template), amount, price, total);
        Mc.msg(player, "§a購入しました(" + amount + "個, " + fmt(total) + "円)。");
    }

    private void handleSellToNpc(ServerPlayer player, ShopNpc npc, String mat, boolean shift) {
        Double priceObj = npc.getBuyPrices().get(mat);
        if (priceObj == null) return;
        double price = priceObj;
        ItemStack hand = Mc.hand(player);
        if (hand.isEmpty() || !Mc.itemName(hand).equals(mat)) { Mc.msg(player, "§c売りたいアイテムを手に持ってください。"); return; }
        ItemStack template = hand.copyWithCount(1);
        int amount = shift ? hand.getCount() : 1;
        UUID founder = npc.getFounder();
        double ownerBal = cardManager.getBalance(founder);
        int ownerAfford = price > 0.0 ? (int) Math.floor((ownerBal + 1.0E-9) / price) : amount;
        amount = Math.max(0, Math.min(amount, ownerAfford));
        double cap = cardManager.getMaxBalance();
        if (cap > 0.0 && price > 0.0) {
            double room = cap - cardManager.getBalance(player.getUUID());
            int roomItems = room > 0.0 ? (int) (room / price) : 0;
            amount = Math.max(0, Math.min(amount, roomItems));
        }
        if (amount <= 0) {
            if (cap > 0.0 && cardManager.getBalance(player.getUUID()) >= cap) Mc.msg(player, "§c残高が上限(" + fmt(cap) + "円)に達しているため売却できません。");
            else Mc.msg(player, "§cこのNPCのオーナー残高が不足しており、買い取れません。");
            return;
        }
        if (!npc.canAddNewSlot(template)) { Mc.msg(player, "§cNPCの在庫枠が満杯で、これ以上買い取れません。"); return; }
        double total = price * amount;
        hand.shrink(amount);
        cardManager.removeBalance(founder, total);
        if (!cardManager.addBalance(player.getUUID(), total)) {
            cardManager.addBalanceForce(founder, total);
            hand.grow(amount);
            Mc.msg(player, "§c残高上限のため売却できませんでした。");
            return;
        }
        npc.addStock(template, amount);
        shopNpcManager.save();
        ShopTradeLog.log("SELL", player, npc, mat, amount, price, total);
        Mc.msg(player, "§a売却しました(" + amount + "個, " + fmt(total) + "円)。");
    }

    private void distributeToOwners(ShopNpc npc, double total) {
        List<UUID> owners = npc.getOwners();
        if (owners.isEmpty()) return;
        double share = Math.floor(total / owners.size() * 100.0) / 100.0;
        double paid = 0.0;
        for (UUID u : owners) if (cardManager.addBalance(u, share)) paid += share;
        double rest = total - paid;
        if (rest > 0.0) cardManager.addBalance(npc.getFounder(), rest);
    }

    private int freeSpace(ServerPlayer player, ItemStack item) {
        int free = 0;
        int max = item.getMaxStackSize();
        Inventory inv = player.getInventory();
        for (int i = 0; i < Mc.STORAGE; i++) {
            ItemStack s = inv.getItem(i);
            if (s.isEmpty()) free += max;
            else if (s.getCount() < max && Mc.same(s, item)) free += max - s.getCount();
        }
        return free;
    }

    private String fmt(double d) { return CardManager.formatMoney(d); }
    private String trim(String s, int n) { return s.length() > n ? s.substring(0, n) : s; }
}
