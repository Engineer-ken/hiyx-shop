package yourname.cardshop.shopnpc;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.util.Mc;

/** 店NPC取引ログ(logs/shopnpc-trades-yyyy-MM-dd.log)。 */
public final class ShopTradeLog {
    private static final Object LOCK = new Object();
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private ShopTradeLog() { }

    public static void log(String kind, ServerPlayer player, ShopNpc npc, Object item, int qty, double unit, double total) {
        try {
            Path dir = CardShopMod.dir().resolve("logs");
            Files.createDirectories(dir);
            Path f = dir.resolve("shopnpc-trades-" + LocalDate.now() + ".log");
            StringBuilder owners = new StringBuilder();
            for (UUID u : npc.getOwners()) { if (owners.length() > 0) owners.append(','); owners.append(u); }
            String line = LocalDateTime.now().format(TS) + " | " + kind + " | player=" + clean(Mc.name(player)) + "(" + player.getUUID() + ")"
                    + " | npc=" + npc.getMannequinUuid() + " | founder=" + npc.getFounder() + " | owners=" + owners
                    + " | item=" + clean(String.valueOf(item)) + " | qty=" + qty
                    + " | unit=" + String.format(Locale.ROOT, "%.2f", unit) + " | total=" + String.format(Locale.ROOT, "%.2f", total) + System.lineSeparator();
            synchronized (LOCK) {
                try (BufferedWriter w = Files.newBufferedWriter(f, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND)) { w.write(line); }
            }
        } catch (IOException | RuntimeException ignored) { }
    }
    private static String clean(String s) { return s == null ? "null" : s.replace('\n', ' ').replace('\r', ' ').replace('|', '/'); }
}
