package yourname.cardshop.shopnpc;

import java.util.List;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.decoration.Mannequin;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import yourname.cardshop.command.CardTab;
import yourname.cardshop.util.Cmd;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Sender;

public class ShopNpcCommand implements Cmd {
    private static final double RADIUS = 4.0;
    private final ShopNpcManager shopNpcManager;

    public ShopNpcCommand(ShopNpcManager shopNpcManager) { this.shopNpcManager = shopNpcManager; }

    @Override
    public boolean run(Sender s, String[] a) {
        if (!s.isPlayer()) { s.msg("§cプレイヤーのみ実行できます。"); return true; }
        ServerPlayer p = s.player();
        if (a.length == 0) { s.msg("§c使い方: /shopnpc <sell|buy|addowner|removeowner|withdraw|collect|mystock> [引数]"); return true; }

        Mannequin m = null;
        for (Mannequin c : Mc.nearbyMannequins(p, RADIUS)) {
            ShopNpc n = shopNpcManager.get(c.getUUID());
            if (n != null && n.isOwner(p.getUUID())) { m = c; break; }
        }
        if (m == null) { s.msg("§c近くに、あなたがオーナーのNPCが見つかりません。"); return true; }
        ShopNpc npc = shopNpcManager.get(m.getUUID());
        if (npc == null) { s.msg("§cNPCデータが見つかりませんでした。"); return true; }

        switch (a[0].toLowerCase()) {
            case "sell" -> {
                if (a.length < 2) { s.msg("§c使い方: /shopnpc sell <価格> [all]"); return true; }
                double price = parsePrice(s, a[1]);
                if (Double.isNaN(price)) return true;
                ItemStack hand = Mc.hand(p);
                if (hand.isEmpty()) { s.msg("§c登録したいアイテムを手に持ってください。"); return true; }
                ItemStack template = hand.copyWithCount(1);
                if (!npc.canAddNewSlot(template)) { s.msg("§c在庫枠(27種類)が満杯です。"); return true; }
                int n;
                if (a.length >= 3 && a[2].equalsIgnoreCase("all")) {
                    n = 0;
                    Inventory inv = p.getInventory();
                    for (int i = 0; i < Mc.STORAGE; i++) {
                        ItemStack it = inv.getItem(i);
                        if (it.isEmpty() || !Mc.same(it, template)) continue;
                        n += it.getCount();
                        it.setCount(0);
                    }
                    ItemStack off = p.getItemInHand(InteractionHand.OFF_HAND);
                    if (!off.isEmpty() && Mc.same(off, template)) { n += off.getCount(); off.setCount(0); }
                } else {
                    n = hand.getCount();
                    hand.setCount(0);
                }
                ShopNpc.StockEntry e = npc.addStock(template, n);
                e.setPrice(price);
                shopNpcManager.save();
                s.msg("§a" + describe(template) + " を単価" + price + "円で出品しました(" + n + "個、在庫" + e.getAmount() + ")。");
            }
            case "buy" -> {
                if (a.length < 2) { s.msg("§c使い方: /shopnpc buy <価格>"); return true; }
                double price = parsePrice(s, a[1]);
                if (Double.isNaN(price)) return true;
                ItemStack hand = Mc.hand(p);
                if (hand.isEmpty()) { s.msg("§c買い取りたい種類を手に持ってください(消費されません)。"); return true; }
                String mat = Mc.itemName(hand);
                npc.getBuyPrices().put(mat, price);
                shopNpcManager.save();
                s.msg("§a" + mat + " を単価" + price + "円で買取登録しました。");
            }
            case "addowner" -> {
                if (a.length < 2) { s.msg("§c使い方: /shopnpc addowner <プレイヤー>"); return true; }
                UUID t = Mc.uuidOf(a[1]);
                if (t == null) { s.msg("§c" + a[1] + " が見つかりません。"); return true; }
                if (npc.addOwner(p.getUUID(), t)) { shopNpcManager.save(); s.msg("§a" + a[1] + " を共同オーナーに追加しました。"); }
                else s.msg("§c追加できません(最初に登録した人だけが実行できます)。");
            }
            case "removeowner" -> {
                if (a.length < 2) { s.msg("§c使い方: /shopnpc removeowner <プレイヤー>"); return true; }
                UUID t = Mc.uuidOf(a[1]);
                if (t == null) { s.msg("§c" + a[1] + " が見つかりません。"); return true; }
                if (npc.removeOwner(p.getUUID(), t)) { shopNpcManager.save(); s.msg("§a" + a[1] + " を共同オーナーから外しました。"); }
                else s.msg("§c削除できません(最初に登録した人だけが実行でき、founder自身は外せません)。");
            }
            case "withdraw" -> {
                ItemStack hand = Mc.hand(p);
                if (hand.isEmpty()) { s.msg("§c回収したいアイテムを手に持ってください(在庫にあるものと同じ現物を持てばOK。個数は無視されます)。"); return true; }
                ShopNpc.StockEntry target = npc.findEntry(hand);
                if (target == null || target.getAmount() <= 0) {
                    List<ShopNpc.StockEntry> list = npc.findStockedByMaterial(Mc.itemName(hand));
                    if (list.size() == 1) target = list.get(0);
                    else if (list.size() > 1) { s.msg("§c同じ種類の在庫が複数あります。回収したい現物(エンチャント・名前・耐久が同じもの)を手に持ってください。"); return true; }
                    else target = null;
                }
                if (target == null) { s.msg("§cこのNPCに " + Mc.itemName(hand) + " の在庫はありません。"); return true; }
                int stock = target.getAmount();
                int n = stock;
                if (a.length >= 2) {
                    try { n = Integer.parseInt(a[1]); } catch (NumberFormatException e) { s.msg("§c個数は整数で指定してください。"); return true; }
                    if (n <= 0) { s.msg("§c個数は1以上で指定してください。"); return true; }
                    n = Math.min(n, stock);
                }
                ItemStack tpl = target.getTemplate();
                String desc = describe(tpl);
                if (!npc.removeStock(target, n)) { s.msg("§c在庫の回収に失敗しました。"); return true; }
                Mc.give(p, tpl.copyWithCount(n));
                int left = target.getAmount();
                if (left <= 0) npc.removeEntry(target);
                shopNpcManager.save();
                s.msg("§a" + desc + " を " + n + "個 回収しました(残り在庫: " + left + ")。");
            }
            case "collect" -> {
                for (ShopNpc.StockEntry e : npc.getEntries()) {
                    if (e.getAmount() <= 0) continue;
                    Mc.give(p, e.getTemplate().copyWithCount(e.getAmount()));
                }
                npc.getEntries().clear();
                shopNpcManager.save();
                s.msg("§a在庫を全部回収し、出品をリセットしました。");
            }
            case "mystock" -> {
                s.msg("§6==== オーナー ====");
                for (UUID u : npc.getOwners()) s.msg((npc.isFounder(u) ? "§e★ " : "§f・ ") + Mc.nameOf(u));
                s.msg("§6==== 在庫 ====");
                int cnt = 0;
                for (ShopNpc.StockEntry e : npc.getEntries()) {
                    if (e.getAmount() <= 0) continue;
                    cnt++;
                    Double pr = e.getPrice();
                    s.msg("§f" + describe(e.getTemplate()) + " §7x" + e.getAmount() + " §f- §a" + (pr == null ? "?" : String.valueOf(pr)) + "円");
                }
                if (cnt == 0) s.msg("§7(在庫なし)");
                s.msg("§6==== 買取品目 ====");
                if (npc.getBuyPrices().isEmpty()) s.msg("§7(なし)");
                else npc.getBuyPrices().forEach((mat, d) -> s.msg("§f" + mat + " §f- §a" + d + "円"));
            }
            default -> s.msg("§c不明なサブコマンドです。");
        }
        return true;
    }

    static String describe(ItemStack it) {
        StringBuilder sb = new StringBuilder(Mc.itemName(it));
        String name = Mc.getName(it);
        if (name != null) sb.append("(").append(name).append("§f)");
        if (it.isEnchanted()) sb.append(" [エンチャント]");
        if (it.isDamaged()) sb.append(" [耐久消耗]");
        return sb.toString();
    }

    private double parsePrice(Sender s, String str) {
        try {
            double d = Double.parseDouble(str);
            if (d <= 0.0) { s.msg("§c価格は正の数で指定してください。"); return Double.NaN; }
            return d;
        } catch (NumberFormatException e) { s.msg("§c価格は数値で指定してください。"); return Double.NaN; }
    }

    @Override
    public List<String> tab(Sender s, String[] a) { return CardTab.shopnpc(s, a); }
}
