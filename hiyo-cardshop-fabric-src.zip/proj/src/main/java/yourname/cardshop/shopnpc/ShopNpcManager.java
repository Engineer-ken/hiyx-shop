package yourname.cardshop.shopnpc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.world.item.ItemStack;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Tasks;
import yourname.cardshop.util.Yml;

public class ShopNpcManager {
    private final Map<UUID, ShopNpc> npcs = new HashMap<>();
    private boolean savePending = false;

    public ShopNpcManager() { load(); }

    public ShopNpc create(UUID mannequin, UUID owner) {
        ShopNpc n = new ShopNpc(mannequin, owner);
        npcs.put(mannequin, n);
        save();
        return n;
    }
    public ShopNpc get(UUID id) { return npcs.get(id); }
    public void remove(UUID id) { npcs.remove(id); save(); }

    private void load() {
        Yml y = Yml.load(CardShopMod.file("shopnpcs.yml"));
        for (String key : y.keys()) {
            try {
                UUID id = UUID.fromString(key);
                String p = key + ".";
                List<String> list = y.getStringList(p + "owners");
                if (list.isEmpty() && y.contains(p + "owner")) list = List.of(y.getString(p + "owner"));
                List<UUID> owners = new ArrayList<>();
                for (String o : list) owners.add(UUID.fromString(o));
                if (owners.isEmpty()) continue;
                ShopNpc npc = new ShopNpc(id, owners.get(0));
                npc.setOwnersFromLoad(owners);
                Yml items = y.section(p + "items");
                if (items != null) for (String k : items.keys()) {
                    try {
                        String ip = p + "items." + k + ".";
                        String enc = y.getString(ip + "item");
                        if (enc == null) continue;
                        // 新形式はJSON("{"始まり)。旧プラグイン形式(Base64のNBT)も読めれば移行する
                        ItemStack t = enc.startsWith("{") ? Mc.dec(enc) : Mc.decLegacy(enc);
                        if (t.isEmpty()) { Mc.log("shopnpcs.yml: 読めない在庫アイテムをスキップ(" + key + "/" + k + ")"); continue; }
                        int amount = y.getInt(ip + "amount");
                        Double price = y.contains(ip + "price") ? Double.valueOf(y.getDouble(ip + "price")) : null;
                        UUID eid;
                        try { eid = UUID.fromString(k); } catch (IllegalArgumentException e) { eid = UUID.randomUUID(); }
                        if (amount <= 0 && price == null) continue;
                        npc.getEntries().add(new ShopNpc.StockEntry(eid, t, amount, price));
                    } catch (Exception e) { Mc.log("shopnpcs.yml 在庫読み込みエラー(" + key + "/" + k + "): " + e.getMessage()); }
                }
                Yml stock = y.section(p + "stock"); // 旧形式(素材名→個数)の移行
                if (stock != null) for (String k : stock.keys()) {
                    try {
                        ItemStack t = Mc.stack(k, 1);
                        if (t.isEmpty()) continue;
                        ShopNpc.StockEntry e = npc.addStock(t, y.getInt(p + "stock." + k));
                        if (y.contains(p + "sell." + k)) e.setPrice(y.getDouble(p + "sell." + k));
                    } catch (Exception e) { Mc.log("shopnpcs.yml 旧在庫の移行エラー(" + key + "/" + k + "): " + e.getMessage()); }
                }
                Yml buy = y.section(p + "buy");
                if (buy != null) for (String k : buy.keys()) npc.getBuyPrices().put(k.toUpperCase(), y.getDouble(p + "buy." + k));
                npcs.put(id, npc);
            } catch (Exception e) { Mc.log("shopnpcs.yml 読み込みエラー(" + key + "): " + e.getMessage()); }
        }
    }

    /** 5秒まとめて保存(軽量化) */
    public void save() {
        if (!CardShopMod.running()) { saveNow(); return; }
        if (savePending) return;
        savePending = true;
        Tasks.later(100, () -> { savePending = false; saveNow(); });
    }

    public void saveNow() {
        Yml y = new Yml();
        for (ShopNpc n : npcs.values()) {
            String p = n.getMannequinUuid() + ".";
            y.set(p + "owners", n.getOwners().stream().map(UUID::toString).toList());
            for (ShopNpc.StockEntry e : n.getEntries()) {
                String ip = p + "items." + e.getId() + ".";
                y.set(ip + "item", Mc.enc(e.getTemplate()));
                y.set(ip + "amount", e.getAmount());
                if (e.getPrice() != null) y.set(ip + "price", e.getPrice());
            }
            for (Map.Entry<String, Double> b : n.getBuyPrices().entrySet()) y.set(p + "buy." + b.getKey(), b.getValue());
        }
        y.save(CardShopMod.file("shopnpcs.yml"));
    }
}
