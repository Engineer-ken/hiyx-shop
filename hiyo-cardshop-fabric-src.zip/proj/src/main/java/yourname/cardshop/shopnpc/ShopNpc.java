package yourname.cardshop.shopnpc;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.world.item.ItemStack;
import yourname.cardshop.util.Mc;

/** 店NPC。品目名は Bukkit Material名(DIAMOND 等)と同じ大文字名。 */
public class ShopNpc {
    public static final int STOCK_SIZE = 27;
    private final UUID mannequinUuid;
    private final List<UUID> owners = new ArrayList<>();
    private final List<StockEntry> entries = new ArrayList<>();
    private final Map<String, Double> buyPrices = new LinkedHashMap<>();

    public ShopNpc(UUID mannequinUuid, UUID founder) { this.mannequinUuid = mannequinUuid; owners.add(founder); }

    public UUID getMannequinUuid() { return mannequinUuid; }
    public List<UUID> getOwners() { return owners; }
    public UUID getFounder() { return owners.isEmpty() ? null : owners.get(0); }
    public boolean isOwner(UUID u) { return owners.contains(u); }
    public boolean isFounder(UUID u) { return !owners.isEmpty() && owners.get(0).equals(u); }
    public boolean addOwner(UUID requester, UUID target) {
        if (!isFounder(requester) || owners.contains(target)) return false;
        owners.add(target);
        return true;
    }
    public boolean removeOwner(UUID requester, UUID target) {
        if (!isFounder(requester) || isFounder(target)) return false;
        return owners.remove(target);
    }
    public void setOwnersFromLoad(List<UUID> l) { owners.clear(); owners.addAll(l); }
    public List<StockEntry> getEntries() { return entries; }
    public Map<String, Double> getBuyPrices() { return buyPrices; }

    public StockEntry findEntry(ItemStack s) {
        if (s == null || s.isEmpty()) return null;
        for (StockEntry e : entries) if (Mc.same(e.getTemplate(), s)) return e;
        return null;
    }
    public StockEntry getEntryById(UUID id) {
        for (StockEntry e : entries) if (e.getId().equals(id)) return e;
        return null;
    }
    public List<StockEntry> findStockedByMaterial(String mat) {
        List<StockEntry> r = new ArrayList<>();
        for (StockEntry e : entries) if (e.getType().equals(mat) && e.getAmount() > 0) r.add(e);
        return r;
    }
    public int usedSlots() {
        int n = 0;
        for (StockEntry e : entries) if (e.getAmount() > 0) n++;
        return n;
    }
    public boolean canAddNewSlot(ItemStack s) {
        StockEntry e = findEntry(s);
        if (e != null && e.getAmount() > 0) return true;
        return usedSlots() < STOCK_SIZE;
    }
    public StockEntry addStock(ItemStack s, int n) {
        StockEntry e = findEntry(s);
        if (e == null) { e = new StockEntry(UUID.randomUUID(), s, 0, null); entries.add(e); }
        e.setAmount(e.getAmount() + n);
        return e;
    }
    public boolean removeStock(StockEntry e, int n) {
        if (e == null || e.getAmount() < n) return false;
        e.setAmount(e.getAmount() - n);
        if (e.getAmount() <= 0 && e.getPrice() == null) entries.remove(e);
        return true;
    }
    public void removeEntry(StockEntry e) { entries.remove(e); }

    public static class StockEntry {
        private final UUID id;
        private final ItemStack template;
        private int amount;
        private Double price;

        public StockEntry(UUID id, ItemStack template, int amount, Double price) {
            this.id = id;
            this.template = template.copyWithCount(1);
            this.amount = amount;
            this.price = price;
        }
        private String enc;
        /** 保存用JSON(テンプレートは不変なので1回だけ生成) */
        public void setEnc(String e) { this.enc = e; }
        public String enc() { if (enc == null) enc = Mc.enc(template); return enc; }
        public UUID getId() { return id; }
        public ItemStack getTemplate() { return template; }
        public int getAmount() { return amount; }
        public void setAmount(int n) { amount = n; }
        public Double getPrice() { return price; }
        public void setPrice(Double d) { price = d; }
        public String getType() { return Mc.itemName(template); }
    }
}
