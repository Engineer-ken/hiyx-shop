package yourname.cardshop.util;

import com.mojang.serialization.Codec;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.UUID;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;

/** Mannequin NPC の生成・削除。生成は /summon (NBT) を使うので内部API変更に強い。 */
public final class Npc {
    private Npc() { }

    /** エンティティ側に永続保存する役割マーカー ("gate" 等) — 元のPDCマーカーの代わり */
    public static final AttachmentType<String> ROLE =
            AttachmentRegistry.createPersistent(Identifier.fromNamespaceAndPath("cardshop", "role"), Codec.STRING);

    public static String role(Entity e) { return e.getAttached(ROLE); }

    private static String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }

    private static String uuidNbt(UUID u) {
        long m = u.getMostSignificantBits(), l = u.getLeastSignificantBits();
        return "[I;" + (int) (m >> 32) + "," + (int) m + "," + (int) (l >> 32) + "," + (int) l + "]";
    }

    /**
     * @param skinUrl 空でなければこのURLのスキンを使用(失敗時クライアントは既定スキン)
     * @param skinPlayer URL未指定時に見た目を借りるプレイヤー
     * @return 生成したNPCのUUID
     */
    public static UUID spawn(ServerLevel level, double x, double y, double z, float yaw, String name, String role,
                             String skinUrl, UUID skinPlayer, String skinPlayerName) {
        UUID id = UUID.randomUUID();
        String profile = null;
        if (skinUrl != null && !skinUrl.isBlank()) {
            String json = "{\"textures\":{\"SKIN\":{\"url\":\"" + skinUrl.trim() + "\"}}}";
            String b64 = Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8));
            profile = "{name:\"NPC\",id:" + uuidNbt(UUID.randomUUID()) + ",properties:[{name:\"textures\",value:\"" + b64 + "\"}]}";
        } else if (skinPlayer != null) {
            profile = "{name:\"" + esc(skinPlayerName) + "\",id:" + uuidNbt(skinPlayer) + "}";
        }
        String nbt = "{UUID:" + uuidNbt(id) + ",CustomName:\"" + esc(name) + "\",CustomNameVisible:1b,Invulnerable:1b,Silent:1b,immovable:1b"
                + ",Rotation:[" + yaw + "f,0f]" + (profile != null ? ",profile:" + profile : "") + "}";
        String cmd = "execute in " + level.dimension().identifier() + " run summon minecraft:mannequin "
                + x + " " + y + " " + z + " " + nbt;
        Mc.console(cmd);
        Entity e = level.getEntity(id);
        if (e != null && role != null) e.setAttached(ROLE, role);
        return id;
    }

    public static void remove(UUID id) {
        Entity e = Mc.entity(id);
        if (e != null) e.discard();
    }
}
