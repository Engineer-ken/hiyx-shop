package yourname.cardshop.util;

import java.util.UUID;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerPlayer;

/** コマンド実行者(プレイヤー or コンソール)。 */
public final class Sender {
    public final CommandSourceStack src;
    public Sender(CommandSourceStack src) { this.src = src; }

    public ServerPlayer player() { return src.getPlayer(); }
    public boolean isPlayer() { return src.getPlayer() != null; }
    public String name() { ServerPlayer p = src.getPlayer(); return p != null ? Mc.name(p) : "Console"; }
    public UUID uuid() { ServerPlayer p = src.getPlayer(); return p != null ? p.getUUID() : null; }
    public void msg(String s) { Mc.msg(src, s); }
    public boolean admin() { return Mc.isAdmin(src); }
}
