package yourname.cardshop.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

/** BukkitScheduler の代わり。サーバーtickに乗せる軽量スケジューラ(タスクが無いときはほぼ何もしない)。 */
public final class Tasks {
    private static final Queue<Runnable> NEXT = new ConcurrentLinkedQueue<>();
    private static final Queue<Timer> INCOMING = new ConcurrentLinkedQueue<>();
    private static final List<Timer> TIMERS = new ArrayList<>();
    private static final ExecutorService ASYNC = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "cardshop-async");
        t.setDaemon(true);
        return t;
    });
    private static volatile long tick = 0;

    public static final class Timer {
        private long nextRun; private final int period; private final Runnable r; private boolean cancelled;
        Timer(long next, int period, Runnable r) { this.nextRun = next; this.period = period; this.r = r; }
        public void cancel() { cancelled = true; }
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tick++;
            Runnable r;
            while ((r = NEXT.poll()) != null) safe(r);
            Timer in;
            while ((in = INCOMING.poll()) != null) TIMERS.add(in);
            if (TIMERS.isEmpty()) return;
            for (int i = TIMERS.size() - 1; i >= 0; i--) {
                Timer t = TIMERS.get(i);
                if (t.cancelled) { TIMERS.remove(i); continue; }
                if (tick >= t.nextRun) {
                    if (t.period > 0) t.nextRun = tick + t.period; else t.cancelled = true;
                    safe(t.r);
                }
            }
        });
    }
    private static void safe(Runnable r) {
        try { r.run(); } catch (Throwable e) { System.err.println("[CardShop] タスク例外: " + e); e.printStackTrace(); }
    }

    /** 次のtickで実行(別スレッドから呼んでOK) */
    public static void run(Runnable r) { NEXT.add(r); }
    /** ticks 後に1回実行(サーバースレッドから) */
    public static Timer later(int ticks, Runnable r) { Timer t = new Timer(tick + Math.max(1, ticks), 0, r); INCOMING.add(t); return t; }
    /** delay後、period tickごとに実行 */
    public static Timer timer(int delay, int period, Runnable r) { Timer t = new Timer(tick + Math.max(1, delay), Math.max(1, period), r); INCOMING.add(t); return t; }
    public static void async(Runnable r) { ASYNC.execute(r); }
    public static void shutdown() { ASYNC.shutdown(); }
}
