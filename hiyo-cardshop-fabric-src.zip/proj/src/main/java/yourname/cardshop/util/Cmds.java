package yourname.cardshop.util;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.List;
import java.util.Locale;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;

/** args[] 方式のコマンドをBrigadierに登録する薄いアダプタ(元プラグインのコード構造を維持するため)。 */
public final class Cmds {
    private Cmds() { }

    public static void register(CommandDispatcher<CommandSourceStack> d, String name, String usage, boolean adminOnly, Cmd cmd) {
        var root = Commands.literal(name);
        if (adminOnly) root.requires(Mc::isAdmin);
        root.executes(c -> exec(c, "", usage, cmd));
        root.then(Commands.argument("args", StringArgumentType.greedyString())
                .suggests((c, b) -> suggest(c, b, cmd))
                .executes(c -> exec(c, StringArgumentType.getString(c, "args"), usage, cmd)));
        d.register(root);
    }

    private static String[] split(String in) {
        String t = in.trim();
        return t.isEmpty() ? new String[0] : t.split("\\s+");
    }

    private static int exec(CommandContext<CommandSourceStack> c, String in, String usage, Cmd cmd) {
        Sender s = new Sender(c.getSource());
        try {
            if (!cmd.run(s, split(in)) && usage != null && !usage.isEmpty()) s.msg(usage);
        } catch (Exception e) {
            s.msg("\u00a7c\u5185\u90e8\u30a8\u30e9\u30fc\u304c\u767a\u751f\u3057\u307e\u3057\u305f: " + e);
            e.printStackTrace();
        }
        return 1;
    }

    private static java.util.concurrent.CompletableFuture<com.mojang.brigadier.suggestion.Suggestions> suggest(
            CommandContext<CommandSourceStack> c, SuggestionsBuilder b, Cmd cmd) {
        String in = b.getRemaining();
        String[] args = in.isEmpty() ? new String[] {""} : in.split(" ", -1);
        String last = args[args.length - 1];
        SuggestionsBuilder sb = b.createOffset(b.getStart() + in.lastIndexOf(' ') + 1);
        try {
            List<String> l = cmd.tab(new Sender(c.getSource()), args);
            if (l != null) for (String x : l) if (x.toLowerCase(Locale.ROOT).startsWith(last.toLowerCase(Locale.ROOT))) sb.suggest(x);
        } catch (Exception ignored) { }
        return sb.buildFuture();
    }
}
