package yourname.cardshop.util;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;

/** クリックを自前で処理するチェスト型GUI(アイテムは一切動かせない)。 */
public final class Gui extends ChestMenu {
    @FunctionalInterface
    public interface Click { void on(ServerPlayer p, boolean rightClick, boolean shift); }

    private static MenuType<?> type(int rows) {
        return switch (rows) {
            case 1 -> MenuType.GENERIC_9x1; case 2 -> MenuType.GENERIC_9x2; case 3 -> MenuType.GENERIC_9x3;
            case 4 -> MenuType.GENERIC_9x4; case 5 -> MenuType.GENERIC_9x5; default -> MenuType.GENERIC_9x6;
        };
    }

    private final SimpleContainer box;
    private final int size;
    private final Map<Integer, Click> acts = new HashMap<>();
    private Consumer<Gui> filler;

    private Gui(int id, Inventory inv, SimpleContainer box, int rows) {
        super(type(rows), id, inv, box, rows);
        this.box = box;
        this.size = rows * 9;
    }

    public void set(int slot, ItemStack s, Click c) {
        if (slot < 0 || slot >= size) return;
        box.setItem(slot, s);
        if (c != null) acts.put(slot, c);
    }
    public int size() { return size; }

    /** 中身を作り直して同期(再オープンせずに更新するのでカーソルがずれない) */
    public void refresh() {
        box.clearContent();
        acts.clear();
        if (filler != null) filler.accept(this);
        sendAllDataToRemote();
    }

    public static void open(ServerPlayer p, String title, int rows, Consumer<Gui> filler) {
        final int r = Math.max(1, Math.min(6, rows));
        p.openMenu(new SimpleMenuProvider((id, inv, pl) -> {
            Gui g = new Gui(id, inv, new SimpleContainer(r * 9), r);
            g.filler = filler;
            if (filler != null) filler.accept(g);
            return g;
        }, Txt.c(title)));
    }

    @Override
    public void clicked(int slotId, int clickData, ContainerInput input, Player player) {
        if (player instanceof ServerPlayer sp && slotId >= 0 && slotId < size) {
            Click c = acts.get(slotId);
            if (c != null) c.on(sp, clickData == 1, "QUICK_MOVE".equals(input.name()));
        }
        sendAllDataToRemote();
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) { return ItemStack.EMPTY; }

    @Override
    public boolean stillValid(Player player) { return true; }
}
