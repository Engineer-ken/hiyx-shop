package yourname.cardshop.util;

/** ブロック座標(world = Bukkit形式のワールド名) */
public record Pos(String world, int x, int y, int z) {
    public String key() { return world + "," + x + "," + y + "," + z; }
    public static Pos parse(String s) {
        String[] a = s.split(",");
        return new Pos(a[0], Integer.parseInt(a[1].trim()), Integer.parseInt(a[2].trim()), Integer.parseInt(a[3].trim()));
    }
}
