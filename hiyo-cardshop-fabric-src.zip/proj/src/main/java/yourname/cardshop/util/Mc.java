package yourname.cardshop.util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.function.Predicate;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.PermissionLevel;
import net.minecraft.util.Prediction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtOps;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Minecraft固有の操作をここに集約(バージョン差異で壊れたらこのファイルを直す)。 */
public final class Mc {
    private Mc() { }

    private static MinecraftServer server;
    public static void setServer(MinecraftServer s) { server = s; }
    public static MinecraftServer server() { return server; }

    // ================= プレイヤー / 権限 =================
    public static List<ServerPlayer> online() { return server == null ? List.of() : new ArrayList<>(server.getPlayerList().getPlayers()); }
    public static ServerPlayer player(UUID id) { return server == null ? null : server.getPlayerList().getPlayer(id); }
    public static ServerPlayer player(String name) { return server == null ? null : server.getPlayerList().getPlayerByName(name); }
    public static String name(ServerPlayer p) { return p.getName().getString(); }
    public static void msg(ServerPlayer p, String s) { p.sendSystemMessage(Txt.c(s)); }
    public static void msg(CommandSourceStack src, String s) { src.sendSystemMessage(Txt.c(s)); }
    public static void log(String s) { System.out.println("[CardShop] " + Txt.strip(s)); }

    private static final Identifier ADMIN = Identifier.fromNamespaceAndPath("cardshop", "admin");
    private static final Identifier CASINO = Identifier.fromNamespaceAndPath("cardshop", "casino");
    private static final Identifier TAX_EXEMPT = Identifier.fromNamespaceAndPath("cardshop", "logintax.exempt");
    public static boolean isAdmin(CommandSourceStack s) { return s.checkPermission(ADMIN, PermissionLevel.GAMEMASTERS); }
    public static boolean isAdmin(ServerPlayer p) { return p.checkPermission(ADMIN, PermissionLevel.GAMEMASTERS); }
    public static boolean canCasino(ServerPlayer p) { return p.checkPermission(CASINO, true); }
    public static boolean taxExempt(ServerPlayer p) { return p.checkPermission(TAX_EXEMPT, false); }

    /** 管理者(権限保持者+コンソール)へ通知 */
    public static void notifyAdmins(String s) {
        for (ServerPlayer p : online()) if (isAdmin(p)) msg(p, s);
        log(s);
    }
    public static void broadcast(String s) {
        for (ServerPlayer p : online()) msg(p, s);
        log(s);
    }

    // ---- オフライン名前解決 (usercache.json) ----
    private static Map<String, UUID> byName = new HashMap<>();
    private static Map<UUID, String> byId = new HashMap<>();
    private static long cacheStamp = -1;
    private static void loadCache() {
        Path f = Path.of("usercache.json");
        try {
            if (!Files.exists(f)) return;
            long st = Files.getLastModifiedTime(f).toMillis();
            if (st == cacheStamp) return;
            cacheStamp = st;
            Map<String, UUID> n = new HashMap<>();
            Map<UUID, String> i = new HashMap<>();
            try (Reader r = Files.newBufferedReader(f)) {
                JsonElement root = JsonParser.parseReader(r);
                if (root instanceof JsonArray arr) for (JsonElement e : arr) {
                    JsonObject o = e.getAsJsonObject();
                    UUID u = UUID.fromString(o.get("uuid").getAsString());
                    String nm = o.get("name").getAsString();
                    n.put(nm.toLowerCase(Locale.ROOT), u);
                    i.put(u, nm);
                }
            }
            byName = n; byId = i;
        } catch (Exception ignored) { }
    }
    /** 名前 → UUID (オンライン優先、なければ usercache.json)。不明なら null */
    public static UUID uuidOf(String name) {
        ServerPlayer p = player(name);
        if (p != null) return p.getUUID();
        loadCache();
        return byName.get(name.toLowerCase(Locale.ROOT));
    }
    /** UUID → 名前 (不明なら UUID先頭8桁) */
    public static String nameOf(UUID id) {
        ServerPlayer p = player(id);
        if (p != null) return name(p);
        loadCache();
        String n = byId.get(id);
        return n != null ? n : id.toString().substring(0, 8);
    }

    // ================= アイテム =================
    /** Bukkit Material名(PAPER等) → Item。不明なら null */
    public static Item item(String name) {
        if (name == null) return null;
        try {
            Item it = BuiltInRegistries.ITEM.getValue(Identifier.parse(name.toLowerCase(Locale.ROOT)));
            return it == null || it == Items.AIR ? null : it;
        } catch (Exception e) { return null; }
    }
    public static String itemName(Item it) { return BuiltInRegistries.ITEM.getKey(it).getPath().toUpperCase(Locale.ROOT); }
    public static String itemName(ItemStack s) { return itemName(s.getItem()); }
    public static ItemStack stack(String material, int n) { Item it = item(material); return it == null ? ItemStack.EMPTY : new ItemStack(it, n); }
    public static boolean same(ItemStack a, ItemStack b) { return ItemStack.isSameItemSameComponents(a, b); }

    public static void setName(ItemStack s, String legacy) { s.set(DataComponents.CUSTOM_NAME, Txt.c(legacy)); }
    public static String getName(ItemStack s) { Component c = s.get(DataComponents.CUSTOM_NAME); return c == null ? null : c.getString(); }
    public static void setLore(ItemStack s, List<String> lines) {
        List<Component> l = new ArrayList<>();
        for (String x : lines) l.add(Txt.c(x));
        s.set(DataComponents.LORE, new ItemLore(l));
    }
    public static void addLore(ItemStack s, List<String> lines) {
        ItemLore old = s.get(DataComponents.LORE);
        List<Component> l = new ArrayList<>(old == null ? List.of() : old.lines());
        for (String x : lines) l.add(Txt.c(x));
        s.set(DataComponents.LORE, new ItemLore(l));
    }
    public static String tagGet(ItemStack s, String key) {
        CustomData cd = s.get(DataComponents.CUSTOM_DATA);
        if (cd == null) return null;
        return cd.copyTag().getString(key).orElse(null);
    }
    public static void tagSet(ItemStack s, String key, String val) {
        CustomData cd = s.get(DataComponents.CUSTOM_DATA);
        CompoundTag t = cd == null ? new CompoundTag() : cd.copyTag();
        t.putString(key, val);
        s.set(DataComponents.CUSTOM_DATA, CustomData.of(t));
    }
    /** 名前・説明・タグなど付加情報があるか */
    public static boolean hasMeta(ItemStack s) {
        return s.has(DataComponents.CUSTOM_NAME) || s.has(DataComponents.LORE) || s.has(DataComponents.CUSTOM_DATA) || s.has(DataComponents.ENCHANTMENTS);
    }

    public static String enc(ItemStack s) {
        var ops = RegistryOps.create(JsonOps.INSTANCE, server.registryAccess());
        return ItemStack.CODEC.encodeStart(ops, s).getOrThrow().toString();
    }
    public static ItemStack dec(String json) {
        try {
            var ops = RegistryOps.create(JsonOps.INSTANCE, server.registryAccess());
            return ItemStack.CODEC.parse(ops, JsonParser.parseString(json)).result().orElse(ItemStack.EMPTY);
        } catch (Exception e) { return ItemStack.EMPTY; }
    }

    /** 旧プラグイン(Paper)の ItemStack.serializeAsBytes() をBase64化したものを読む(shopnpcs.yml 移行用)。失敗時は EMPTY */
    public static ItemStack decLegacy(String base64) {
        try {
            byte[] b = java.util.Base64.getDecoder().decode(base64);
            CompoundTag tag = NbtIo.readCompressed(new java.io.ByteArrayInputStream(b), NbtAccounter.unlimitedHeap());
            var ops = RegistryOps.create(NbtOps.INSTANCE, server.registryAccess());
            return ItemStack.CODEC.parse(ops, tag).result().orElse(ItemStack.EMPTY);
        } catch (Throwable e) { return ItemStack.EMPTY; }
    }

    // ---- インベントリ(メイン36スロット) ----
    public static final int STORAGE = 36;
    public static int count(ServerPlayer p, Predicate<ItemStack> f) {
        Inventory inv = p.getInventory(); int n = 0;
        for (int i = 0; i < STORAGE; i++) { ItemStack s = inv.getItem(i); if (!s.isEmpty() && f.test(s)) n += s.getCount(); }
        return n;
    }
    /** 条件に合うアイテムを最大amount個消費。実際に消費した数を返す */
    public static int take(ServerPlayer p, Predicate<ItemStack> f, int amount) {
        Inventory inv = p.getInventory(); int left = amount;
        for (int i = 0; i < STORAGE && left > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (s.isEmpty() || !f.test(s)) continue;
            int t = Math.min(left, s.getCount());
            s.shrink(t); left -= t;
        }
        return amount - left;
    }
    /** 最大スタック数ごとに分割して付与。入りきらない分は足元にドロップ */
    public static void give(ServerPlayer p, ItemStack s) {
        int left = s.getCount();
        int max = Math.max(1, s.getMaxStackSize());
        while (left > 0) {
            int n = Math.min(left, max);
            p.getInventory().placeItemBackInInventory(s.copyWithCount(n), Prediction.SERVER_ONLY);
            left -= n;
        }
    }
    /** メイン36スロットに s(個数込み)が全部入るか */
    public static boolean canFit(ServerPlayer p, ItemStack s) {
        Inventory inv = p.getInventory();
        int max = Math.max(1, s.getMaxStackSize());
        int room = 0;
        for (int i = 0; i < STORAGE; i++) {
            ItemStack c = inv.getItem(i);
            if (c.isEmpty()) room += max;
            else if (same(c, s)) room += Math.max(0, max - c.getCount());
            if (room >= s.getCount()) return true;
        }
        return room >= s.getCount();
    }
    public static ItemStack hand(ServerPlayer p) { return p.getMainHandItem(); }

    // ================= ワールド =================
    /** Bukkit形式のワールド名("world" / "world_nether" / "world_the_end") または dimension id */
    public static ServerLevel level(String world) {
        if (server == null || world == null) return null;
        ResourceKey<Level> k = switch (world) {
            case "world", "overworld", "minecraft:overworld" -> Level.OVERWORLD;
            case "world_nether", "the_nether", "minecraft:the_nether" -> Level.NETHER;
            case "world_the_end", "the_end", "minecraft:the_end" -> Level.END;
            default -> {
                try { yield ResourceKey.create(Registries.DIMENSION, Identifier.parse(world)); } catch (Exception e) { yield null; }
            }
        };
        return k == null ? null : server.getLevel(k);
    }
    public static String worldName(Level l) {
        ResourceKey<Level> k = l.dimension();
        if (k == Level.OVERWORLD) return "world";
        if (k == Level.NETHER) return "world_nether";
        if (k == Level.END) return "world_the_end";
        return k.identifier().toString();
    }
    public static Entity entity(UUID id) {
        if (server == null) return null;
        for (ServerLevel l : server.getAllLevels()) { Entity e = l.getEntity(id); if (e != null) return e; }
        return null;
    }
    public static BlockState state(ServerLevel l, int x, int y, int z) { return l.getBlockState(new BlockPos(x, y, z)); }
    public static BlockState state(Pos p) { ServerLevel l = level(p.world()); return l == null ? null : state(l, p.x(), p.y(), p.z()); }
    public static String blockId(BlockState s) { return BuiltInRegistries.BLOCK.getKey(s.getBlock()).getPath(); }

    /** コマンドをコンソール権限で実行(出力は抑制) */
    public static void console(String cmd) {
        if (server == null) return;
        server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), cmd);
    }

    /** 旧プラグイン(Bukkit PDC)が付けた値を読む: custom_data.PublicBukkitValues["cardshopplugin:<key>"] */
    public static boolean legacyHas(ItemStack s, String key) {
        CustomData cd = s.get(DataComponents.CUSTOM_DATA);
        if (cd == null) return false;
        return cd.copyTag().getCompound("PublicBukkitValues").map(t -> t.contains("cardshopplugin:" + key)).orElse(false);
    }
    public static String legacyString(ItemStack s, String key) {
        CustomData cd = s.get(DataComponents.CUSTOM_DATA);
        if (cd == null) return null;
        return cd.copyTag().getCompound("PublicBukkitValues").flatMap(t -> t.getString("cardshopplugin:" + key)).orElse(null);
    }

    /** プレイヤー周囲のMannequin(NPC) */
    public static List<net.minecraft.world.entity.decoration.Mannequin> nearbyMannequins(ServerPlayer p, double r) {
        return ((ServerLevel) p.level()).getEntitiesOfClass(net.minecraft.world.entity.decoration.Mannequin.class, p.getBoundingBox().inflate(r));
    }

    /** ブロック位置(角)から ±r の範囲のMannequin */
    public static List<net.minecraft.world.entity.decoration.Mannequin> mannequinsNear(ServerLevel l, BlockPos p, double r) {
        return l.getEntitiesOfClass(net.minecraft.world.entity.decoration.Mannequin.class,
                new net.minecraft.world.phys.AABB(p.getX() - r, p.getY() - r, p.getZ() - r, p.getX() + r, p.getY() + r, p.getZ() + r));
    }

    // ---- 看板の文字(API名の差異に強いようリフレクションで取得) ----
    private static boolean signResolved;
    private static java.lang.reflect.Method mFront, mBack, mText, mMessages, mMessage;
    private static void resolveSign() {
        if (signResolved) return;
        signResolved = true;
        try {
            Class<?> signClass = net.minecraft.world.level.block.entity.SignBlockEntity.class;
            Class<?> textClass = null;
            for (java.lang.reflect.Method m : signClass.getMethods()) {
                if (m.getParameterCount() == 0 && m.getName().equals("getFrontText")) { mFront = m; textClass = m.getReturnType(); }
                else if (m.getParameterCount() == 0 && m.getName().equals("getBackText")) mBack = m;
                else if (m.getParameterCount() == 1 && m.getParameterTypes()[0] == boolean.class && m.getName().equals("getText")) { mText = m; textClass = m.getReturnType(); }
            }
            if (textClass == null) return;
            for (java.lang.reflect.Method m : textClass.getMethods()) {
                if (m.getName().equals("getMessages") && m.getParameterCount() == 1 && m.getReturnType().isArray()) mMessages = m;
                else if (m.getName().equals("getMessage") && m.getParameterCount() == 2) mMessage = m;
            }
        } catch (Throwable t) { log("看板APIの解決に失敗: " + t); }
    }
    /** 看板の4行のテキスト(取得できなければ空配列) */
    public static String[] signLines(net.minecraft.world.level.block.entity.SignBlockEntity sign, boolean front) {
        resolveSign();
        try {
            Object text = null;
            if (mText != null) text = mText.invoke(sign, front);
            else if (front && mFront != null) text = mFront.invoke(sign);
            else if (!front && mBack != null) text = mBack.invoke(sign);
            if (text == null) return new String[0];
            String[] out = new String[4];
            if (mMessages != null) {
                Object arr = mMessages.invoke(text, false);
                for (int i = 0; i < 4 && i < java.lang.reflect.Array.getLength(arr); i++) {
                    Object c = java.lang.reflect.Array.get(arr, i);
                    out[i] = c instanceof Component cc ? cc.getString() : "";
                }
            } else if (mMessage != null) {
                for (int i = 0; i < 4; i++) {
                    Object c = mMessage.invoke(text, i, false);
                    out[i] = c instanceof Component cc ? cc.getString() : "";
                }
            } else return new String[0];
            return out;
        } catch (Throwable t) { return new String[0]; }
    }

    // @@MORE@@
}
