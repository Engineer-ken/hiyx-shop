package yourname.cardshop.util;

import java.util.List;

/** Bukkit CommandExecutor + TabCompleter 互換のコマンド定義。 */
public interface Cmd {
    /** false を返すと usage を表示する */
    boolean run(Sender s, String[] args);
    default List<String> tab(Sender s, String[] args) { return List.of(); }
}
