package yourname.cardshop.util;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;

/** §カラーコード(Bukkit形式)文字列 → Component 変換。 */
public final class Txt {
    private Txt() { }

    /** '&' を '§' に変換(ChatColor.translateAlternateColorCodes 相当) */
    public static String color(String s) {
        if (s == null) return "";
        char[] b = s.toCharArray();
        for (int i = 0; i < b.length - 1; i++) {
            if (b[i] == '&' && "0123456789AaBbCcDdEeFfKkLlMmNnOoRrXx".indexOf(b[i + 1]) > -1) { b[i] = '\u00a7'; b[i + 1] = Character.toLowerCase(b[i + 1]); }
        }
        return new String(b);
    }

    /** 色コード除去 */
    public static String strip(String s) {
        if (s == null) return "";
        return s.replaceAll("\u00a7.", "");
    }

    public static MutableComponent c(String s) {
        MutableComponent root = Component.empty().withStyle(Style.EMPTY.withItalic(false));
        if (s == null || s.isEmpty()) return root;
        Style style = Style.EMPTY;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '\u00a7' && i + 1 < s.length()) {
                char code = Character.toLowerCase(s.charAt(i + 1));
                ChatFormatting f = ChatFormatting.getByCode(code);
                if (f != null) {
                    if (sb.length() > 0) { root.append(Component.literal(sb.toString()).withStyle(style)); sb.setLength(0); }
                    if (f == ChatFormatting.RESET) style = Style.EMPTY;
                    else if ("klmno".indexOf(code) >= 0) style = style.applyFormat(f);
                    else style = Style.EMPTY.applyFormat(f);
                    i++;
                    continue;
                }
            }
            sb.append(ch);
        }
        if (sb.length() > 0) root.append(Component.literal(sb.toString()).withStyle(style));
        return root;
    }
}
