package yourname.cardshop.util;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;

/** Bukkit の YamlConfiguration 互換の軽量ラッパー(ドット区切りパス対応)。 */
public final class Yml {
    private final Map<String, Object> root;

    public Yml() { this.root = new LinkedHashMap<>(); }
    private Yml(Map<String, Object> m) { this.root = m; }

    @SuppressWarnings("unchecked")
    public static Yml load(Path file) {
        if (!Files.exists(file)) return new Yml();
        try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            Object o = new Yaml().load(r);
            return o instanceof Map ? new Yml(norm((Map<Object, Object>) o)) : new Yml();
        } catch (Exception e) {
            System.err.println("[CardShop] YAML読み込み失敗: " + file + " : " + e);
            return new Yml();
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> norm(Map<Object, Object> in) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (Map.Entry<Object, Object> e : in.entrySet()) {
            Object v = e.getValue();
            if (v instanceof Map) v = norm((Map<Object, Object>) v);
            out.put(String.valueOf(e.getKey()), v);
        }
        return out;
    }

    public void save(Path file) {
        try {
            if (file.getParent() != null) Files.createDirectories(file.getParent());
            DumperOptions o = new DumperOptions();
            o.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
            o.setAllowUnicode(true);
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            try (Writer w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
                new Yaml(o).dump(root, w);
            }
            Files.move(tmp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            System.err.println("[CardShop] YAML保存失敗: " + file + " : " + e);
        }
    }

    // ---- 取得 ----
    @SuppressWarnings("unchecked")
    public Object get(String path) {
        Object cur = root;
        for (String k : path.split("\\.")) {
            if (!(cur instanceof Map)) return null;
            cur = ((Map<String, Object>) cur).get(k);
            if (cur == null) return null;
        }
        return cur;
    }
    public boolean contains(String path) { return get(path) != null; }
    public String getString(String path, String def) { Object o = get(path); return o == null ? def : String.valueOf(o); }
    public String getString(String path) { return getString(path, null); }
    public double getDouble(String path, double def) {
        Object o = get(path);
        if (o instanceof Number n) return n.doubleValue();
        if (o instanceof String s) { try { return Double.parseDouble(s); } catch (Exception ignored) { } }
        return def;
    }
    public double getDouble(String path) { return getDouble(path, 0.0); }
    public long getLong(String path, long def) {
        Object o = get(path);
        if (o instanceof Number n) return n.longValue();
        if (o instanceof String s) { try { return Long.parseLong(s.trim()); } catch (Exception ignored) { } }
        return def;
    }
    public long getLong(String path) { return getLong(path, 0L); }
    public int getInt(String path, int def) { return (int) getLong(path, def); }
    public int getInt(String path) { return getInt(path, 0); }
    public boolean getBoolean(String path, boolean def) {
        Object o = get(path);
        if (o instanceof Boolean b) return b;
        if (o instanceof String s) return Boolean.parseBoolean(s);
        return def;
    }
    public boolean getBoolean(String path) { return getBoolean(path, false); }
    public List<String> getStringList(String path) {
        List<String> out = new ArrayList<>();
        if (get(path) instanceof List<?> l) for (Object o : l) out.add(String.valueOf(o));
        return out;
    }

    // ---- セクション ----
    @SuppressWarnings("unchecked")
    public Yml section(String path) {
        Object o = get(path);
        return o instanceof Map ? new Yml((Map<String, Object>) o) : null;
    }
    public boolean isSection(String path) { return get(path) instanceof Map; }
    public List<String> keys() { return new ArrayList<>(root.keySet()); }
    public List<String> keys(String path) {
        Yml s = path == null || path.isEmpty() ? this : section(path);
        return s == null ? new ArrayList<>() : s.keys();
    }

    // ---- 設定 ----
    @SuppressWarnings("unchecked")
    public void set(String path, Object value) {
        String[] ks = path.split("\\.");
        Map<String, Object> cur = root;
        for (int i = 0; i < ks.length - 1; i++) {
            Object n = cur.get(ks[i]);
            if (!(n instanceof Map)) {
                if (value == null) return;
                n = new LinkedHashMap<String, Object>();
                cur.put(ks[i], n);
            }
            cur = (Map<String, Object>) n;
        }
        if (value == null) cur.remove(ks[ks.length - 1]);
        else cur.put(ks[ks.length - 1], value instanceof Yml y ? y.root : value);
    }
    public void clear() { root.clear(); }

    /** jar内の既定値で、足りないキーだけ補う(Bukkitの getConfig() の既定値マージ相当) */
    public void mergeDefaults(Yml def) { mergeInto("", def); }
    private void mergeInto(String prefix, Yml def) {
        for (String k : def.keys()) {
            String p = prefix.isEmpty() ? k : prefix + "." + k;
            if (def.isSection(k)) mergeInto(p, def.section(k));
            else if (!contains(p)) set(p, def.get(k));
        }
    }
}
