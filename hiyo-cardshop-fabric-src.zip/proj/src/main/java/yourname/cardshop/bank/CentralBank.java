package yourname.cardshop.bank;

import yourname.cardshop.CardShopMod;
import yourname.cardshop.util.Tasks;
import yourname.cardshop.util.Yml;

public class CentralBank {
    private double totalAbsorbed;
    private boolean savePending = false;

    public CentralBank() {
        Yml y = Yml.load(CardShopMod.file("bank.yml"));
        this.totalAbsorbed = y.getDouble("total-absorbed", 0.0);
    }

    public void save() {
        if (!CardShopMod.running()) { saveNow(); return; }
        if (savePending) return;
        savePending = true;
        Tasks.later(100, () -> { savePending = false; saveNow(); });
    }

    private void saveNow() {
        Yml y = new Yml();
        y.set("total-absorbed", totalAbsorbed);
        y.saveAuto(CardShopMod.file("bank.yml"));
    }

    public void absorb(double d) {
        if (d <= 0.0) return;
        totalAbsorbed += d;
        save();
    }

    public boolean withdraw(double d) {
        if (d <= 0.0) return true;
        if (totalAbsorbed < d) return false;
        totalAbsorbed -= d;
        save();
        return true;
    }

    public double getTotalAbsorbed() { return totalAbsorbed; }
}
