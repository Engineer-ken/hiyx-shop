package yourname.cardshop.casino;

import java.security.SecureRandom;
import java.util.Set;

/** カジノの各ゲーム(サーバー側で結果を判定)。 */
final class CasinoGames {
    private static final SecureRandom R = new SecureRandom();
    private static final int[] WT = {10, 8, 6, 4, 3, 1};
    private static final int[] PAY = {5, 10, 16, 32, 65, 200};
    private static final int[] SCRATCH_P = {125, 34, 16, 3, 1};
    private static final int[] SCRATCH_M = {2, 5, 10, 50, 200};
    private static final int[] O = {0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26};
    private static final Set<Integer> RED = Set.of(1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36);

    private CasinoGames() { }

    record Res(long mult, String json) { }

    static Res play(String game, String pick) {
        try {
            switch (game) {
                case "slot": {
                    int[] r = new int[3];
                    for (int i = 0; i < 3; i++) {
                        int n = R.nextInt(32);
                        int k = 0;
                        while (n >= WT[k]) { n -= WT[k]; k++; }
                        r[i] = k;
                    }
                    long m = 0L;
                    if (r[0] == r[1] && r[1] == r[2]) m = PAY[r[0]];
                    else if ((r[0] == 0 ? 1 : 0) + (r[1] == 0 ? 1 : 0) + (r[2] == 0 ? 1 : 0) == 2) m = 2L;
                    return new Res(m, "\"r\":[" + r[0] + "," + r[1] + "," + r[2] + "]");
                }
                case "roulette": {
                    int n = O[R.nextInt(37)];
                    boolean win;
                    if (pick.startsWith("n:")) {
                        int pn = Integer.parseInt(pick.substring(2));
                        if (pn < 0 || pn > 36) return null;
                        win = n == pn;
                    } else {
                        switch (pick) {
                            case "r" -> win = RED.contains(n);
                            case "k" -> win = n != 0 && !RED.contains(n);
                            case "o" -> win = n % 2 == 1;
                            case "e" -> win = n != 0 && n % 2 == 0;
                            case "l" -> win = n >= 1 && n <= 18;
                            case "h" -> win = n >= 19;
                            default -> { return null; }
                        }
                    }
                    return new Res(win ? (pick.startsWith("n:") ? 36 : 2) : 0L, "\"n\":" + n);
                }
                case "coin": {
                    int p = Integer.parseInt(pick);
                    if (p != 0 && p != 1) return null;
                    int x = R.nextInt(80);
                    boolean edge = x < 2;
                    int face = x % 2;
                    return new Res(!edge && face == p ? 2L : 0L, "\"e\":" + edge + ",\"f\":" + face);
                }
                case "dice": {
                    int p = Integer.parseInt(pick);
                    if (p < 0 || p > 2) return null;
                    int a = 1 + R.nextInt(6), b = 1 + R.nextInt(6), c = 1 + R.nextInt(6);
                    int sum = a + b + c;
                    boolean triple = a == b && b == c;
                    long m;
                    if (p == 2) m = triple ? 34 : 0;
                    else if (triple) m = 0L;
                    else m = (p == 0 ? sum >= 11 : sum <= 10) ? 2L : 0L;
                    return new Res(m, "\"d\":[" + a + "," + b + "," + c + "]");
                }
                case "scratch": {
                    int n = R.nextInt(1000);
                    int hit = -1;
                    for (int i = 0; i < 5; i++) {
                        if (n < SCRATCH_P[i]) { hit = i; break; }
                        n -= SCRATCH_P[i];
                    }
                    return new Res(hit >= 0 ? SCRATCH_M[hit] : 0L, "\"w\":" + hit);
                }
                default:
                    return null;
            }
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
