package yourname.cardshop.casino;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Yml;

/** Webカジノ用の簡易HTTPサーバー (POST /api/start, /api/play と web/ フォルダの静的配信)。 */
public class CasinoHttp {
    private final CasinoManager m;
    private HttpServer server;

    public CasinoHttp(CasinoManager m) { this.m = m; }

    public void start() {
        Yml c = CardShopMod.cfg();
        if (!c.getBoolean("casino.http-enabled", true)) return;
        try {
            server = HttpServer.create(new InetSocketAddress(c.getInt("casino.http-port", 8123)), 32);
            server.setExecutor(Executors.newFixedThreadPool(2, r -> {
                Thread t = new Thread(r, "casino-http");
                t.setDaemon(true);
                return t;
            }));
            server.createContext("/api/", this::api);
            server.createContext("/", this::files);
            server.start();
            Mc.log("Casino HTTP: port " + c.getInt("casino.http-port", 8123));
        } catch (IOException e) { Mc.log("Casino HTTP 起動失敗: " + e.getMessage()); }
    }

    public void stop() { if (server != null) server.stop(0); }

    private void api(HttpExchange ex) throws IOException {
        try {
            ex.getResponseHeaders().set("Access-Control-Allow-Origin", CardShopMod.cfg().getString("casino.allow-origin", "*"));
            ex.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");
            if (ex.getRequestMethod().equals("OPTIONS")) { ex.sendResponseHeaders(204, -1L); return; }
            if (!ex.getRequestMethod().equals("POST")) { json(ex, 405, "{\"ok\":false,\"err\":\"bad\"}"); return; }
            byte[] body = ex.getRequestBody().readNBytes(1025);
            if (body.length > 1024) { json(ex, 413, "{\"ok\":false,\"err\":\"bad\"}"); return; }
            Map<String, String> f = form(new String(body, StandardCharsets.UTF_8));
            CasinoManager.Ticket t = m.byToken(f.getOrDefault("code", ""));
            if (t == null) { json(ex, 200, "{\"ok\":false,\"err\":\"badcode\"}"); return; }
            String path = ex.getRequestURI().getPath();
            if (path.equals("/api/start")) {
                synchronized (t) { json(ex, 200, "{\"ok\":true,\"chips\":" + t.chips + "}"); }
                return;
            }
            if (path.equals("/api/play")) json(ex, 200, play(t, f));
            else json(ex, 404, "{\"ok\":false,\"err\":\"bad\"}");
        } catch (Exception e) {
            json(ex, 500, "{\"ok\":false,\"err\":\"bad\"}");
        }
    }

    private String play(CasinoManager.Ticket t, Map<String, String> f) {
        long bet;
        try { bet = Long.parseLong(f.getOrDefault("bet", "")); } catch (NumberFormatException e) { return "{\"ok\":false,\"err\":\"bet\"}"; }
        long now = System.currentTimeMillis();
        synchronized (t) {
            if (t.closed) return "{\"ok\":false,\"err\":\"badcode\"}";
            if (now - t.lastPlay < CardShopMod.cfg().getLong("casino.min-interval-ms", 400L)) return "{\"ok\":false,\"err\":\"slow\"}";
            if (bet < 1L || bet > t.chips || bet > m.maxBet()) return "{\"ok\":false,\"err\":\"bet\"}";
            CasinoGames.Res r = CasinoGames.play(f.getOrDefault("game", ""), f.getOrDefault("pick", ""));
            if (r == null) return "{\"ok\":false,\"err\":\"bad\"}";
            t.lastPlay = now;
            t.chips = Math.min(t.chips - bet + bet * r.mult(), t.initial * m.maxMult());
            m.markDirty();
            return "{\"ok\":true,\"chips\":" + t.chips + ",\"mult\":" + r.mult() + "," + r.json() + "}";
        }
    }

    private static Map<String, String> form(String s) {
        Map<String, String> m = new HashMap<>();
        for (String kv : s.split("&")) {
            int i = kv.indexOf('=');
            if (i <= 0) continue;
            m.put(URLDecoder.decode(kv.substring(0, i), StandardCharsets.UTF_8), URLDecoder.decode(kv.substring(i + 1), StandardCharsets.UTF_8));
        }
        return m;
    }

    private static void json(HttpExchange ex, int code, String s) throws IOException {
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json");
        ex.sendResponseHeaders(code, b.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(b); }
    }

    private void files(HttpExchange ex) throws IOException {
        Path root = CardShopMod.dir().resolve("web").toAbsolutePath().normalize();
        String p = ex.getRequestURI().getPath();
        if (p.equals("/")) p = "/index.html";
        Path f = root.resolve("." + p).normalize();
        if (!f.startsWith(root) || !Files.isRegularFile(f)) { ex.sendResponseHeaders(404, -1L); return; }
        byte[] b = Files.readAllBytes(f);
        ex.getResponseHeaders().set("Content-Type", p.endsWith(".html") ? "text/html; charset=utf-8" : "application/octet-stream");
        ex.getResponseHeaders().set("Cache-Control", "no-store");
        ex.sendResponseHeaders(200, b.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(b); }
    }
}
