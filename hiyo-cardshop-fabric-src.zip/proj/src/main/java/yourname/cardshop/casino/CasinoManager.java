package yourname.cardshop.casino;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.bank.CentralBank;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Tasks;
import yourname.cardshop.util.Yml;

/** サーバー判定方式のWebカジノ(チップのデポジット/精算)。 */
public class CasinoManager {
    private final CardManager cards;
    private final CentralBank bank;
    private final SecureRandom rnd = new SecureRandom();
    private final Map<String, Ticket> byToken = new ConcurrentHashMap<>();
    private final Map<UUID, Ticket> byPlayer = new HashMap<>();
    private double houseNet;
    private final AtomicBoolean savePending = new AtomicBoolean();
    private long ver;
    private long written;

    public CasinoManager(CardManager cards, CentralBank bank) {
        this.cards = cards; this.bank = bank;
        load();
        Tasks.timer(72000, 72000, this::expire);
    }

    private static Yml cfg() { return CardShopMod.cfg(); }
    private double cv() { return Math.max(1, cfg().getInt("casino.chip-value", 100)); }
    private long minChips() { return cfg().getLong("casino.min-chips", 10L); }
    private long maxChips() { return cfg().getLong("casino.max-chips", 5000L); }
    long maxBet() { return cfg().getLong("casino.max-bet-chips", 500L); }
    long maxMult() { return cfg().getInt("casino.max-payout-multiplier", 10); }
    private long expireMs() { return cfg().getLong("casino.expire-days", 14L) * 86400000L; }
    private double alertWin() { return cfg().getDouble("casino.alert-win", 50000.0); }

    public Ticket byToken(String t) { return byToken.get(t.toLowerCase(Locale.ROOT)); }

    public void deposit(ServerPlayer p, double amount) {
        UUID id = p.getUUID();
        if (byPlayer.containsKey(id)) { Mc.msg(p, "§c未精算のチップがあります。/casino ticket で再表示、/casino redeem で精算してください。"); return; }
        double cv = cv();
        long chips = Math.round(amount / cv);
        if (amount <= 0.0 || Math.abs(chips * cv - amount) > 1.0E-9 || chips < minChips() || chips > maxChips()) {
            Mc.msg(p, "§c金額は " + (long) cv + " の倍数で " + (long) (minChips() * cv) + "〜" + (long) (maxChips() * cv) + " にしてください。");
            return;
        }
        if (!cards.removeBalance(id, amount)) { Mc.msg(p, "§c残高が足りません。"); return; }
        byte[] b = new byte[12];
        rnd.nextBytes(b);
        Ticket t = new Ticket(HexFormat.of().formatHex(b), id, chips, chips, System.currentTimeMillis());
        byToken.put(t.token, t);
        byPlayer.put(id, t);
        markDirty();
        log(Mc.name(p), "deposit", amount, 0.0);
        Mc.msg(p, "§a" + chips + "チップを発行しました。Webカジノで遊び、終わったら /casino redeem で精算します。");
        sendCode(p, t);
    }

    public void showTicket(ServerPlayer p) {
        Ticket t = byPlayer.get(p.getUUID());
        if (t == null) Mc.msg(p, "§c未精算のチップはありません。");
        else sendCode(p, t);
    }

    /** コード表示(クリックでコピー / Webカジノを開く)。元プラグインと同じ tellraw を実行 */
    private void sendCode(ServerPlayer p, Ticket t) {
        Mc.msg(p, "§6【チップコード】 " + t.token);
        String url = cfg().getString("casino.web-url", "");
        String open = url.startsWith("http")
                ? ",{\"text\":\"[カジノを開く]\",\"color\":\"green\",\"click_event\":{\"action\":\"open_url\",\"url\":\"" + url + "#c=" + t.token + "\"}}" : "";
        Mc.console("tellraw " + Mc.name(p) + " [{\"text\":\"[クリックでコピー] \",\"color\":\"yellow\",\"click_event\":{\"action\":\"copy_to_clipboard\",\"value\":\"" + t.token + "\"}}" + open + "]");
    }

    public void redeem(ServerPlayer p) {
        UUID id = p.getUUID();
        Ticket t = byPlayer.get(id);
        if (t == null) { Mc.msg(p, "§c未精算のチップはありません。"); return; }
        long chips;
        synchronized (t) {
            t.closed = true;
            chips = Math.min(t.chips, t.initial * maxMult());
        }
        double cv = cv();
        double deposit = t.initial * cv;
        double payout = chips * cv;
        double profit = payout - deposit;
        if (profit > 0.0) {
            double pay = Math.min(profit, Math.max(0.0, bank.getTotalAbsorbed()));
            if (pay > 0.0) bank.withdraw(pay);
            if (pay < profit) Mc.msg(p, "§eサーバー予算の都合で配当を一部制限しました。");
            payout = deposit + pay;
            profit = pay;
        } else if (profit < 0.0) bank.absorb(-profit);
        byPlayer.remove(id);
        byToken.remove(t.token);
        houseNet -= profit;
        if (payout > 0.0) cards.addBalanceForce(id, payout);
        markDirty();
        log(Mc.name(p), "redeem", payout, profit);
        Mc.msg(p, "§a精算しました: " + CardManager.formatMoney(payout) + "(損益 " + (profit >= 0.0 ? "+" : "") + (long) profit + ")");
        if (profit >= alertWin()) Mc.notifyAdmins("§6[Casino] " + Mc.name(p) + " が +" + (long) profit + " の大勝ち");
    }

    public String stats() {
        double held = 0.0;
        for (Ticket t : byPlayer.values()) held += t.initial * cv();
        return "未精算 " + byPlayer.size() + "枚 / 預り " + (long) held + " / カジノ累計損益(サーバー側) " + (long) houseNet + " / 中央銀行予算 " + (long) bank.getTotalAbsorbed();
    }

    private void expire() {
        long now = System.currentTimeMillis();
        long ex = expireMs();
        boolean changed = false;
        Iterator<Map.Entry<UUID, Ticket>> it = byPlayer.entrySet().iterator();
        while (it.hasNext()) {
            Ticket t = it.next().getValue();
            if (now - t.created <= ex) continue;
            synchronized (t) { t.closed = true; }
            double lost = t.initial * cv();
            bank.absorb(lost);
            houseNet += lost;
            byToken.remove(t.token);
            it.remove();
            changed = true;
        }
        if (changed) markDirty();
    }

    private void load() {
        Yml y = Yml.load(CardShopMod.file("casino.yml"));
        houseNet = y.getDouble("house-net");
        Yml ts = y.section("tickets");
        if (ts == null) return;
        for (String k : ts.keys()) {
            UUID id = UUID.fromString(k);
            Ticket t = new Ticket(y.getString("tickets." + k + ".token"), id, y.getLong("tickets." + k + ".initial"),
                    y.getLong("tickets." + k + ".chips"), y.getLong("tickets." + k + ".created"));
            byPlayer.put(id, t);
            byToken.put(t.token, t);
        }
    }

    /** どのスレッドから呼んでもよい(1秒後にまとめて保存) */
    public void markDirty() {
        if (savePending.compareAndSet(false, true)) Tasks.later(20, this::saveNow);
    }

    public void saveNow() {
        savePending.set(false);
        Yml y = new Yml();
        y.set("house-net", houseNet);
        byPlayer.forEach((id, t) -> {
            synchronized (t) {
                String k = "tickets." + id;
                y.set(k + ".token", t.token);
                y.set(k + ".initial", t.initial);
                y.set(k + ".chips", t.chips);
                y.set(k + ".created", t.created);
            }
        });
        long v = ++ver;
        Runnable w = () -> write(y, v);
        if (CardShopMod.running()) Tasks.async(w); else w.run();
    }

    private synchronized void write(Yml y, long v) {
        if (v < written) return;
        written = v;
        y.save(CardShopMod.file("casino.yml"));
    }

    private void log(String name, String kind, double a, double b) {
        String line = System.currentTimeMillis() + "," + name + "," + kind + "," + (long) a + "," + (long) b + "\n";
        Tasks.async(() -> {
            synchronized (CasinoManager.this) {
                try { Files.writeString(CardShopMod.file("casino-log.csv"), line, StandardOpenOption.CREATE, StandardOpenOption.APPEND); }
                catch (IOException ignored) { }
            }
        });
    }

    public static final class Ticket {
        final String token;
        final UUID owner;
        final long initial;
        final long created;
        long chips;
        long lastPlay;
        boolean closed;
        Ticket(String token, UUID owner, long initial, long chips, long created) {
            this.token = token; this.owner = owner; this.initial = initial; this.chips = chips; this.created = created;
        }
    }
}
