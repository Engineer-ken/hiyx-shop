package yourname.cardshop.casino;

import java.util.List;
import yourname.cardshop.util.Cmd;
import yourname.cardshop.util.Sender;

public class CasinoCommand implements Cmd {
    private final CasinoManager m;
    public CasinoCommand(CasinoManager m) { this.m = m; }

    @Override
    public boolean run(Sender s, String[] a) {
        if (a.length == 1 && a[0].equalsIgnoreCase("stats")) {
            if (!s.admin()) { s.msg("§c権限がありません。"); return true; }
            s.msg("§6[Casino] " + m.stats());
            return true;
        }
        if (!s.isPlayer()) { s.msg("プレイヤー専用です。"); return true; }
        if (a.length == 2 && a[0].equalsIgnoreCase("deposit")) {
            try { m.deposit(s.player(), Double.parseDouble(a[1])); }
            catch (NumberFormatException e) { s.msg("§c金額は数字で指定してください。"); }
        } else if (a.length >= 1 && a[0].equalsIgnoreCase("redeem")) m.redeem(s.player());
        else if (a.length == 1 && a[0].equalsIgnoreCase("ticket")) m.showTicket(s.player());
        else s.msg("§e/casino deposit <金額> | redeem | ticket");
        return true;
    }

    @Override
    public List<String> tab(Sender s, String[] a) { return a.length == 1 ? List.of("deposit", "redeem", "ticket", "stats") : List.of(); }
}
