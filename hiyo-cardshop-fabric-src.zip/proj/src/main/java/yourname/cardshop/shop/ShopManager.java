package yourname.cardshop.shop;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Yml;

/** プレイヤー間ショップ(/shop)。 */
public class ShopManager {
    private final CardManager cardManager;
    private final Map<UUID, ShopListing> listings = new LinkedHashMap<>();

    public ShopManager(CardManager cardManager) { this.cardManager = cardManager; load(); }

    public SellResult sell(ServerPlayer seller, double pricePerUnit, int amount) {
        if (pricePerUnit <= 0.0 || amount <= 0) return SellResult.INVALID_PRICE;
        ItemStack hand = Mc.hand(seller);
        if (hand.isEmpty()) return SellResult.NOT_ENOUGH_ITEMS;
        if (cardManager.isCardItem(hand)) return SellResult.CARD_ITEM_NOT_SELLABLE;
        ItemStack template = hand.copyWithCount(1);
        int owned = Mc.count(seller, s -> Mc.same(s, template));
        if (owned < amount) return SellResult.NOT_ENOUGH_ITEMS;
        Mc.take(seller, s -> Mc.same(s, template), amount);
        UUID id = UUID.randomUUID();
        listings.put(id, new ShopListing(id, seller.getUUID(), Mc.name(seller), template, amount, pricePerUnit));
        saveAll();
        return SellResult.OK;
    }

    public BuyResult buy(ServerPlayer buyer, UUID listingId, int amount) {
        ShopListing l = listings.get(listingId);
        if (l == null) return BuyResult.NOT_FOUND;
        if (l.getSellerUuid().equals(buyer.getUUID())) return BuyResult.CANNOT_BUY_OWN;
        if (amount <= 0 || amount > l.getAmount()) return BuyResult.NOT_ENOUGH_STOCK;
        double total = l.getPricePerUnit() * amount;
        if (cardManager.getBalance(buyer.getUUID()) < total) return BuyResult.NOT_ENOUGH_BALANCE;
        ItemStack give = l.getItemTemplate().copyWithCount(amount);
        if (!Mc.canFit(buyer, give)) return BuyResult.INVENTORY_FULL;
        cardManager.removeBalance(buyer.getUUID(), total);
        cardManager.addBalance(l.getSellerUuid(), total);
        Mc.give(buyer, give);
        l.setAmount(l.getAmount() - amount);
        if (l.getAmount() <= 0) listings.remove(listingId);
        saveAll();
        return BuyResult.OK;
    }

    public CancelResult cancel(ServerPlayer player, UUID listingId) {
        ShopListing l = listings.get(listingId);
        if (l == null) return CancelResult.NOT_FOUND;
        if (!l.getSellerUuid().equals(player.getUUID())) return CancelResult.NOT_OWNER;
        Mc.give(player, l.getItemTemplate().copyWithCount(l.getAmount()));
        listings.remove(listingId);
        saveAll();
        return CancelResult.OK;
    }

    public List<ShopListing> getAllListings() { return new ArrayList<>(listings.values()); }
    public List<ShopListing> getListingsBySeller(UUID seller) {
        List<ShopListing> r = new ArrayList<>();
        for (ShopListing l : listings.values()) if (l.getSellerUuid().equals(seller)) r.add(l);
        return r;
    }
    public ShopListing findByShortId(String shortId) {
        for (ShopListing l : listings.values()) if (l.getId().toString().startsWith(shortId)) return l;
        return null;
    }
    public ShopListing getById(UUID id) { return listings.get(id); }

    /** アイテム情報は専用形式(JSON)で保存。旧プラグイン(Bukkit形式)の出品は読み込めないためスキップ */
    public void load() {
        Yml y = Yml.load(CardShopMod.file("shop.yml"));
        for (String key : y.keys()) {
            try {
                UUID id = UUID.fromString(key);
                Object item = y.get(key + ".item");
                if (!(item instanceof String json)) { Mc.log("shop.yml: 旧形式の出品はスキップ(" + key + ")"); continue; }
                ItemStack t = Mc.dec(json);
                if (t.isEmpty()) continue;
                listings.put(id, new ShopListing(id, UUID.fromString(y.getString(key + ".seller-uuid")), y.getString(key + ".seller-name"),
                        t, y.getInt(key + ".amount"), y.getDouble(key + ".price")));
            } catch (Exception e) { Mc.log("shop.yml の読み込みでエラー: " + e.getMessage()); }
        }
    }

    public void saveAll() {
        Yml y = new Yml();
        for (ShopListing l : listings.values()) {
            String p = l.getId() + ".";
            y.set(p + "seller-uuid", l.getSellerUuid().toString());
            y.set(p + "seller-name", l.getSellerName());
            y.set(p + "item", Mc.enc(l.getItemTemplate()));
            y.set(p + "amount", l.getAmount());
            y.set(p + "price", l.getPricePerUnit());
        }
        y.save(CardShopMod.file("shop.yml"));
    }

    public enum SellResult { OK, NOT_ENOUGH_ITEMS, CARD_ITEM_NOT_SELLABLE, INVALID_PRICE }
    public enum BuyResult { OK, NOT_FOUND, NOT_ENOUGH_STOCK, NOT_ENOUGH_BALANCE, INVENTORY_FULL, CANNOT_BUY_OWN }
    public enum CancelResult { OK, NOT_FOUND, NOT_OWNER, INVENTORY_FULL }
}
