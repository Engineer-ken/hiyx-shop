package yourname.cardshop.shop;

import java.util.UUID;
import net.minecraft.world.item.ItemStack;

public class ShopListing {
    private final UUID id;
    private final UUID sellerUuid;
    private final String sellerName;
    private final ItemStack itemTemplate;
    private int amount;
    private final double pricePerUnit;

    public ShopListing(UUID id, UUID sellerUuid, String sellerName, ItemStack itemTemplate, int amount, double pricePerUnit) {
        this.id = id; this.sellerUuid = sellerUuid; this.sellerName = sellerName;
        this.itemTemplate = itemTemplate; this.amount = amount; this.pricePerUnit = pricePerUnit;
    }
    public UUID getId() { return id; }
    public UUID getSellerUuid() { return sellerUuid; }
    public String getSellerName() { return sellerName; }
    public ItemStack getItemTemplate() { return itemTemplate; }
    public int getAmount() { return amount; }
    public void setAmount(int amount) { this.amount = amount; }
    public double getPricePerUnit() { return pricePerUnit; }
}
