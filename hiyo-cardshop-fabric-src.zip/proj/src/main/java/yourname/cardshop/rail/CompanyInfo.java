package yourname.cardshop.rail;

public class CompanyInfo {
    public final String name;
    public final char code;
    public final double farePerSegment;
    public final String ownerName;
    public final double dailyVirtualIncome;

    public CompanyInfo(String name, char code, double farePerSegment, String ownerName, double dailyVirtualIncome) {
        this.name = name; this.code = code; this.farePerSegment = farePerSegment;
        this.ownerName = ownerName; this.dailyVirtualIncome = dailyVirtualIncome;
    }
}
