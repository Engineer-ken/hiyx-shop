package yourname.cardshop.rail;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.util.Mc;

/** train/company.txt (会社名:代表文字:1区間運賃:オーナー名:1日あたりの仮想収入) */
public class CompanyRegistry {
    private final Path file;
    private final Map<Character, CompanyInfo> byCode = new HashMap<>();

    public CompanyRegistry() {
        Path dir = CardShopMod.dir().resolve("train");
        try { Files.createDirectories(dir); } catch (IOException ignored) { }
        this.file = dir.resolve("company.txt");
        ensureDefaultFile();
        reload();
    }

    private void ensureDefaultFile() {
        if (Files.exists(file)) return;
        try {
            Files.writeString(file, "# 会社名:代表文字:1区間運賃:オーナー名:1日あたりの仮想収入(省略可)\nK鉄:K:100:owner1:0\n蹄鉄:蹄:80:owner2:0\n渡辺急行:渡:110:owner3:0\n", StandardCharsets.UTF_8);
        } catch (IOException e) { Mc.log("company.txt の初期作成に失敗: " + e.getMessage()); }
    }

    public void reload() {
        byCode.clear();
        try {
            List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
            for (String line : lines) {
                String t = line.trim();
                if (t.isEmpty() || t.startsWith("#")) continue;
                String[] parts = t.split(":");
                if (parts.length < 4) continue;
                String name = parts[0];
                char code = parts[1].charAt(0);
                double fare;
                try { fare = Double.parseDouble(parts[2]); } catch (NumberFormatException e) { continue; }
                String owner = parts[3];
                double daily = 0.0;
                if (parts.length >= 5) { try { daily = Double.parseDouble(parts[4]); } catch (NumberFormatException ignored) { } }
                byCode.put(code, new CompanyInfo(name, code, fare, owner, daily));
            }
        } catch (IOException e) { Mc.log("company.txt の読み込みに失敗: " + e.getMessage()); }
    }

    public CompanyInfo getByCode(char code) { return byCode.get(code); }
    public Collection<CompanyInfo> getAll() { return byCode.values(); }

    public void addOrUpdate(String name, char code, double fare, String ownerName, double daily) {
        byCode.put(code, new CompanyInfo(name, code, fare, ownerName, daily));
        save();
    }
    public boolean setDailyIncome(char code, double daily) {
        CompanyInfo o = byCode.get(code);
        if (o == null) return false;
        byCode.put(code, new CompanyInfo(o.name, o.code, o.farePerSegment, o.ownerName, daily));
        save();
        return true;
    }
    public boolean remove(char code) {
        boolean r = byCode.remove(code) != null;
        if (r) save();
        return r;
    }
    public void save() {
        StringBuilder sb = new StringBuilder("# 会社名:代表文字:1区間運賃:オーナー名:1日あたりの仮想収入\n");
        for (CompanyInfo i : byCode.values())
            sb.append(i.name).append(":").append(i.code).append(":").append(i.farePerSegment).append(":").append(i.ownerName).append(":").append(i.dailyVirtualIncome).append("\n");
        try { Files.writeString(file, sb.toString(), StandardCharsets.UTF_8); }
        catch (IOException e) { Mc.log("company.txt の保存に失敗: " + e.getMessage()); }
    }
}
