package yourname.cardshop.rail;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.util.Mc;

/** オーナー名 → UUID。オンライン/キャッシュに無ければBukkit同様のオフラインUUIDを返す。 */
public final class OwnerResolver {
    private static final Map<String, UUID> CACHE = new ConcurrentHashMap<>();
    private OwnerResolver() { }

    public static UUID resolve(String name) {
        if (name == null) return UUID.nameUUIDFromBytes("OfflinePlayer:".getBytes(StandardCharsets.UTF_8));
        String key = name.toLowerCase();
        UUID c = CACHE.get(key);
        if (c != null) return c;
        UUID u = Mc.uuidOf(name);
        if (u == null) u = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
        CACHE.put(key, u);
        return u;
    }
    public static void remember(ServerPlayer p) { CACHE.put(Mc.name(p).toLowerCase(), p.getUUID()); }
}
