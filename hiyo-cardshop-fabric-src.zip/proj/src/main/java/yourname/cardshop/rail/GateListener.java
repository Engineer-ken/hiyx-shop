package yourname.cardshop.rail;

import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.decoration.Mannequin;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.entry.EntryNpcManager;
import yourname.cardshop.shopkeeper.ShopkeeperManager;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Tasks;

/** 改札(フェンスゲート)・入場料ゲートの処理。ゲートNPCの半径3マス以内のゲートはすべて改札口で、CARDで決済しないと開かない。 */
public class GateListener {
    private static final double GATE_RADIUS = 3.0;
    private static final double ENTRY_RADIUS = 2.0;
    private static final int AUTO_CLOSE_TICKS = 60;

    private final StationTracker stationTracker;
    private final CompanyRegistry companyRegistry;
    private final CardManager cardManager;
    private final ShopkeeperManager shopkeeperManager;
    private final EntryNpcManager entryNpcManager;
    private final CompanyIncomeManager companyIncomeManager;

    public GateListener(StationTracker st, CompanyRegistry cr, CardManager cm, ShopkeeperManager sm, EntryNpcManager em, CompanyIncomeManager ci) {
        this.stationTracker = st; this.companyRegistry = cr; this.cardManager = cm;
        this.shopkeeperManager = sm; this.entryNpcManager = em; this.companyIncomeManager = ci;
    }

    private static boolean isGate(BlockState s) { return Mc.blockId(s).endsWith("fence_gate"); }

    public void register() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (level.isClientSide() || hand != InteractionHand.MAIN_HAND || !(player instanceof ServerPlayer sp)) return InteractionResult.PASS;
            return onInteract(sp, (ServerLevel) level, hit.getBlockPos());
        });
        PlayerBlockBreakEvents.BEFORE.register((level, player, pos, state, be) -> {
            if (level.isClientSide() || !(player instanceof ServerPlayer sp)) return true;
            return !shouldBlockBreak(sp, (ServerLevel) level, pos, state);
        });
    }

    private InteractionResult onInteract(ServerPlayer player, ServerLevel level, BlockPos pos) {
        if (!isGate(level.getBlockState(pos))) return InteractionResult.PASS;

        Mannequin entryNpc = findNearbyEntryNpc(level, pos);
        if (entryNpc != null) { handleEntryGate(player, level, pos, entryNpc); return InteractionResult.FAIL; }

        // 改札: ゲートNPCの近くのゲートは、CARDで決済しないと開かない
        if (!nearGateNpc(level, pos)) return InteractionResult.PASS;
        if (!holdingCard(player)) {
            Mc.msg(player, "§c運賃が未払いです。CARDを持った状態でゲートを開けてください。");
            return InteractionResult.FAIL;
        }
        if (settle(player)) openThenAutoClose(level, pos);
        return InteractionResult.FAIL;
    }

    private boolean holdingCard(ServerPlayer p) {
        return cardManager.isCardItem(p.getMainHandItem()) || cardManager.isCardItem(p.getOffhandItem());
    }

    private boolean nearGateNpc(ServerLevel level, BlockPos pos) {
        for (Mannequin m : Mc.mannequinsNear(level, pos, GATE_RADIUS)) if (shopkeeperManager.isGateNpc(m)) return true;
        return false;
    }

    private Mannequin findNearbyEntryNpc(ServerLevel level, BlockPos pos) {
        if (entryNpcManager.isEmpty()) return null; // 入場料NPCが1体も無ければ検索しない(軽量化)
        for (Mannequin m : Mc.mannequinsNear(level, pos, ENTRY_RADIUS)) if (entryNpcManager.isEntryNpc(m)) return m;
        return null;
    }

    private void handleEntryGate(ServerPlayer player, ServerLevel level, BlockPos pos, Mannequin npc) {
        Double fee = entryNpcManager.getFee(npc.getUUID());
        if (fee == null || fee <= 0.0) { openThenAutoClose(level, pos); return; }
        if (!holdingCard(player)) { Mc.msg(player, "§c入場料(" + fee + "円)が未払いです。CARDを持った状態でゲートを開けてください。"); return; }
        if (!cardManager.removeBalance(player.getUUID(), fee)) { Mc.msg(player, "§c入場料(" + fee + "円)の残高が不足しています。"); return; }
        UUID owner = entryNpcManager.getOwner(npc.getUUID());
        if (owner != null) cardManager.addBalance(owner, fee);
        Mc.msg(player, "§a入場料 " + fee + "円 を支払いました。");
        openThenAutoClose(level, pos);
    }

    private boolean shouldBlockBreak(ServerPlayer player, ServerLevel level, BlockPos pos, BlockState state) {
        if (!isGate(state)) return false;
        boolean nearAnyNpc = findNearbyEntryNpc(level, pos) != null;
        if (!nearAnyNpc) {
            if (stationTracker.getLedger(player.getUUID()).isEmpty()) return false;
            if (!nearGateNpc(level, pos)) return false;
        }
        Mc.msg(player, "§c支払いが未完了です。ゲートを壊して回避することはできません。");
        return true;
    }

    private void openThenAutoClose(ServerLevel level, BlockPos pos) {
        BlockState st = level.getBlockState(pos);
        if (st.hasProperty(BlockStateProperties.OPEN)) level.setBlock(pos, st.setValue(BlockStateProperties.OPEN, true), 3);
        Tasks.later(AUTO_CLOSE_TICKS, () -> {
            BlockState cur = level.getBlockState(pos);
            if (cur.hasProperty(BlockStateProperties.OPEN) && cur.getValue(BlockStateProperties.OPEN))
                level.setBlock(pos, cur.setValue(BlockStateProperties.OPEN, false), 3);
        });
    }

    /** 溜まった運賃を決済して、会社オーナーへ入金。成功(または運賃なし)なら true */
    private boolean settle(ServerPlayer player) {
        Map<Character, Integer> ledger = stationTracker.getLedger(player.getUUID());
        if (ledger.isEmpty()) return true;
        double total = 0.0;
        StringBuilder detail = new StringBuilder();
        for (Map.Entry<Character, Integer> e : ledger.entrySet()) {
            CompanyInfo c = companyRegistry.getByCode(e.getKey());
            if (c == null) continue;
            double fare = c.farePerSegment * e.getValue();
            total += fare;
            detail.append(c.name).append(" ").append(e.getValue()).append("区間 ").append(fare).append("円  ");
        }
        if (total <= 0.0) { stationTracker.clearLedger(player.getUUID()); return true; }
        if (!cardManager.removeBalance(player.getUUID(), total)) {
            Mc.msg(player, "§c運賃(" + total + "円)の残高が不足しています。改札を通れません。");
            return false;
        }
        for (Map.Entry<Character, Integer> e : ledger.entrySet()) {
            CompanyInfo c = companyRegistry.getByCode(e.getKey());
            if (c == null) continue;
            double fare = c.farePerSegment * e.getValue();
            cardManager.addBalance(OwnerResolver.resolve(c.ownerName), fare);
            companyIncomeManager.addPendingRealIncome(c.code, fare);
        }
        stationTracker.clearLedger(player.getUUID());
        Mc.msg(player, "§a運賃 合計" + total + "円 を支払いました。 (" + detail + ")");
        return true;
    }
}
