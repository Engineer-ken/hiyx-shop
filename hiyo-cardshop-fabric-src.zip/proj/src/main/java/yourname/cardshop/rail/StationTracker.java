package yourname.cardshop.rail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Pos;

/**
 * 駅(看板の1文字目=会社コード + 隣接ノートブロック)の登録と、乗り物が駅を通過した回数の記録。
 * 元: ChunkLoad/SignChange/BlockBreak/VehicleMove イベント → ここではチャンク読込 + 周辺の定期走査 + 乗車中のtick確認。
 */
public class StationTracker {
    private static final long COUNT_COOLDOWN_MS = 3000L;
    private static final Direction[] FACES = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP, Direction.DOWN};

    private final Map<Pos, Character> stations = new ConcurrentHashMap<>();
    private final Map<UUID, Map<Character, Integer>> rideLedger = new ConcurrentHashMap<>();
    private final Map<String, Long> recentlyCounted = new ConcurrentHashMap<>();
    private final Map<ChunkKey, List<Pos>> byChunk = new ConcurrentHashMap<>();
    private final Map<UUID, double[]> lastVehicle = new HashMap<>();
    private record ChunkKey(String world, int cx, int cz) { }

    private static ChunkKey keyOf(Pos p) { return new ChunkKey(p.world(), p.x() >> 4, p.z() >> 4); }

    private void putStation(Pos p, char c) {
        Character old = stations.put(p, c);
        if (old == null) byChunk.computeIfAbsent(keyOf(p), k -> new CopyOnWriteArrayList<>()).add(p);
    }
    private void removeStation(Pos p) {
        if (stations.remove(p) == null) return;
        ChunkKey k = keyOf(p);
        List<Pos> l = byChunk.get(k);
        if (l != null) { l.remove(p); if (l.isEmpty()) byChunk.remove(k, l); }
    }

    public void register() {
        ServerChunkEvents.CHUNK_LOAD.register((level, chunk, generated) -> pending.add(new Object[] {level, chunk}));
        // 看板の編集イベントが無いので、看板を置く/触った時だけ、少し後に周辺を確認する(普段は何もしない)
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (!level.isClientSide() && hand == InteractionHand.MAIN_HAND && player instanceof ServerPlayer sp) {
                if (Mc.itemName(sp.getMainHandItem()).contains("SIGN") || Mc.blockId(level.getBlockState(hit.getBlockPos())).contains("sign")) watch(sp);
            }
            return InteractionResult.PASS;
        });
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, be) -> {
            if (!(level instanceof ServerLevel sl)) return;
            String w = Mc.worldName(sl);
            if (state.is(Blocks.NOTE_BLOCK)) removeStation(new Pos(w, pos.getX(), pos.getY(), pos.getZ()));
            else if (Mc.blockId(state).contains("sign")) {
                for (Direction d : FACES) {
                    BlockPos n = pos.relative(d);
                    if (sl.getBlockState(n).is(Blocks.NOTE_BLOCK)) removeStation(new Pos(w, n.getX(), n.getY(), n.getZ()));
                }
            }
        });
    }

    // ---- 看板の読み取り ----
    private void scanChunk(ServerLevel level, LevelChunk chunk) {
        for (Map.Entry<BlockPos, BlockEntity> e : chunk.getBlockEntities().entrySet()) {
            if (e.getValue() instanceof SignBlockEntity sign) registerFromSign(level, e.getKey(), sign);
        }
    }

    /** チャンク読み込み直後に重い処理をしないよう、いったん溜めて1tickに最大3チャンクずつ確認する */
    private final java.util.ArrayDeque<Object[]> pending = new java.util.ArrayDeque<>();

    public void processPending() {
        if (pending.isEmpty()) return;
        long end = System.nanoTime() + 1_000_000L; // 1tickあたり約1msまで
        do {
            Object[] a = pending.poll();
            if (a == null) return;
            try { scanChunk((ServerLevel) a[0], (LevelChunk) a[1]); } catch (Throwable ignored) { }
        } while (System.nanoTime() < end);
    }

    private final Map<UUID, Long> lastWatch = new HashMap<>();

    private void watch(ServerPlayer p) {
        UUID id = p.getUUID();
        long now = System.currentTimeMillis();
        Long last = lastWatch.get(id);
        if (last != null && now - last < 2000L) return;
        lastWatch.put(id, now);
        for (int d : new int[] {60, 200, 500}) {
            yourname.cardshop.util.Tasks.later(d, () -> { ServerPlayer pl = Mc.player(id); if (pl != null) scanAround(pl); });
        }
    }

    public void forget(UUID id) { lastWatch.remove(id); }

    /** プレイヤー周辺(3x3チャンク)の看板を確認して登録 */
    public void scanAround(ServerPlayer p) {
        ServerLevel level = (ServerLevel) p.level();
        int cx = p.blockPosition().getX() >> 4, cz = p.blockPosition().getZ() >> 4;
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
            LevelChunk c = level.getChunkSource().getChunkNow(cx + dx, cz + dz);
            if (c != null) scanChunk(level, c);
        }
    }

    private void registerFromSign(ServerLevel level, BlockPos pos, SignBlockEntity sign) {
        Character c = firstCharOf(Mc.signLines(sign, true));
        if (c == null) c = firstCharOf(Mc.signLines(sign, false));
        if (c == null) return;
        for (Direction d : FACES) {
            BlockPos n = pos.relative(d);
            if (level.getBlockState(n).is(Blocks.NOTE_BLOCK)) {
                putStation(new Pos(Mc.worldName(level), n.getX(), n.getY(), n.getZ()), c);
                return;
            }
        }
    }

    private Character firstCharOf(String[] lines) {
        for (String l : lines) {
            String s = l == null ? "" : l;
            if (s.isBlank()) continue;
            return s.trim().charAt(0);
        }
        return null;
    }

    // ---- 通過判定(乗り物に乗っているプレイヤーがいるときだけ。同じブロック内の移動は無視) ----
    public void tickVehicles(List<ServerPlayer> players) {
        if (stations.isEmpty()) { if (!lastVehicle.isEmpty()) lastVehicle.clear(); return; }
        Set<UUID> seen = null;
        for (ServerPlayer p : players) {
            Entity v = p.getVehicle();
            if (v == null) continue;
            if (seen == null) seen = new HashSet<>();
            UUID vid = v.getUUID();
            if (!seen.add(vid)) continue;
            double x = v.getX(), y = v.getY(), z = v.getZ();
            double[] prev = lastVehicle.get(vid);
            if (prev == null) { lastVehicle.put(vid, new double[] {x, y, z}); continue; }
            double px = prev[0], py = prev[1], pz = prev[2];
            prev[0] = x; prev[1] = y; prev[2] = z;
            if ((int) Math.floor(px) == (int) Math.floor(x) && (int) Math.floor(pz) == (int) Math.floor(z)
                    && (int) Math.floor(py) == (int) Math.floor(y)) continue;
            List<ServerPlayer> riders = new ArrayList<>(2);
            for (Entity e : v.getPassengers()) if (e instanceof ServerPlayer sp) riders.add(sp);
            if (!riders.isEmpty()) check(Mc.worldName(v.level()), new double[] {px, py, pz}, new double[] {x, y, z}, riders);
        }
        if (seen == null) { if (!lastVehicle.isEmpty()) lastVehicle.clear(); }
        else if (lastVehicle.size() > seen.size()) lastVehicle.keySet().retainAll(seen);
    }

    private void check(String world, double[] from, double[] to, List<ServerPlayer> riders) {
        int fx = (int) Math.floor(from[0]), fz = (int) Math.floor(from[2]);
        int tx = (int) Math.floor(to[0]), tz = (int) Math.floor(to[2]);
        int minCx = Math.min(fx, tx) >> 4, maxCx = Math.max(fx, tx) >> 4;
        int minCz = Math.min(fz, tz) >> 4, maxCz = Math.max(fz, tz) >> 4;
        for (int cx = minCx; cx <= maxCx; cx++) for (int cz = minCz; cz <= maxCz; cz++) {
            List<Pos> list = byChunk.get(new ChunkKey(world, cx, cz));
            if (list == null) continue;
            for (Pos st : list) {
                Character c = stations.get(st);
                if (c == null || !passing(st, fx, fz, tx, tz, to[1])) continue;
                for (ServerPlayer pl : riders) {
                    String key = pl.getUUID() + "@" + st.x() + "," + st.y() + "," + st.z();
                    long now = System.currentTimeMillis();
                    Long last = recentlyCounted.get(key);
                    if (last != null && now - last < COUNT_COOLDOWN_MS) continue;
                    if (recentlyCounted.size() > 512) recentlyCounted.values().removeIf(t -> now - t >= COUNT_COOLDOWN_MS);
                    recentlyCounted.put(key, now);
                    addRide(pl.getUUID(), c);
                }
            }
        }
    }

    private boolean passing(Pos st, int fx, int fz, int tx, int tz, double toY) {
        int minX = Math.min(fx, tx), maxX = Math.max(fx, tx), minZ = Math.min(fz, tz), maxZ = Math.max(fz, tz);
        if (st.x() < minX || st.x() > maxX || st.z() < minZ || st.z() > maxZ) return false;
        return toY >= st.y() && toY <= st.y() + 2.0;
    }

    private void addRide(UUID u, char c) { rideLedger.computeIfAbsent(u, k -> new HashMap<>()).merge(c, 1, Integer::sum); }
    public Map<Character, Integer> getLedger(UUID u) { return rideLedger.getOrDefault(u, Map.of()); }
    public void clearLedger(UUID u) { rideLedger.remove(u); }
}
