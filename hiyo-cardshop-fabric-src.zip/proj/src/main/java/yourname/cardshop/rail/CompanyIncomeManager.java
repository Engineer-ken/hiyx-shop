package yourname.cardshop.rail;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Tasks;
import yourname.cardshop.util.Yml;

/** 鉄道会社オーナーのログイン時収入(仮想収入+運賃の実収入)。 */
public class CompanyIncomeManager {
    private final CompanyRegistry companyRegistry;
    private final CardManager cardManager;
    private final Map<UUID, Long> lastLogoutMillis = new HashMap<>();
    private final Map<Character, Double> pendingRealIncome = new HashMap<>();
    private boolean savePending = false;

    public CompanyIncomeManager(CompanyRegistry companyRegistry, CardManager cardManager) {
        this.companyRegistry = companyRegistry;
        this.cardManager = cardManager;
        load();
    }

    public void addPendingRealIncome(char c, double d) {
        if (d <= 0.0) return;
        pendingRealIncome.merge(c, d, Double::sum);
        save();
    }

    public void recordLogout(UUID u) { lastLogoutMillis.put(u, System.currentTimeMillis()); save(); }

    public void processLogin(ServerPlayer player) {
        long now = System.currentTimeMillis();
        Long last = lastLogoutMillis.get(player.getUUID());
        boolean changed = false;
        for (CompanyInfo c : companyRegistry.getAll()) {
            if (!c.ownerName.equalsIgnoreCase(Mc.name(player))) continue;
            UUID id = player.getUUID();
            double virt = 0.0;
            if (last != null && c.dailyVirtualIncome > 0.0) virt = ((double) (now - last) / 8.64E7) * c.dailyVirtualIncome;
            double real = pendingRealIncome.getOrDefault(c.code, 0.0);
            double total = virt + real;
            if (total <= 0.01) continue;
            boolean ok = cardManager.addBalance(id, total);
            String v = String.format("%.1f", virt), r = String.format("%.1f", real), t = String.format("%.1f", total);
            if (ok) Mc.msg(player, "§6[鉄道収入] §f" + c.name + " §7からの収入: 仮想収入 " + v + "円 + 実収入 " + r + "円 = §a合計 " + t + "円 §7が振り込まれました。");
            else Mc.msg(player, "§6[鉄道収入] §f" + c.name + " §7からの収入(合計 " + t + "円)が発生しましたが、残高上限のため振り込めませんでした。");
            Mc.log("[鉄道収入] " + Mc.name(player) + " / " + c.name + " (代表文字:" + c.code + ") 仮想収入=" + v + "円 実収入=" + r + "円 合計=" + t + "円 振込=" + ok);
            pendingRealIncome.remove(c.code);
            changed = true;
        }
        if (changed) save();
    }

    private void load() {
        Yml y = Yml.load(CardShopMod.file("companyincome.yml"));
        Yml lo = y.section("last-logout");
        if (lo != null) for (String k : lo.keys()) {
            try { lastLogoutMillis.put(UUID.fromString(k), y.getLong("last-logout." + k)); }
            catch (Exception e) { Mc.log("companyincome.yml(last-logout) 読み込みエラー(" + k + "): " + e.getMessage()); }
        }
        Yml pr = y.section("pending-real-income");
        if (pr != null) for (String k : pr.keys()) {
            try { pendingRealIncome.put(k.charAt(0), y.getDouble("pending-real-income." + k)); }
            catch (Exception e) { Mc.log("companyincome.yml(pending-real-income) 読み込みエラー(" + k + "): " + e.getMessage()); }
        }
    }

    public void save() {
        if (!CardShopMod.running()) { saveNow(); return; }
        if (savePending) return;
        savePending = true;
        Tasks.later(100, () -> { savePending = false; saveNow(); });
    }

    public void saveNow() {
        Yml y = new Yml();
        Map<String, Object> lo = new java.util.LinkedHashMap<>();
        for (Map.Entry<UUID, Long> e : lastLogoutMillis.entrySet()) lo.put(e.getKey().toString(), e.getValue());
        Map<String, Object> pr = new java.util.LinkedHashMap<>();
        for (Map.Entry<Character, Double> e : pendingRealIncome.entrySet()) pr.put(String.valueOf(e.getKey()), e.getValue());
        if (!lo.isEmpty()) y.set("last-logout", lo);
        if (!pr.isEmpty()) y.set("pending-real-income", pr);
        y.saveAuto(CardShopMod.file("companyincome.yml"));
    }
}
