package yourname.cardshop.rail;

import java.util.List;
import yourname.cardshop.command.CardTab;
import yourname.cardshop.util.Cmd;
import yourname.cardshop.util.Sender;

public class CompanyCommand implements Cmd {
    private final CompanyRegistry registry;
    public CompanyCommand(CompanyRegistry registry) { this.registry = registry; }

    @Override
    public boolean run(Sender s, String[] a) {
        if (!s.admin()) { s.msg("§c権限がありません。"); return true; }
        if (a.length == 0) { s.msg("§c使い方: /company <add|setincome|remove|list> ..."); return true; }
        switch (a[0].toLowerCase()) {
            case "add" -> {
                if (a.length < 5) { s.msg("§c使い方: /company add <名前> <代表文字> <運賃> <オーナー名> [1日あたり仮想収入]"); return true; }
                double fare;
                try { fare = Double.parseDouble(a[3]); } catch (NumberFormatException e) { s.msg("§c運賃は数値で指定してください。"); return true; }
                double daily = 0.0;
                if (a.length >= 6) {
                    try { daily = Double.parseDouble(a[5]); } catch (NumberFormatException e) { s.msg("§c仮想収入は数値で指定してください。"); return true; }
                }
                registry.addOrUpdate(a[1], a[2].charAt(0), fare, a[4], daily);
                s.msg("§a鉄道会社「" + a[1] + "」(" + a[2] + ")を登録しました。運賃: " + fare + "円 オーナー: " + a[4] + " 仮想収入: " + daily + "円/日");
            }
            case "setincome" -> {
                if (a.length < 3) { s.msg("§c使い方: /company setincome <代表文字> <1日あたり仮想収入>"); return true; }
                double daily;
                try { daily = Double.parseDouble(a[2]); } catch (NumberFormatException e) { s.msg("§c数値で指定してください。"); return true; }
                s.msg(registry.setDailyIncome(a[1].charAt(0), daily) ? "§a仮想収入を " + daily + "円/日 に設定しました。" : "§cその代表文字の会社は見つかりませんでした。");
            }
            case "remove" -> {
                if (a.length < 2) { s.msg("§c使い方: /company remove <代表文字>"); return true; }
                s.msg(registry.remove(a[1].charAt(0)) ? "§a削除しました。" : "§cその代表文字の会社は見つかりませんでした。");
            }
            case "list" -> {
                s.msg("§6==== 鉄道会社一覧 ====");
                for (CompanyInfo i : registry.getAll())
                    s.msg("§f[" + i.code + "] " + i.name + " §7- 運賃" + i.farePerSegment + "円 オーナー:" + i.ownerName + " 仮想収入:" + i.dailyVirtualIncome + "円/日");
            }
            default -> s.msg("§c不明なサブコマンドです。");
        }
        return true;
    }

    @Override
    public List<String> tab(Sender s, String[] a) { return CardTab.company(s, a); }
}
