package yourname.cardshop.entry;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.world.entity.Entity;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Yml;

public class EntryNpcManager {
    private final Map<UUID, Double> fees = new HashMap<>();
    private final Map<UUID, UUID> owners = new HashMap<>();

    public EntryNpcManager() { load(); }

    public void register(UUID npc, UUID owner, double fee) { owners.put(npc, owner); fees.put(npc, fee); save(); }
    public boolean setFee(UUID npc, UUID requester, double fee) {
        UUID owner = owners.get(npc);
        if (owner == null || !owner.equals(requester)) return false;
        fees.put(npc, fee);
        save();
        return true;
    }
    public boolean isEntryNpc(Entity e) { return owners.containsKey(e.getUUID()); }
    public Double getFee(UUID npc) { return fees.get(npc); }
    public UUID getOwner(UUID npc) { return owners.get(npc); }

    private void load() {
        Yml y = Yml.load(CardShopMod.file("entrynpcs.yml"));
        for (String key : y.keys()) {
            try {
                UUID id = UUID.fromString(key);
                owners.put(id, UUID.fromString(y.getString(key + ".owner")));
                fees.put(id, y.getDouble(key + ".fee"));
            } catch (Exception e) { Mc.log("entrynpcs.yml 読み込みエラー(" + key + "): " + e.getMessage()); }
        }
    }
    public void save() {
        Yml y = new Yml();
        for (UUID id : owners.keySet()) {
            y.set(id + ".owner", owners.get(id).toString());
            y.set(id + ".fee", fees.getOrDefault(id, 0.0));
        }
        y.save(CardShopMod.file("entrynpcs.yml"));
    }
}
