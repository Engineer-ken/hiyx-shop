package yourname.cardshop.entry;

import java.util.List;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.decoration.Mannequin;
import yourname.cardshop.command.CardTab;
import yourname.cardshop.util.Cmd;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Sender;

public class EntryNpcCommand implements Cmd {
    private final EntryNpcManager entries;

    public EntryNpcCommand(EntryNpcManager entries) { this.entries = entries; }

    @Override
    public boolean run(Sender s, String[] args) {
        if (!s.isPlayer()) { s.msg("§cプレイヤーのみ実行できます。"); return true; }
        ServerPlayer player = s.player();
        if (args.length < 2 || !args[0].equalsIgnoreCase("setfee")) { s.msg("§c使い方: /entrynpc setfee <金額>"); return true; }
        double fee;
        try {
            fee = Double.parseDouble(args[1]);
            if (fee < 0.0) throw new NumberFormatException();
        } catch (NumberFormatException e) { s.msg("§c金額は0以上の数値で指定してください。"); return true; }
        Mannequin target = null;
        for (Mannequin m : Mc.nearbyMannequins(player, 4.0)) if (entries.isEntryNpc(m)) { target = m; break; }
        if (target == null) { s.msg("§c近くに入場料NPCが見つかりません。"); return true; }
        boolean ok = entries.setFee(target.getUUID(), player.getUUID(), fee);
        s.msg(ok ? "§a入場料を " + fee + "円 に設定しました。" : "§cこのNPCのオーナーではありません。");
        return true;
    }

    @Override
    public List<String> tab(Sender s, String[] a) { return CardTab.entrynpc(s, a); }
}
