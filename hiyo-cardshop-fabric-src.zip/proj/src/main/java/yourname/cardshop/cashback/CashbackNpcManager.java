package yourname.cardshop.cashback;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.util.Yml;

public class CashbackNpcManager {
    private final Map<UUID, CashbackNpc> npcs = new HashMap<>();

    public CashbackNpcManager() { load(); }

    public CashbackNpc create(UUID mannequinUuid, UUID adminUuid) {
        CashbackNpc npc = new CashbackNpc(mannequinUuid, adminUuid);
        npcs.put(mannequinUuid, npc);
        save();
        return npc;
    }
    public CashbackNpc get(UUID id) { return npcs.get(id); }
    public Collection<CashbackNpc> all() { return npcs.values(); }

    private void load() {
        Yml y = Yml.load(CardShopMod.file("cashbacknpcs.yml"));
        for (String key : y.keys()) {
            try {
                UUID id = UUID.fromString(key);
                UUID admin = UUID.fromString(y.getString(key + ".admin"));
                CashbackNpc npc = new CashbackNpc(id, admin);
                npc.setBudgetRemaining(y.getDouble(key + ".budget"));
                Yml offers = y.section(key + ".offers");
                if (offers != null) for (String mat : offers.keys()) {
                    npc.setOffer(mat.toUpperCase(), y.getDouble(key + ".offers." + mat + ".price"), y.getInt(key + ".offers." + mat + ".max"));
                }
                npcs.put(id, npc);
            } catch (Exception e) {
                Mc_log("cashbacknpcs.yml 読み込みエラー(" + key + "): " + e.getMessage());
            }
        }
    }
    private static void Mc_log(String s) { yourname.cardshop.util.Mc.log(s); }

    public void save() {
        Yml y = new Yml();
        for (CashbackNpc npc : npcs.values()) {
            String path = npc.getMannequinUuid() + ".";
            y.set(path + "admin", npc.getAdminUuid().toString());
            y.set(path + "budget", npc.getBudgetRemaining());
            for (String mat : npc.getBuyPrices().keySet()) {
                y.set(path + "offers." + mat + ".price", npc.getBuyPrices().get(mat));
                y.set(path + "offers." + mat + ".max", npc.getRemainingFor(mat));
            }
        }
        y.save(CardShopMod.file("cashbacknpcs.yml"));
    }
}
