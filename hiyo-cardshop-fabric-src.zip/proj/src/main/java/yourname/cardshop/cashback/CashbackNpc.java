package yourname.cardshop.cashback;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** 中央銀行 買取NPC。品目キーは Bukkit Material名(例: DIAMOND) と同じ大文字名。 */
public class CashbackNpc {
    private final UUID mannequinUuid;
    private final UUID adminUuid;
    private double budgetRemaining;
    private final Map<String, Double> buyPrices = new LinkedHashMap<>();
    private final Map<String, Integer> maxRemaining = new LinkedHashMap<>();

    public CashbackNpc(UUID mannequinUuid, UUID adminUuid) { this.mannequinUuid = mannequinUuid; this.adminUuid = adminUuid; }

    public UUID getMannequinUuid() { return mannequinUuid; }
    public UUID getAdminUuid() { return adminUuid; }
    public double getBudgetRemaining() { return budgetRemaining; }
    public void setBudgetRemaining(double v) { budgetRemaining = v; }
    public void addBudget(double v) { budgetRemaining += v; }
    public boolean spendBudget(double v) {
        if (budgetRemaining < v) return false;
        budgetRemaining -= v;
        return true;
    }
    public Map<String, Double> getBuyPrices() { return buyPrices; }
    public Map<String, Integer> getMaxRemaining() { return maxRemaining; }
    public void setOffer(String material, double price, int maxAmount) {
        buyPrices.put(material, price);
        maxRemaining.put(material, maxAmount);
    }
    public int getRemainingFor(String material) { return maxRemaining.getOrDefault(material, 0); }
    public boolean consumeQuota(String material, int amount) {
        int cur = maxRemaining.getOrDefault(material, 0);
        if (cur < amount) return false;
        maxRemaining.put(material, cur - amount);
        return true;
    }
}
