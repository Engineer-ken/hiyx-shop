package yourname.cardshop.cashback;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import yourname.cardshop.bank.CentralBank;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.util.Gui;
import yourname.cardshop.util.Mc;

/** 中央銀行 買取窓口GUI。手持ちクリック=1個売却 / Shift+クリック=1スタック売却。 */
public class CashbackNpcGui {
    private final CashbackNpcManager manager;
    private final CardManager cardManager;

    public CashbackNpcGui(CashbackNpcManager manager, CardManager cardManager, CentralBank centralBank) {
        this.manager = manager;
        this.cardManager = cardManager;
    }

    public void open(ServerPlayer viewer, UUID npcUuid) {
        if (manager.get(npcUuid) == null) { Mc.msg(viewer, "§cこのNPCは買取を行っていません。"); return; }
        Gui.open(viewer, "中央銀行 買取窓口", 3, g -> fill(g, npcUuid));
    }

    private void fill(Gui g, UUID npcUuid) {
        CashbackNpc npc = manager.get(npcUuid);
        if (npc == null) return;
        int slot = 0;
        for (Map.Entry<String, Double> e : npc.getBuyPrices().entrySet()) {
            String mat = e.getKey();
            if (npc.getRemainingFor(mat) <= 0 || slot >= g.size()) continue;
            Item it = Mc.item(mat);
            if (it == null) continue;
            ItemStack s = new ItemStack(it, 1);
            List<String> lore = new ArrayList<>();
            lore.add("§7買取価格: §a" + e.getValue() + "円");
            lore.add("§7残り枠: §f" + npc.getRemainingFor(mat) + "個");
            lore.add("§7NPC残り予算: §f" + npc.getBudgetRemaining() + "円");
            lore.add("§e手に持ってクリック=1個売却");
            lore.add("§eShift+クリック=1スタック売却");
            Mc.setLore(s, lore);
            g.set(slot++, s, (p, right, shift) -> onClick(p, g, npcUuid, mat, shift));
        }
    }

    private void onClick(ServerPlayer player, Gui g, UUID npcUuid, String mat, boolean shift) {
        CashbackNpc npc = manager.get(npcUuid);
        if (npc == null) return;
        Double price = npc.getBuyPrices().get(mat);
        if (price == null || npc.getRemainingFor(mat) <= 0) {
            Mc.msg(player, "§cこの品目は取り扱っていません(または枠切れ)。");
            return;
        }
        boolean done = shift ? sellOneStack(player, npc, mat, price) : sellOne(player, npc, mat, price);
        if (done) g.refresh();
    }

    /** 従来: 手に持っているアイテムを1個売却 */
    private boolean sellOne(ServerPlayer player, CashbackNpc npc, String mat, double price) {
        ItemStack hand = Mc.hand(player);
        if (hand.isEmpty() || !Mc.itemName(hand).equals(mat)) {
            Mc.msg(player, "§c売りたいアイテムを手に持ってください。");
            return false;
        }
        if (!npc.spendBudget(price)) { Mc.msg(player, "§cこのNPCの予算が不足しています。"); return false; }
        npc.consumeQuota(mat, 1);
        hand.shrink(1);
        cardManager.addBalance(player.getUUID(), price);
        manager.save();
        Mc.msg(player, "§a中央銀行から " + price + "円 のキャッシュバックを受け取りました。");
        return true;
    }

    /**
     * Shift+クリック: インベントリから該当アイテムを1スタック(1スロット分)売却。
     * 手持ち優先→ホットバー/メイン欄の先頭から。名前や付加情報のあるアイテム(CARD等)は対象外。
     * NPCの残り枠・予算・買い手の残高上限に収まる範囲で売却(一部のみ売れる場合あり)。
     */
    private boolean sellOneStack(ServerPlayer player, CashbackNpc npc, String mat, double price) {
        Inventory inv = player.getInventory();
        int slot = -1;
        int held = inv.getSelectedSlot();
        if (sellable(inv.getItem(held), mat)) slot = held;
        else for (int i = 0; i < Mc.STORAGE; i++) if (sellable(inv.getItem(i), mat)) { slot = i; break; }
        if (slot < 0) {
            Mc.msg(player, "§c売れるアイテムがインベントリにありません(名前や付加情報のあるアイテムは対象外)。");
            return false;
        }
        ItemStack stack = inv.getItem(slot);

        int amount = Math.min(stack.getCount(), npc.getRemainingFor(mat));
        if (price > 0.0) {
            int affordable = (int) Math.floor((npc.getBudgetRemaining() + 1.0E-9) / price);
            amount = Math.min(amount, affordable);
        }
        if (amount < 1) { Mc.msg(player, "§cこのNPCの予算が不足しています。"); return false; }

        double total = CardManager.round2(price * amount);
        UUID uuid = player.getUUID();
        if (cardManager.wouldExceedCap(uuid, total)) { Mc.msg(player, "§c残高の上限を超えるため売却できません。"); return false; }
        if (!npc.spendBudget(total)) { Mc.msg(player, "§cこのNPCの予算が不足しています。"); return false; }
        npc.consumeQuota(mat, amount);
        stack.shrink(amount);
        cardManager.addBalance(uuid, total);
        manager.save();
        Mc.msg(player, "§a中央銀行に " + amount + "個 売却し、" + total + "円 のキャッシュバックを受け取りました。");
        return true;
    }

    private static boolean sellable(ItemStack s, String mat) {
        return !s.isEmpty() && Mc.itemName(s).equals(mat) && !Mc.hasMeta(s);
    }
}
