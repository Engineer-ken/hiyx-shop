package yourname.cardshop.cashback;

import java.util.List;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.decoration.Mannequin;
import net.minecraft.world.item.ItemStack;
import yourname.cardshop.bank.CentralBank;
import yourname.cardshop.command.CardTab;
import yourname.cardshop.util.Cmd;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Sender;

public class CashbackNpcCommand implements Cmd {
    private static final double RADIUS = 4.0;
    private final CashbackNpcManager manager;
    private final CentralBank centralBank;

    public CashbackNpcCommand(CashbackNpcManager manager, CentralBank centralBank) { this.manager = manager; this.centralBank = centralBank; }

    @Override
    public boolean run(Sender s, String[] args) {
        if (!s.isPlayer()) { s.msg("§cプレイヤーのみ実行できます。"); return true; }
        ServerPlayer player = s.player();
        if (!s.admin()) { s.msg("§c権限がありません。"); return true; }
        if (args.length == 0) { s.msg("§c使い方: /cashbacknpc <setbuy|addbudget|info> ..."); return true; }

        Mannequin target = null;
        for (Mannequin m : Mc.nearbyMannequins(player, RADIUS)) if (manager.get(m.getUUID()) != null) { target = m; break; }
        if (target == null) { s.msg("§c近くにキャッシュバックNPCが見つかりません。"); return true; }
        CashbackNpc npc = manager.get(target.getUUID());
        if (npc == null) { s.msg("§cNPCデータが見つかりませんでした。"); return true; }
        if (!npc.getAdminUuid().equals(player.getUUID())) { s.msg("§cこのNPCの管理者ではありません。"); return true; }

        switch (args[0].toLowerCase()) {
            case "setbuy" -> {
                if (args.length < 3) { s.msg("§c使い方: /cashbacknpc setbuy <価格> <上限個数>"); return true; }
                ItemStack hand = Mc.hand(player);
                if (hand.isEmpty()) { s.msg("§c買い取りたい種類を手に持ってください(消費されません)。"); return true; }
                double price; int max;
                try { price = Double.parseDouble(args[1]); max = Integer.parseInt(args[2]); }
                catch (NumberFormatException e) { s.msg("§c価格・上限は数値で指定してください。"); return true; }
                String mat = Mc.itemName(hand);
                npc.setOffer(mat, price, max);
                manager.save();
                s.msg("§a" + mat + " を単価" + price + "円・上限" + max + "個で買取登録しました。");
            }
            case "addbudget" -> {
                if (args.length < 2) { s.msg("§c使い方: /cashbacknpc addbudget <金額>"); return true; }
                double amount;
                try { amount = Double.parseDouble(args[1]); } catch (NumberFormatException e) { s.msg("§c金額は数値で指定してください。"); return true; }
                if (!centralBank.withdraw(amount)) { s.msg("§c中央銀行の残高が不足しています(現在: " + centralBank.getTotalAbsorbed() + "円)。"); return true; }
                npc.addBudget(amount);
                manager.save();
                s.msg("§a中央銀行から " + amount + "円 をこのNPCの予算に割り当てました(残り予算: " + npc.getBudgetRemaining() + "円)。");
            }
            case "info" -> {
                s.msg("§6==== キャッシュバックNPC ====");
                s.msg("§7残り予算: §a" + npc.getBudgetRemaining() + "円");
                if (npc.getBuyPrices().isEmpty()) { s.msg("§7(買取品目なし)"); break; }
                npc.getBuyPrices().forEach((mat, price) -> s.msg("§f" + mat + " §7- §a" + price + "円 §7(残り" + npc.getRemainingFor(mat) + "個)"));
            }
            default -> s.msg("§c不明なサブコマンドです。");
        }
        return true;
    }

    @Override
    public List<String> tab(Sender s, String[] a) { return CardTab.cashbacknpc(s, a); }
}
