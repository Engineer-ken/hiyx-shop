package yourname.cardshop.command;

import java.util.List;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.shop.ShopListing;
import yourname.cardshop.shop.ShopManager;
import yourname.cardshop.util.Cmd;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Sender;

public class ShopCommand implements Cmd {
    private final ShopManager shopManager;

    public ShopCommand(ShopManager shopManager) { this.shopManager = shopManager; }

    @Override
    public boolean run(Sender s, String[] args) {
        if (!s.isPlayer()) { s.msg("§cプレイヤーのみ実行できます。"); return true; }
        ServerPlayer p = s.player();
        if (args.length == 0) { s.msg("§c使い方: /shop <sell|list|buy|cancel|mylistings>"); return true; }
        switch (args[0].toLowerCase()) {
            case "sell" -> sell(p, args);
            case "list" -> list(p);
            case "buy" -> buy(p, args);
            case "cancel" -> cancel(p, args);
            case "mylistings" -> mine(p);
            default -> s.msg("§c不明なサブコマンドです。");
        }
        return true;
    }

    private void sell(ServerPlayer p, String[] args) {
        if (args.length < 2) { Mc.msg(p, "§c使い方: /shop sell <単価> [個数(省略時は手持ちの数)]"); return; }
        double price; int amount;
        try { price = Double.parseDouble(args[1]); } catch (NumberFormatException e) { Mc.msg(p, "§c単価は数値で指定してください。"); return; }
        if (args.length >= 3) {
            try { amount = Integer.parseInt(args[2]); } catch (NumberFormatException e) { Mc.msg(p, "§c個数は整数で指定してください。"); return; }
        } else amount = Mc.hand(p).getCount();
        switch (shopManager.sell(p, price, amount)) {
            case OK -> Mc.msg(p, "§a出品しました。単価: " + price + " / 個数: " + amount);
            case NOT_ENOUGH_ITEMS -> Mc.msg(p, "§c出品する個数分のアイテムを所持していません。");
            case CARD_ITEM_NOT_SELLABLE -> Mc.msg(p, "§cCARDは出品できません。");
            case INVALID_PRICE -> Mc.msg(p, "§c価格と個数は正の数で指定してください。");
        }
    }

    private void list(ServerPlayer p) {
        List<ShopListing> all = shopManager.getAllListings();
        if (all.isEmpty()) { Mc.msg(p, "§7現在、出品はありません。"); return; }
        Mc.msg(p, "§6==== ショップ出品一覧 ====");
        for (ShopListing l : all) Mc.msg(p, fmt(l));
    }

    private void mine(ServerPlayer p) {
        List<ShopListing> mine = shopManager.getListingsBySeller(p.getUUID());
        if (mine.isEmpty()) { Mc.msg(p, "§7あなたの出品はありません。"); return; }
        Mc.msg(p, "§6==== あなたの出品 ====");
        for (ShopListing l : mine) Mc.msg(p, fmt(l));
    }

    private String fmt(ShopListing l) {
        return "§f[" + l.getId().toString().substring(0, 8) + "] §e" + Mc.itemName(l.getItemTemplate()) + " §7x" + l.getAmount()
                + " §f- §a" + l.getPricePerUnit() + "/個 §7(出品者: " + l.getSellerName() + ")";
    }

    private void buy(ServerPlayer p, String[] args) {
        if (args.length < 2) { Mc.msg(p, "§c使い方: /shop buy <ID> [個数]"); return; }
        ShopListing l = shopManager.findByShortId(args[1]);
        if (l == null) { Mc.msg(p, "§cその出品IDは見つかりませんでした。"); return; }
        int amount = 1;
        if (args.length >= 3) {
            try { amount = Integer.parseInt(args[2]); } catch (NumberFormatException e) { Mc.msg(p, "§c個数は整数で指定してください。"); return; }
        }
        switch (shopManager.buy(p, l.getId(), amount)) {
            case OK -> Mc.msg(p, "§a購入しました。");
            case NOT_FOUND -> Mc.msg(p, "§cその出品は見つかりませんでした。");
            case NOT_ENOUGH_STOCK -> Mc.msg(p, "§c在庫が足りません。");
            case NOT_ENOUGH_BALANCE -> Mc.msg(p, "§c残高が足りません。");
            case INVENTORY_FULL -> Mc.msg(p, "§cインベントリに空きがありません。");
            case CANNOT_BUY_OWN -> Mc.msg(p, "§c自分の出品は購入できません。");
        }
    }

    private void cancel(ServerPlayer p, String[] args) {
        if (args.length < 2) { Mc.msg(p, "§c使い方: /shop cancel <ID>"); return; }
        ShopListing l = shopManager.findByShortId(args[1]);
        if (l == null) { Mc.msg(p, "§cその出品IDは見つかりませんでした。"); return; }
        switch (shopManager.cancel(p, l.getId())) {
            case OK -> Mc.msg(p, "§a出品を取り下げ、アイテムを返却しました。");
            case NOT_FOUND -> Mc.msg(p, "§cその出品は見つかりませんでした。");
            case NOT_OWNER -> Mc.msg(p, "§c自分の出品のみ取り下げられます。");
            case INVENTORY_FULL -> Mc.msg(p, "§cインベントリに空きがありません。");
        }
    }

    @Override
    public List<String> tab(Sender s, String[] a) { return CardTab.shop(s, a); }
}
