package yourname.cardshop.command;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.cashback.CashbackNpc;
import yourname.cardshop.util.Cmd;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Sender;

/** /cardadmin (経済確認コマンド) */
public class AdminCommand implements Cmd {
    private static final int PAGE_SIZE = 10;
    private static final List<String> SUBS = List.of("summary", "balance", "list", "bank", "help");

    private static Map<UUID, Double> balances() {
        Map<UUID, Double> m = new HashMap<>();
        for (Map.Entry<UUID, Double> e : CardShopMod.cards.allBalances()) m.put(e.getKey(), e.getValue());
        return m;
    }
    private static String money(double d) {
        return new DecimalFormat("#,##0.##", DecimalFormatSymbols.getInstance(Locale.ROOT)).format(d) + "円";
    }
    /** [割当済み予算合計, NPC数] */
    private static double[] cashbackBudgets() {
        double sum = 0; int n = 0;
        for (CashbackNpc c : CardShopMod.cashbacks.all()) { sum += c.getBudgetRemaining(); n++; }
        return new double[] {sum, n};
    }

    @Override
    public boolean run(Sender s, String[] a) {
        if (!s.admin()) { s.msg("§cこのコマンドを実行する権限がありません。"); return true; }
        String sub = a.length == 0 ? "summary" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "summary", "total" -> summary(s);
            case "balance", "bal" -> balance(s, a);
            case "list", "top" -> list(s, a);
            case "bank" -> bank(s);
            default -> help(s);
        }
        return true;
    }

    private void help(Sender s) {
        s.msg("§6==== /cardadmin ====");
        s.msg("§e/cardadmin summary §7- 経済サマリー(個人財産合計・中央銀行・総額)");
        s.msg("§e/cardadmin balance <プレイヤー> §7- 個人の残高");
        s.msg("§e/cardadmin list [ページ] §7- 全口座の残高ランキング");
        s.msg("§e/cardadmin bank §7- 中央銀行の残高と買取NPC予算");
    }

    private void summary(Sender s) {
        Map<UUID, Double> map = balances();
        double total = 0.0; UUID topId = null; double top = Double.NEGATIVE_INFINITY;
        for (Map.Entry<UUID, Double> e : map.entrySet()) {
            double v = e.getValue() == null ? 0.0 : e.getValue();
            total += v;
            if (v > top) { top = v; topId = e.getKey(); }
        }
        double bank = CardShopMod.bank.getTotalAbsorbed();
        double[] cb = cashbackBudgets();
        s.msg("§6==== 経済サマリー ====");
        s.msg("§f個人財産の合計: §a" + money(total) + " §7(口座数 " + map.size() + ")");
        if (!map.isEmpty()) s.msg("§f平均: §a" + money(total / map.size()) + " §7/ §f最高: §e" + Mc.nameOf(topId) + " §a" + money(top));
        s.msg("§f中央銀行残高: §a" + money(bank));
        s.msg("§f買取NPCへ割当済みの予算: §a" + money(cb[0]) + " §7(" + (int) cb[1] + "体)");
        s.msg("§f合計(個人+中央銀行+NPC予算): §6" + money(total + bank + cb[0]));
        s.msg("§7詳細: /cardadmin list, /cardadmin balance <名前>, /cardadmin bank");
    }

    private void balance(Sender s, String[] a) {
        if (a.length < 2) { s.msg("§c使い方: /cardadmin balance <プレイヤー>"); return; }
        CardManager cm = CardShopMod.cards;
        UUID id = null;
        for (UUID u : balances().keySet()) if (a[1].equalsIgnoreCase(Mc.nameOf(u))) { id = u; break; }
        if (id == null) id = Mc.uuidOf(a[1]);
        if (id == null || !cm.hasAccount(id)) { s.msg("§c" + a[1] + " の口座は見つかりませんでした。"); return; }
        s.msg("§e" + Mc.nameOf(id) + " §7の残高: §a" + money(cm.getBalance(id)));
    }

    private void list(Sender s, String[] a) {
        int page = 1;
        if (a.length >= 2) {
            try { page = Math.max(1, Integer.parseInt(a[1])); }
            catch (NumberFormatException e) { s.msg("§cページ番号は整数で指定してください。"); return; }
        }
        Map<UUID, Double> map = balances();
        if (map.isEmpty()) { s.msg("§7口座がありません。"); return; }
        List<Map.Entry<UUID, Double>> list = new ArrayList<>(map.entrySet());
        list.sort((x, y) -> Double.compare(y.getValue() == null ? 0.0 : y.getValue(), x.getValue() == null ? 0.0 : x.getValue()));
        int pages = (list.size() + PAGE_SIZE - 1) / PAGE_SIZE;
        if (page > pages) page = pages;
        double total = 0.0;
        for (Map.Entry<UUID, Double> e : list) total += e.getValue() == null ? 0.0 : e.getValue();
        s.msg("§6==== 残高ランキング (" + page + "/" + pages + ") 合計 " + money(total) + " ====");
        int start = (page - 1) * PAGE_SIZE;
        for (int i = start; i < Math.min(list.size(), start + PAGE_SIZE); i++) {
            Map.Entry<UUID, Double> e = list.get(i);
            double v = e.getValue() == null ? 0.0 : e.getValue();
            String pct = total > 0.0 ? String.format(Locale.ROOT, " §7(%.1f%%)", v * 100.0 / total) : "";
            s.msg("§7" + (i + 1) + ". §f" + Mc.nameOf(e.getKey()) + " §a" + money(v) + pct);
        }
        if (page < pages) s.msg("§7次のページ: /cardadmin list " + (page + 1));
    }

    private void bank(Sender s) {
        double bank = CardShopMod.bank.getTotalAbsorbed();
        double[] cb = cashbackBudgets();
        s.msg("§6==== 中央銀行 ====");
        s.msg("§f残高(税・手数料などで吸収した額): §a" + money(bank));
        s.msg("§f買取NPCへ割当済みの残り予算: §a" + money(cb[0]) + " §7(" + (int) cb[1] + "体)");
        s.msg("§f合計: §6" + money(bank + cb[0]));
    }

    @Override
    public List<String> tab(Sender s, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.admin()) return out;
        if (a.length == 1) CardTab.addMatches(out, SUBS, a[0]);
        else if (a.length == 2 && (a[0].equalsIgnoreCase("balance") || a[0].equalsIgnoreCase("bal")))
            CardTab.addMatches(out, CardTab.playerNames(CardShopMod.cards, true), a[1]);
        return out;
    }
}
