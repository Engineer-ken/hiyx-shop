package yourname.cardshop.command;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.util.Cmd;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Sender;

public class PayCommand implements Cmd {
    private final CardManager cardManager;

    public PayCommand(CardManager cardManager) { this.cardManager = cardManager; }

    @Override
    public boolean run(Sender sender, String[] args) {
        if (!sender.isPlayer()) { sender.msg("§cプレイヤーのみ実行できます。"); return true; }
        ServerPlayer player = sender.player();
        if (args.length != 2) { sender.msg("§c使い方: /pay <プレイヤー名> <金額>"); return true; }
        UUID me = player.getUUID();
        if (!cardManager.hasAccount(me)) { sender.msg("§cあなたはCARDを持っていません。"); return true; }

        UUID target; String targetName;
        ServerPlayer online = Mc.player(args[0]);
        if (online != null) {
            target = online.getUUID();
            targetName = Mc.name(online);
        } else {
            target = Mc.uuidOf(args[0]);
            if (target == null) { sender.msg("§cそのプレイヤーは見つかりません。"); return true; }
            targetName = Mc.nameOf(target);
        }
        if (target.equals(me)) { sender.msg("§c自分自身には送金できません。"); return true; }
        if (!cardManager.hasAccount(target)) { sender.msg("§c" + targetName + " はCARDを持っていません。"); return true; }

        double amount;
        try { amount = Double.parseDouble(args[1]); } catch (NumberFormatException e) { sender.msg("§c金額は数値で指定してください。"); return true; }
        if (Double.isNaN(amount) || Double.isInfinite(amount)) { sender.msg("§c金額は数値で指定してください。"); return true; }
        amount = CardManager.round2(amount);
        if (amount < 0.01) { sender.msg("§c送金額は0.01以上で指定してください。"); return true; }
        if (cardManager.getBalance(me) < amount) {
            sender.msg("§c残高が足りません。(残高: " + CardManager.formatMoney(cardManager.getBalance(me)) + "円)");
            return true;
        }
        if (cardManager.wouldExceedCap(target, amount)) { sender.msg("§c相手の残高が上限に達するため送金できません。"); return true; }
        if (!cardManager.removeBalance(me, amount)) { sender.msg("§c残高が足りません。"); return true; }
        if (!cardManager.addBalance(target, amount)) {
            cardManager.addBalanceForce(me, amount);
            sender.msg("§c送金に失敗しました。");
            return true;
        }
        String amt = CardManager.formatMoney(amount);
        sender.msg("§a" + targetName + " に " + amt + "円 送金しました。(残高: " + CardManager.formatMoney(cardManager.getBalance(me)) + "円)");
        ServerPlayer t = Mc.player(target);
        if (t != null) Mc.msg(t, "§a" + Mc.name(player) + " から " + amt + "円 受け取りました。");
        return true;
    }

    @Override
    public List<String> tab(Sender s, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            String p = a[0].toLowerCase();
            for (ServerPlayer pl : Mc.online()) {
                if (pl.getUUID().equals(s.uuid())) continue;
                if (Mc.name(pl).toLowerCase().startsWith(p)) out.add(Mc.name(pl));
            }
        }
        return out;
    }
}
