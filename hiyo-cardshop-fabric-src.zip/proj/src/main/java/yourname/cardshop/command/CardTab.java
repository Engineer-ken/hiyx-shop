package yourname.cardshop.command;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.rail.CompanyInfo;
import yourname.cardshop.shop.ShopListing;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Sender;

/** タブ補完(元プラグインの CardTab)。 */
public final class CardTab {
    private CardTab() { }

    public static void addMatches(List<String> list, Collection<String> cands, String prefix) {
        String p = prefix == null ? "" : prefix.toLowerCase(Locale.ROOT);
        for (String c : cands) if (c.toLowerCase(Locale.ROOT).startsWith(p) && !list.contains(c)) list.add(c);
    }

    public static List<String> playerNames(CardManager cm, boolean includeAccounts) {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        for (ServerPlayer p : Mc.online()) set.add(Mc.name(p));
        if (includeAccounts && cm != null) {
            for (Map.Entry<UUID, Double> e : cm.allBalances()) {
                String n = Mc.nameOf(e.getKey());
                if (n.length() == 8 && n.matches("[0-9a-f]{8}")) continue;
                set.add(n);
            }
        }
        return new ArrayList<>(set);
    }

    private static boolean is(String[] a, int i, String... names) {
        if (a.length <= i) return false;
        String s = a[i].toLowerCase(Locale.ROOT);
        for (String n : names) if (n.equals(s)) return true;
        return false;
    }

    public static List<String> card(Sender s, String[] a) {
        List<String> out = new ArrayList<>();
        String last = a[a.length - 1];
        boolean admin = s.admin();
        if (a.length == 1) {
            if (admin) addMatches(out, List.of("issue", "reissue", "add", "remove", "set", "balance", "bank", "reloadconfig", "testskin"), last);
            else addMatches(out, List.of("reissue", "balance"), last);
        } else if (a.length == 2 && admin) {
            if (is(a, 0, "issue")) addMatches(out, playerNames(CardShopMod.cards, false), last);
            else if (is(a, 0, "add", "remove", "set", "balance")) addMatches(out, playerNames(CardShopMod.cards, true), last);
        }
        return out;
    }

    public static List<String> shop(Sender s, String[] a) {
        List<String> out = new ArrayList<>();
        String last = a[a.length - 1];
        if (a.length == 1) addMatches(out, List.of("sell", "list", "buy", "cancel", "mylistings"), last);
        else if (a.length == 2) {
            List<String> ids = new ArrayList<>();
            if (is(a, 0, "buy")) {
                for (ShopListing l : CardShopMod.shops.getAllListings()) ids.add(l.getId().toString().substring(0, 8));
            } else if (is(a, 0, "cancel") && s.isPlayer()) {
                for (ShopListing l : CardShopMod.shops.getListingsBySeller(s.uuid())) ids.add(l.getId().toString().substring(0, 8));
            }
            addMatches(out, ids, last);
        }
        return out;
    }

    public static List<String> rent(Sender s, String[] a) {
        List<String> out = new ArrayList<>();
        String last = a[a.length - 1];
        boolean admin = s.admin();
        if (a.length == 1) {
            List<String> subs = new ArrayList<>(List.of("setprice", "addtenant", "removetenant", "info", "history"));
            if (admin) subs.add(0, "registerowner");
            addMatches(out, subs, last);
        } else if (a.length == 2 && is(a, 0, "registerowner", "setprice", "addtenant", "removetenant", "info", "history")) {
            if (!is(a, 0, "registerowner") || admin) addMatches(out, new ArrayList<>(CardShopMod.rents.getAll().keySet()), last);
        } else if ((a.length == 3 && is(a, 0, "addtenant", "removetenant")) || (a.length == 3 && admin && is(a, 0, "registerowner"))) {
            addMatches(out, playerNames(CardShopMod.cards, true), last);
        }
        return out;
    }

    public static List<String> shopnpc(Sender s, String[] a) {
        List<String> out = new ArrayList<>();
        String last = a[a.length - 1];
        if (a.length == 1) addMatches(out, List.of("sell", "buy", "addowner", "removeowner", "withdraw", "collect", "mystock"), last);
        else if (a.length == 2 && is(a, 0, "addowner", "removeowner")) addMatches(out, playerNames(CardShopMod.cards, true), last);
        else if (a.length == 3 && is(a, 0, "sell")) addMatches(out, List.of("all"), last);
        return out;
    }

    public static List<String> company(Sender s, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.admin()) return out;
        String last = a[a.length - 1];
        if (a.length == 1) addMatches(out, List.of("add", "setincome", "remove", "list"), last);
        else if (a.length == 2 && is(a, 0, "setincome", "remove")) {
            List<String> codes = new ArrayList<>();
            for (CompanyInfo c : CardShopMod.companies.getAll()) codes.add(String.valueOf(c.code));
            addMatches(out, codes, last);
        } else if (a.length == 5 && is(a, 0, "add")) addMatches(out, playerNames(CardShopMod.cards, true), last);
        return out;
    }

    public static List<String> entrynpc(Sender s, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) addMatches(out, List.of("setfee"), a[0]);
        return out;
    }

    public static List<String> cashbacknpc(Sender s, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1 && s.admin()) addMatches(out, List.of("setbuy", "addbudget", "info"), a[0]);
        return out;
    }
}
