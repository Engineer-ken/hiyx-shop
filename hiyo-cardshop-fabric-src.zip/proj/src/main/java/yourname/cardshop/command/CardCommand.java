package yourname.cardshop.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.benefit.BenefitManager;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.util.Cmd;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Npc;
import yourname.cardshop.util.Sender;
import yourname.cardshop.util.Tasks;

/** /card (CARD管理) + /card benefit (国からの給付金) をまとめたコマンド。 */
public class CardCommand implements Cmd {
    private final CardManager cm;
    private final BenefitManager benefit;

    public CardCommand(CardManager cm, BenefitManager benefit) { this.cm = cm; this.benefit = benefit; }

    private static boolean isLabel(String s) { return s.equals("国からの給付金") || s.equals("給付金") || s.equalsIgnoreCase("benefit"); }

    @Override
    public boolean run(Sender s, String[] a) {
        // --- 給付金(元: BenefitCardCommand が先に処理) ---
        if (a.length >= 1 && a[0].equalsIgnoreCase("benefit")) { handleBenefit(s, a); return true; }
        if (a.length >= 3 && a[0].equalsIgnoreCase("issue")) {
            int idx = -1;
            for (int i = 2; i < a.length; i++) if (isLabel(a[i])) { idx = i; break; }
            if (idx >= 0) { handleIssueWithBenefit(s, a, idx); return true; }
        }
        // --- 通常の /card ---
        if (a.length == 0) { s.msg("§c使い方: /card <issue|reissue|add|remove|set|balance|bank> ..."); return true; }
        switch (a[0].toLowerCase()) {
            case "issue" -> issue(s, a);
            case "reissue" -> reissue(s);
            case "add" -> adjust(s, a, true);
            case "remove" -> adjust(s, a, false);
            case "set" -> set(s, a);
            case "balance" -> balance(s, a);
            case "bank" -> {
                if (!requireAdmin(s)) return true;
                s.msg("§6中央銀行の累計吸収額: " + CardShopMod.bank.getTotalAbsorbed() + "円");
            }
            case "reloadconfig" -> {
                if (!requireAdmin(s)) return true;
                CardShopMod.reloadConfig();
                s.msg("§aconfig.ymlを再読み込みしました。");
            }
            case "testskin" -> testSkin(s, a);
            default -> s.msg("§c不明なサブコマンドです。");
        }
        return true;
    }

    private boolean requireAdmin(Sender s) {
        if (!s.admin()) { s.msg("§cこのコマンドを実行する権限がありません。"); return false; }
        return true;
    }

    private void issue(Sender s, String[] a) {
        if (!requireAdmin(s)) return;
        if (a.length < 2) { s.msg("§c使い方: /card issue <player> [amount]"); return; }
        ServerPlayer t = Mc.player(a[1]);
        if (t == null) { s.msg("§cそのプレイヤーはオンラインではありません。"); return; }
        double amount = 0.0;
        if (a.length >= 3) {
            try { amount = Double.parseDouble(a[2]); } catch (NumberFormatException e) { s.msg("§c金額は数値で指定してください。"); return; }
        }
        if (cm.issueCard(t, amount)) {
            s.msg("§a" + Mc.name(t) + " にCARDを発行しました(初期残高: " + amount + ")。");
            Mc.msg(t, "§aCARDが発行されました。");
        } else s.msg("§c" + Mc.name(t) + " は既にCARDを所持しています。");
    }

    private void reissue(Sender s) {
        if (!s.isPlayer()) { s.msg("§cプレイヤーのみ実行できます。"); return; }
        ServerPlayer p = s.player();
        double fee = CardShopMod.cfg().getDouble("reissue-fee", 500.0);
        switch (cm.reissueCard(p)) {
            case OK -> s.msg("§aCARDを再発行しました(手数料 " + fee + " を徴収しました)。");
            case NO_ACCOUNT -> s.msg("§cあなたはまだ口座を持っていません。管理者に発行を依頼してください。");
            case NOT_ENOUGH_BALANCE -> s.msg("§c再発行手数料(" + fee + ")分の残高がありません。");
            case INVENTORY_FULL -> s.msg("§cインベントリに空きがありません。");
        }
    }

    private void testSkin(Sender s, String[] a) {
        if (!s.isPlayer()) { s.msg("§cプレイヤーのみ実行できます。"); return; }
        ServerPlayer p = s.player();
        if (!requireAdmin(s)) return;
        if (a.length < 2) { s.msg("§c使い方: /card testskin <URL>"); return; }
        String url = a[1];
        try {
            UUID id = Npc.spawn((ServerLevel) p.level(), p.getX(), p.getY(), p.getZ(), p.getYRot(), "テストスキン", null, url, null, null);
            s.msg("§aテスト用NPCを設置しました(30秒後に自動削除)。表示を確認してください。");
            Mc.log("[testskin] URL=" + url + " で一時Mannequinを生成しました。");
            Tasks.later(600, () -> Npc.remove(id));
        } catch (Exception e) {
            s.msg("§cスキン適用に失敗しました。コンソールログを確認してください。");
            Mc.log("[testskin] 失敗: URL=" + url + " " + e);
        }
    }

    private void adjust(Sender s, String[] a, boolean add) {
        if (!requireAdmin(s)) return;
        if (a.length < 3) { s.msg("§c使い方: /card " + (add ? "add" : "remove") + " <player> <amount>"); return; }
        UUID t = Mc.uuidOf(a[1]);
        if (t == null) { s.msg("§c" + a[1] + " が見つかりません。"); return; }
        double amount;
        try { amount = Double.parseDouble(a[2]); } catch (NumberFormatException e) { s.msg("§c金額は数値で指定してください。"); return; }
        if (add) cm.addBalance(t, amount);
        else if (!cm.removeBalance(t, amount)) { s.msg("§c残高が不足しているため減額できません。"); return; }
        s.msg("§a" + a[1] + " の残高を更新しました。現在: " + cm.getBalance(t));
    }

    private void set(Sender s, String[] a) {
        if (!requireAdmin(s)) return;
        if (a.length < 3) { s.msg("§c使い方: /card set <player> <amount>"); return; }
        UUID t = Mc.uuidOf(a[1]);
        if (t == null) { s.msg("§c" + a[1] + " が見つかりません。"); return; }
        double amount;
        try { amount = Double.parseDouble(a[2]); } catch (NumberFormatException e) { s.msg("§c金額は数値で指定してください。"); return; }
        cm.setBalance(t, amount);
        s.msg("§a" + a[1] + " の残高を " + amount + " に設定しました。");
    }

    private void balance(Sender s, String[] a) {
        UUID target; String name;
        if (a.length >= 2) {
            if (!s.admin() && !a[1].equalsIgnoreCase(s.name())) { s.msg("§c他のプレイヤーの残高を見る権限がありません。"); return; }
            target = Mc.uuidOf(a[1]);
            if (target == null) { s.msg("§c" + a[1] + " が見つかりません。"); return; }
            name = Mc.nameOf(target);
        } else if (s.isPlayer()) { target = s.uuid(); name = s.name(); }
        else { s.msg("§cプレイヤー名を指定してください。"); return; }
        s.msg("§a" + name + " の残高: " + cm.getBalance(target));
    }

    // ---------------- 国からの給付金 ----------------
    private boolean checkPerm(Sender s) {
        if (s.admin()) return true;
        s.msg("§cこのコマンドを実行する権限がありません。");
        return false;
    }
    private void usage(Sender s) {
        s.msg("§c使い方: /card benefit <player> <付与する金額>  (金額0で解除)");
        s.msg("§c        /card benefit remove <player>");
        s.msg("§c        /card benefit list");
    }
    private void handleBenefit(Sender s, String[] a) {
        if (!checkPerm(s)) return;
        if (a.length == 2 && a[1].equalsIgnoreCase("list")) {
            Map<UUID, Double> m = benefit.entries();
            if (m.isEmpty()) { s.msg("§e国からの給付金の登録はありません。"); return; }
            s.msg("§6--- 国からの給付金 (毎日0時・中央銀行から支給) ---");
            for (Map.Entry<UUID, Double> e : m.entrySet())
                s.msg("§f" + Mc.nameOf(e.getKey()) + " §7: §a" + CardManager.formatMoney(e.getValue()) + "円");
            return;
        }
        if (a.length == 3 && a[1].equalsIgnoreCase("remove")) { register(s, a[2], 0.0, false); return; }
        if (a.length != 3) { usage(s); return; }
        double d = parseAmount(s, a[2]);
        if (d < 0.0) return;
        register(s, a[1], d, false);
    }
    private void handleIssueWithBenefit(Sender s, String[] a, int labelIdx) {
        if (!checkPerm(s)) return;
        String amt = null;
        for (int i = 2; i < a.length; i++) if (i != labelIdx) { amt = a[i]; break; }
        if (amt == null) { s.msg("§c使い方: /card issue <player> <付与する金額> 国からの給付金"); return; }
        double d = parseAmount(s, amt);
        if (d < 0.0) return;
        register(s, a[1], d, true);
    }
    private double parseAmount(Sender s, String str) {
        double d;
        try { d = Double.parseDouble(str); } catch (NumberFormatException e) { s.msg("§c金額は数値で指定してください。"); return -1.0; }
        if (Double.isNaN(d) || Double.isInfinite(d) || d < 0.0) { s.msg("§c金額は0以上の数値で指定してください。"); return -1.0; }
        return d;
    }
    private void register(Sender s, String name, double amount, boolean issueIfMissing) {
        UUID id; String pname;
        ServerPlayer p = Mc.player(name);
        if (p != null) {
            id = p.getUUID(); pname = Mc.name(p);
            if (!cm.hasAccount(id) && amount > 0.0) {
                if (!issueIfMissing) { s.msg("§c" + pname + " はCARDを持っていません。先に /card issue " + pname + " で発行してください。"); return; }
                if (cm.issueCard(p, 0.0)) { s.msg("§a" + pname + " にCARDを発行しました(初期残高: 0)。"); Mc.msg(p, "§aCARDが発行されました。"); }
            }
        } else {
            id = Mc.uuidOf(name);
            pname = name;
            if (id == null) { s.msg("§c" + name + " が見つかりません。"); return; }
            if (!cm.hasAccount(id) && benefit.getAmount(id) <= 0.0) { s.msg("§c" + pname + " はCARDを持っていません。"); return; }
        }
        if (amount <= 0.0) {
            if (benefit.unregister(id)) s.msg("§a" + pname + " の国からの給付金を解除しました。");
            else s.msg("§c" + pname + " は国からの給付金に登録されていません。");
            return;
        }
        benefit.register(id, amount);
        s.msg("§a" + pname + " を国からの給付金に登録しました(毎日0時に " + CardManager.formatMoney(amount) + "円・中央銀行から支給)。");
        if (p != null) Mc.msg(p, "§6[国からの給付金] §7毎日0時に §a" + CardManager.formatMoney(amount) + "円 §7が支給されます。");
    }

    @Override
    public List<String> tab(Sender s, String[] a) {
        List<String> out = new ArrayList<>(CardTab.card(s, a));
        if (!s.admin() || a.length == 0) return out;
        String last = a[a.length - 1].toLowerCase();
        if (a.length == 1) {
            if ("benefit".startsWith(last) && !out.contains("benefit")) out.add("benefit");
        } else if (a[0].equalsIgnoreCase("benefit")) {
            if (a.length == 2) {
                for (String x : new String[] {"list", "remove"}) if (x.startsWith(last)) out.add(x);
                for (ServerPlayer p : Mc.online()) if (Mc.name(p).toLowerCase().startsWith(last)) out.add(Mc.name(p));
            } else if (a.length == 3 && a[1].equalsIgnoreCase("remove")) {
                for (ServerPlayer p : Mc.online()) if (Mc.name(p).toLowerCase().startsWith(last)) out.add(Mc.name(p));
            }
        } else if (a[0].equalsIgnoreCase("issue") && a.length >= 3 && a.length <= 4
                && "国からの給付金".startsWith(a[a.length - 1]) && !out.contains("国からの給付金")) out.add("国からの給付金");
        return out;
    }
}
