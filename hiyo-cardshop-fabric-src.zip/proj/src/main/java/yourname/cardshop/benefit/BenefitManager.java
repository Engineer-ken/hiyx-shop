package yourname.cardshop.benefit;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.bank.CentralBank;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.rent.RentManager;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Tasks;
import yourname.cardshop.util.Yml;

/** 国からの給付金(毎日0時・中央銀行から支給)と、物件の仮想収益の日次処理。 */
public class BenefitManager {
    public static final String LABEL = "国からの給付金";
    private static final long MAX_DELTA_MS = 120000L;
    private static final int BATCH = 25;

    private final CardManager cardManager;
    private final RentManager rentManager;
    private final CentralBank bank;
    private ZoneId zone;
    private long nextRolloverMs = 0L;
    private final Map<UUID, Double> amounts = new LinkedHashMap<>();
    private final Map<UUID, String> lastPaid = new LinkedHashMap<>();
    private String lastRun = "";
    private final Map<UUID, Long> onlineMs = new HashMap<>();
    private final Set<UUID> ownerBuf = new HashSet<>();
    private long lastSampleMs;
    private boolean catchUp;
    private boolean dirty;
    private int saveCounter;
    private int ownerRefresh;

    public BenefitManager(CardManager cm, RentManager rm, CentralBank bank) {
        this.cardManager = cm; this.rentManager = rm; this.bank = bank;
        load();
    }

    /** 20秒ごとに tick() を呼ぶタイマーを開始 */
    public void start() {
        lastSampleMs = System.currentTimeMillis();
        LocalDate today = today();
        nextRolloverMs = today.plusDays(1L).atStartOfDay(zone()).toInstant().toEpochMilli();
        String ts = today.toString();
        boolean cu = !ts.equals(lastRun);
        for (UUID u : amounts.keySet()) if (!ts.equals(lastPaid.get(u))) { cu = true; break; }
        catchUp = cu;
        Tasks.timer(100, 400, this::tick);
    }

    private ZoneId zone() {
        if (zone == null) {
            try { zone = ZoneId.of(CardShopMod.cfg().getString("login-tax.timezone", "Asia/Tokyo")); }
            catch (Exception e) { zone = ZoneId.systemDefault(); }
        }
        return zone;
    }
    private LocalDate today() { return LocalDate.now(zone()); }

    public void register(UUID u, double amount) {
        amounts.put(u, CardManager.round2(amount));
        if (!lastPaid.containsKey(u)) lastPaid.put(u, today().toString());
        saveNow();
    }
    public boolean unregister(UUID u) {
        boolean r = amounts.remove(u) != null;
        lastPaid.remove(u);
        saveNow();
        return r;
    }
    public Map<UUID, Double> entries() { return new LinkedHashMap<>(amounts); }
    public double getAmount(UUID u) { return amounts.getOrDefault(u, 0.0); }

    /** 物件オーナーのオンライン時間を積算 */
    private void sample(long ms) {
        if (ms <= 0L) return;
        if (ownerRefresh-- <= 0) { ownerRefresh = 15; ownerBuf.clear(); rentManager.collectIncomeOwners(ownerBuf); }
        if (ownerBuf.isEmpty()) return;
        for (UUID u : ownerBuf) {
            if (Mc.player(u) == null) continue;
            onlineMs.merge(u, ms, Long::sum);
            dirty = true;
        }
    }

    private void tick() {
        try {
            long now = System.currentTimeMillis();
            long delta = Math.max(0L, Math.min(now - lastSampleMs, MAX_DELTA_MS));
            long prevSample = lastSampleMs;
            lastSampleMs = now;
            if (now < nextRolloverMs && !catchUp) {
                sample(delta);
                if (dirty && ++saveCounter >= 15) { saveCounter = 0; saveNow(); }
                return;
            }
            long before = 0L;
            if (!catchUp) { before = Math.max(0L, Math.min(delta, nextRolloverMs - prevSample)); sample(before); }
            LocalDate today = today();
            nextRolloverMs = today.plusDays(1L).atStartOfDay(zone()).toInstant().toEpochMilli();
            String ts = today.toString();
            boolean firstToday = !ts.equals(lastRun);
            lastRun = ts;
            payBenefits(ts);
            if (firstToday) {
                Map<UUID, Double> frac = new HashMap<>();
                for (Map.Entry<UUID, Long> e : onlineMs.entrySet()) frac.put(e.getKey(), Math.min(1.0, (double) e.getValue() / 8.64E7));
                onlineMs.clear();
                rentManager.payDailyIncome(u -> frac.getOrDefault(u, 0.0));
            } else {
                rentManager.payDailyIncome(u -> 0.0);
            }
            catchUp = false;
            sample(delta - before);
            saveNow();
        } catch (Throwable t) { Mc.log("[日次処理] エラー: " + t); }
    }

    private void payBenefits(String ts) {
        List<UUID> due = new ArrayList<>();
        for (Map.Entry<UUID, Double> e : amounts.entrySet()) {
            if (!(e.getValue() > 0.0) || ts.equals(lastPaid.get(e.getKey()))) continue;
            due.add(e.getKey());
        }
        if (!due.isEmpty()) payBatch(due, 0, ts, new double[2]);
    }

    private void payBatch(List<UUID> list, int from, String ts, double[] stats) {
        int to = Math.min(from + BATCH, list.size());
        for (int i = from; i < to; i++) payOne(list.get(i), ts, stats);
        if (to < list.size()) { Tasks.later(1, () -> payBatch(list, to, ts, stats)); return; }
        saveNow();
        Mc.log("[給付金] " + (int) stats[0] + "人に合計 " + CardManager.formatMoney(stats[1]) + "円 を中央銀行から支給");
    }

    private void payOne(UUID u, String ts, double[] stats) {
        Double amt = amounts.get(u);
        if (amt == null || ts.equals(lastPaid.get(u))) return;
        double want = amt;
        lastPaid.put(u, ts);
        dirty = true;
        double pay = CardManager.round2(Math.min(want, bank.getTotalAbsorbed()));
        String result;
        if (pay <= 0.0) result = "bank-empty";
        else if (cardManager.wouldExceedCap(u, pay)) { pay = 0.0; result = "balance-cap"; }
        else if (!bank.withdraw(pay)) { pay = 0.0; result = "bank-empty"; }
        else if (!cardManager.addBalance(u, pay)) { bank.absorb(pay); pay = 0.0; result = "balance-cap"; }
        else { result = pay < want ? "partial" : "ok"; stats[0] += 1.0; stats[1] += pay; }
        ServerPlayer p = Mc.player(u);
        if (p == null) return;
        switch (result) {
            case "ok" -> Mc.msg(p, "§6[国からの給付金] §a" + CardManager.formatMoney(pay) + "円 §7が支給されました。");
            case "partial" -> Mc.msg(p, "§6[国からの給付金] §a" + CardManager.formatMoney(pay) + "円 §7が支給されました(中央銀行の残高不足のため満額ではありません)。");
            case "balance-cap" -> Mc.msg(p, "§6[国からの給付金] §c残高上限のため受け取れませんでした。");
            default -> Mc.msg(p, "§6[国からの給付金] §c中央銀行の残高不足のため、本日は支給されませんでした。");
        }
    }

    private void load() {
        Yml y = Yml.load(CardShopMod.file("benefits.yml"));
        lastRun = y.getString("last-run", "");
        Yml om = y.section("online-ms");
        if (om != null) for (String k : om.keys()) {
            try { onlineMs.put(UUID.fromString(k), y.getLong("online-ms." + k, 0L)); } catch (Exception ignored) { }
        }
        Yml pl = y.section("players");
        if (pl == null) return;
        for (String k : pl.keys()) {
            try {
                UUID u = UUID.fromString(k);
                amounts.put(u, y.getDouble("players." + k + ".amount"));
                lastPaid.put(u, y.getString("players." + k + ".last-paid", ""));
            } catch (Exception e) { Mc.log("benefits.yml 読み込みエラー(" + k + "): " + e.getMessage()); }
        }
    }

    /** 小さなファイルなので書き込みは別スレッド(スナップショットを作ってから) */
    public void saveNow() {
        Yml y = new Yml();
        y.set("last-run", lastRun);
        for (Map.Entry<UUID, Long> e : onlineMs.entrySet()) y.set("online-ms." + e.getKey(), e.getValue());
        for (Map.Entry<UUID, Double> e : amounts.entrySet()) {
            y.set("players." + e.getKey() + ".amount", e.getValue());
            y.set("players." + e.getKey() + ".last-paid", lastPaid.getOrDefault(e.getKey(), ""));
        }
        dirty = false;
        if (!CardShopMod.running()) { y.save(CardShopMod.file("benefits.yml")); return; }
        Tasks.async(() -> y.save(CardShopMod.file("benefits.yml")));
    }
}
