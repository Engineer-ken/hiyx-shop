package yourname.cardshop.card;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Tasks;
import yourname.cardshop.util.Txt;
import yourname.cardshop.util.Yml;

public class CardManager {
    private static final String K_MARKER = "card_marker";
    private static final String K_OWNER = "card_owner";

    private final Map<UUID, Double> balances = new HashMap<>();
    private boolean savePending = false;

    public CardManager() { load(); }

    private void load() {
        Yml y = Yml.load(CardShopMod.file("cards.yml"));
        for (String k : y.keys()) {
            try { balances.put(UUID.fromString(k), round2(y.getDouble(k))); } catch (IllegalArgumentException ignored) { }
        }
    }

    /** 保存は100tick(5秒)まとめて1回(軽量化) */
    private void requestSave() {
        if (!CardShopMod.running()) { saveAll(); return; }
        if (savePending) return;
        savePending = true;
        Tasks.later(100, () -> { savePending = false; saveAll(); });
    }

    /** 軽量な書き出し(YAMLライブラリを通さない)。内容は従来と同じ「UUID: 残高」形式 */
    public void saveAll() {
        final Map<UUID, Double> copy = new HashMap<>(balances); // メインではコピーだけ
        final java.nio.file.Path f = CardShopMod.file("cards.yml");
        Runnable w = () -> {
            StringBuilder sb = new StringBuilder(copy.size() * 56 + 16);
            for (Map.Entry<UUID, Double> e : copy.entrySet()) {
                double v = e.getValue();
                String num = Math.abs(v) >= 1.0E7 ? BigDecimal.valueOf(v).toPlainString() : String.valueOf(v);
                sb.append(e.getKey()).append(": ").append(num).append('\n');
            }
            Yml.writeAtomic(f, sb.toString());
        };
        if (CardShopMod.running()) Tasks.async(w); else w.run();
    }

    public double getBalance(UUID u) { return round2(balances.getOrDefault(u, 0.0)); }
    public boolean hasAccount(UUID u) { return balances.containsKey(u); }
    public double getMaxBalance() { return CardShopMod.cfg().getDouble("max-balance", -1.0); }
    public boolean wouldExceedCap(UUID u, double d) {
        double cap = getMaxBalance();
        if (cap <= 0.0) return false;
        return getBalance(u) + d > cap;
    }
    public Iterable<Map.Entry<UUID, Double>> allBalances() { return balances.entrySet(); }

    public boolean issueCard(ServerPlayer p, double d) {
        UUID id = p.getUUID();
        if (hasAccount(id)) return false;
        balances.put(id, round2(d));
        requestSave();
        Mc.give(p, createCardItem(id, Mc.name(p)));
        return true;
    }

    public ReissueResult reissueCard(ServerPlayer p) {
        UUID id = p.getUUID();
        if (!hasAccount(id)) return ReissueResult.NO_ACCOUNT;
        double fee = CardShopMod.cfg().getDouble("reissue-fee", 500.0);
        if (getBalance(id) < fee) return ReissueResult.NOT_ENOUGH_BALANCE;
        ItemStack card = createCardItem(id, Mc.name(p));
        if (!p.getInventory().add(card)) return ReissueResult.INVENTORY_FULL;
        removeBalance(id, fee);
        return ReissueResult.OK;
    }

    public void setBalance(UUID u, double d) {
        balances.put(u, Math.max(0.0, round2(d)));
        requestSave();
        syncIfOnline(u);
    }
    public boolean addBalance(UUID u, double d) {
        if (wouldExceedCap(u, d)) return false;
        setBalance(u, getBalance(u) + d);
        return true;
    }
    public void addBalanceForce(UUID u, double d) { setBalance(u, getBalance(u) + d); }
    public boolean removeBalance(UUID u, double d) {
        double bal = getBalance(u);
        d = round2(d);
        if (bal < d) return false;
        setBalance(u, bal - d);
        return true;
    }

    private final java.util.Set<UUID> pendingSync = new java.util.HashSet<>();
    private boolean syncScheduled = false;

    /** 残高変更のたびに即同期せず、0.5秒まとめて1回だけ表示を更新 */
    private void syncIfOnline(UUID u) {
        if (!CardShopMod.running()) return;
        pendingSync.add(u);
        if (syncScheduled) return;
        syncScheduled = true;
        Tasks.later(10, () -> {
            syncScheduled = false;
            java.util.List<UUID> list = new java.util.ArrayList<>(pendingSync);
            pendingSync.clear();
            for (UUID id : list) { ServerPlayer p = Mc.player(id); if (p != null) syncCardDisplay(p); }
        });
    }

    public ItemStack createCardItem(UUID owner, String name) {
        Item it = Mc.item(CardShopMod.cfg().getString("card-material", "PAPER"));
        ItemStack s = new ItemStack(it == null ? Items.PAPER : it, 1);
        Mc.tagSet(s, K_MARKER, "1");
        Mc.tagSet(s, K_OWNER, owner.toString());
        applyDisplayName(s, name, getBalance(owner));
        return s;
    }

    private void applyDisplayName(ItemStack s, String name, double bal) {
        String color = Txt.color(CardShopMod.cfg().getString("card-name-color", "&6"));
        String sym = CardShopMod.cfg().getString("currency-symbol", "\u5186");
        Mc.setName(s, color + "[CARD] " + name + " - " + formatMoney(bal) + sym);
    }

    public static double round2(double d) {
        if (Double.isNaN(d) || Double.isInfinite(d)) return 0.0;
        return BigDecimal.valueOf(d).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }
    public static String formatMoney(double d) {
        return BigDecimal.valueOf(round2(d)).stripTrailingZeros().toPlainString();
    }

    public boolean isCardItem(ItemStack s) {
        if (s == null || s.isEmpty()) return false;
        return Mc.tagGet(s, K_MARKER) != null || Mc.legacyHas(s, K_MARKER);
    }
    public UUID getCardOwner(ItemStack s) {
        if (!isCardItem(s)) return null;
        String o = Mc.tagGet(s, K_OWNER);
        if (o == null) o = Mc.legacyString(s, K_OWNER);
        if (o == null) return null;
        try { return UUID.fromString(o); } catch (IllegalArgumentException e) { return null; }
    }

    public void rebindCard(ItemStack s, ServerPlayer p) {
        Mc.tagSet(s, K_MARKER, "1");
        Mc.tagSet(s, K_OWNER, p.getUUID().toString());
        applyDisplayName(s, Mc.name(p), getBalance(p.getUUID()));
    }

    public void syncCardDisplay(ServerPlayer p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!isCardItem(s)) continue;
            UUID o = getCardOwner(s);
            if (o == null || !o.equals(p.getUUID())) continue;
            applyDisplayName(s, Mc.name(p), getBalance(p.getUUID()));
        }
    }

    public void claimAnyForeignCards(ServerPlayer p) {
        boolean changed = false;
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!isCardItem(s)) continue;
            UUID o = getCardOwner(s);
            if (o != null && o.equals(p.getUUID())) continue;
            rebindCard(s, p);
            changed = true;
        }
        if (changed) Mc.msg(p, "\u00a7aCARD\u306e\u540d\u7fa9\u304c\u3042\u306a\u305f\u306b\u5207\u308a\u66ff\u308f\u308a\u307e\u3057\u305f\u3002");
    }

    public enum ReissueResult { OK, NO_ACCOUNT, NOT_ENOUGH_BALANCE, INVENTORY_FULL }
}
