package yourname.cardshop.card;

import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Tasks;

/** CARDの名義切替・表示同期。拾得/クリックのイベントの代わりに、1秒ごとの軽い確認で名義を切り替える。 */
public class CardListener {
    public static void register(CardManager cm) {
        // ログイン時(元: onJoin)
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer p = handler.getPlayer();
            cm.claimAnyForeignCards(p);
            cm.syncCardDisplay(p);
        });
        // 拾得・インベントリ操作で他人のCARDを手にした場合の名義切替(元: onPickup / onInventoryClick)
        int iv = 40; // 全員を一度にではなく10グループに分けて順番に確認(約2秒で一巡)
        int period = Math.max(1, iv / 10);
        final int[] n = {0};
        // 全員を毎回まとめて確認せず、プレイヤーを10グループに分けて順番に確認(負荷を平らにする)
        Tasks.timer(period, period, () -> {
            int bucket = n[0]++ % 10;
            for (ServerPlayer p : Mc.players()) if (Math.floorMod(p.getUUID().hashCode(), 10) == bucket) cm.claimAnyForeignCards(p);
        });
    }
}
