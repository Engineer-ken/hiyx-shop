package yourname.cardshop.card;

import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Tasks;

/** CARDの名義切替・表示同期。拾得/クリックのイベントの代わりに、1秒ごとの軽い確認で名義を切り替える。 */
public class CardListener {
    public static void register(CardManager cm) {
        // ログイン時(元: onJoin)
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer p = handler.getPlayer();
            cm.claimAnyForeignCards(p);
            cm.syncCardDisplay(p);
        });
        // 拾得・インベントリ操作で他人のCARDを手にした場合の名義切替(元: onPickup / onInventoryClick)
        Tasks.timer(20, 20, () -> {
            for (ServerPlayer p : Mc.online()) cm.claimAnyForeignCards(p);
        });
    }
}
