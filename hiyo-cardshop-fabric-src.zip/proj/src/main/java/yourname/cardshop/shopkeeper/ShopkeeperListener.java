package yourname.cardshop.shopkeeper;

import java.util.Locale;
import java.util.UUID;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Tasks;
import yourname.cardshop.util.Txt;

/** NPCの右クリック処理と、名札付きアーマースタンドからのNPC設置。 */
public class ShopkeeperListener {
    public static void register() {
        UseEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
            if (level.isClientSide() || hand != InteractionHand.MAIN_HAND || !(player instanceof ServerPlayer sp)) return InteractionResult.PASS;
            return onInteract(sp, entity);
        });
    }

    private static InteractionResult onInteract(ServerPlayer player, Entity entity) {
        UUID id = entity.getUUID();
        if (CardShopMod.cashbacks.get(id) != null) {
            CardShopMod.cashbackGui.open(player, id);
            return InteractionResult.SUCCESS;
        }
        if (CardShopMod.shopNpcs.get(id) != null) {
            CardShopMod.shopNpcGui.open(player, id);
            return InteractionResult.SUCCESS;
        }
        if (!(entity instanceof ArmorStand stand)) return InteractionResult.PASS;

        ItemStack hand = player.getMainHandItem();
        if (!hand.is(Items.NAME_TAG)) return InteractionResult.PASS;
        Component cn = hand.get(DataComponents.CUSTOM_NAME);
        String tag = cn == null ? "" : Txt.strip(cn.getString()).trim().toLowerCase(Locale.ROOT);
        ServerLevel w = (ServerLevel) stand.level();
        double x = stand.getX(), y = stand.getY(), z = stand.getZ();
        float yaw = stand.getYRot();
        ShopkeeperManager sm = CardShopMod.shopkeepers;

        switch (tag) {
            case "shopper" -> Tasks.run(() -> {
                stand.discard();
                UUID n = sm.spawnShopkeeper(w, x, y, z, yaw, player);
                CardShopMod.shopNpcs.create(n, player.getUUID());
                Mc.msg(player, "§a店NPCを設置しました。/shopnpc sell や /shopnpc buy で商品を登録できます。");
            });
            case "gate" -> Tasks.run(() -> {
                stand.discard();
                sm.spawnGateNpc(w, x, y, z, yaw, player);
                Mc.msg(player, "§a改札NPCを設置しました。");
            });
            case "entry" -> Tasks.run(() -> {
                stand.discard();
                UUID n = sm.spawnEntryNpc(w, x, y, z, yaw, player);
                CardShopMod.entries.register(n, player.getUUID(), 0.0);
                Mc.msg(player, "§a入場料NPCを設置しました。/entrynpc setfee <金額> で入場料を設定してください。");
            });
            case "cashback" -> {
                if (!Mc.isAdmin(player)) { Mc.msg(player, "§cこのNPCは管理者のみ設置できます。"); return InteractionResult.PASS; }
                Tasks.run(() -> {
                    stand.discard();
                    UUID n = sm.spawnCashbackNpc(w, x, y, z, yaw, player);
                    CardShopMod.cashbacks.create(n, player.getUUID());
                    Mc.msg(player, "§a中央銀行買取NPCを設置しました。/cashbacknpc setbuy と addbudget で設定してください。");
                });
            }
            default -> { }
        }
        return InteractionResult.PASS;
    }
}
