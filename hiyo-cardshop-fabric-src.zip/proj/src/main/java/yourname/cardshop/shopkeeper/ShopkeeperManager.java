package yourname.cardshop.shopkeeper;

import java.util.UUID;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Npc;

/** NPC(Mannequin)の生成。スキンURLは config の *-skin-url、空ならプレイヤー本人のスキン。 */
public class ShopkeeperManager {
    public UUID spawnShopkeeper(ServerLevel w, double x, double y, double z, float yaw, ServerPlayer owner) {
        return spawn(w, x, y, z, yaw, owner, "shop-skin-url", Mc.name(owner) + " の店", "shop");
    }
    public UUID spawnGateNpc(ServerLevel w, double x, double y, double z, float yaw, ServerPlayer placer) {
        return spawn(w, x, y, z, yaw, placer, "gate-skin-url", "改札", "gate");
    }
    public UUID spawnEntryNpc(ServerLevel w, double x, double y, double z, float yaw, ServerPlayer owner) {
        return spawn(w, x, y, z, yaw, owner, "entry-skin-url", "入場受付", "entry");
    }
    public UUID spawnCashbackNpc(ServerLevel w, double x, double y, double z, float yaw, ServerPlayer admin) {
        return spawn(w, x, y, z, yaw, admin, "cashback-skin-url", "中央銀行 買取窓口", "cashback");
    }

    private UUID spawn(ServerLevel w, double x, double y, double z, float yaw, ServerPlayer skinSource, String cfgKey, String name, String role) {
        String url = CardShopMod.cfg().getString(cfgKey, "");
        Mc.log("[スキン適用] " + cfgKey + " = '" + url + "'");
        return Npc.spawn(w, x, y, z, yaw, name, role, url, skinSource.getUUID(), Mc.name(skinSource));
    }

    public boolean isGateNpc(Entity e) { return "gate".equals(Npc.role(e)); }
}
