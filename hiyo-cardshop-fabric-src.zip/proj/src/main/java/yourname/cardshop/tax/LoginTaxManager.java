package yourname.cardshop.tax;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.bank.CentralBank;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Tasks;
import yourname.cardshop.util.Yml;

/** 非ログイン税: ログインしなかった日数ぶん、残高の rate を中央銀行へ納税(ログイン時にまとめて精算)。 */
public class LoginTaxManager {
    private final CardManager cardManager;
    private final CentralBank centralBank;
    private final Path file = CardShopMod.file("lastseen.txt");
    private final Object fileLock = new Object();
    private final Map<UUID, Long> lastSeenDay = new HashMap<>();
    private boolean dirty = false;
    private boolean savePending = false;

    public LoginTaxManager(CardManager cardManager, CentralBank centralBank) {
        this.cardManager = cardManager;
        this.centralBank = centralBank;
        load();
    }

    public void onJoin(ServerPlayer player) {
        UUID id = player.getUUID();
        long today = today();
        Long prev = lastSeenDay.put(id, today);
        if (prev == null || prev != today) markDirty();
        Yml cfg = CardShopMod.cfg();
        if (!cfg.getBoolean("login-tax.enabled", true)) return;
        if (prev == null) return;
        if (Mc.taxExempt(player)) return;
        if (!cardManager.hasAccount(id)) return;

        long days = today - prev - 1L;
        days -= Math.max(0, cfg.getInt("login-tax.grace-days", 0));
        int max = cfg.getInt("login-tax.max-days", 0);
        if (max > 0) days = Math.min(days, max);
        if (days <= 0L) return;
        double rate = Math.min(1.0, Math.max(0.0, cfg.getDouble("login-tax.rate", 0.003)));
        if (rate <= 0.0) return;
        double bal = cardManager.getBalance(id);
        if (bal <= 0.0) return;
        double after = cfg.getBoolean("login-tax.compound", true) ? bal * Math.pow(1.0 - rate, days) : bal * Math.max(0.0, 1.0 - rate * days);
        double min = Math.max(0.0, cfg.getDouble("login-tax.min-balance", 0.0));
        if (after < min) after = Math.min(bal, min);
        double tax = CardManager.round2(bal - after);
        if (tax <= 0.0) return;
        if (cardManager.removeBalance(id, tax)) {
            centralBank.absorb(tax);
            String sym = cfg.getString("currency-symbol", "円");
            Mc.msg(player, "§7" + days + "日間ログインしなかったため、非ログイン税として §c" + CardManager.formatMoney(tax) + sym + " §7が引き落とされました。(残高 "
                    + CardManager.formatMoney(bal) + " → " + CardManager.formatMoney(cardManager.getBalance(id)) + sym + ")");
            Mc.log("[非ログイン税] " + Mc.name(player) + " 未ログイン" + days + "日 -" + CardManager.formatMoney(tax) + sym);
        }
    }

    public void onQuit(ServerPlayer player) { touch(player.getUUID(), today()); }

    /** 5分ごとに、オンライン中のプレイヤーの「最終確認日」を更新(サーバーが落ちても税が誤計算されないように) */
    public void touchOnline() {
        long t = today();
        for (ServerPlayer p : Mc.online()) touch(p.getUUID(), t);
    }

    private void touch(UUID id, long day) {
        Long prev = lastSeenDay.put(id, day);
        if (prev == null || prev != day) markDirty();
    }

    private ZoneId zone;

    private long today() {
        if (zone == null) {
            try { zone = ZoneId.of(CardShopMod.cfg().getString("login-tax.timezone", "Asia/Tokyo")); }
            catch (DateTimeException e) { zone = ZoneId.systemDefault(); }
        }
        return LocalDate.now(zone).toEpochDay();
    }

    private void markDirty() {
        dirty = true;
        if (savePending || !CardShopMod.running()) return;
        savePending = true;
        Tasks.later(100, () -> {
            savePending = false;
            if (!dirty) return;
            dirty = false;
            Map<UUID, Long> copy = new HashMap<>(lastSeenDay); // メインではコピーだけ。文字列化と書き込みは別スレッド
            Tasks.async(() -> write(snapshot(copy)));
        });
    }

    private String snapshot(Map<UUID, Long> src) {
        StringBuilder sb = new StringBuilder(src.size() * 48);
        for (Map.Entry<UUID, Long> e : src.entrySet()) sb.append(e.getKey()).append(',').append(e.getValue()).append('\n');
        return sb.toString();
    }

    private void write(String s) {
        synchronized (fileLock) {
            try {
                Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
                Files.writeString(tmp, s, StandardCharsets.UTF_8);
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException e) { Mc.log("lastseen.txt の保存に失敗しました: " + e.getMessage()); }
        }
    }

    private void load() {
        if (!Files.exists(file)) return;
        try {
            List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
            for (String l : lines) {
                int i = l.indexOf(',');
                if (i < 0) continue;
                try { lastSeenDay.put(UUID.fromString(l.substring(0, i)), Long.parseLong(l.substring(i + 1).trim())); }
                catch (IllegalArgumentException ignored) { }
            }
        } catch (IOException e) { Mc.log("lastseen.txt の読み込みに失敗しました: " + e.getMessage()); }
    }

    public void saveNow() {
        long t = today();
        for (ServerPlayer p : Mc.online()) lastSeenDay.put(p.getUUID(), t);
        write(snapshot(lastSeenDay));
    }
}
