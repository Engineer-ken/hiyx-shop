package yourname.cardshop;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.function.Supplier;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.bank.CentralBank;
import yourname.cardshop.benefit.BenefitManager;
import yourname.cardshop.card.CardListener;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.cashback.CashbackNpcCommand;
import yourname.cardshop.cashback.CashbackNpcGui;
import yourname.cardshop.cashback.CashbackNpcManager;
import yourname.cardshop.casino.CasinoCommand;
import yourname.cardshop.casino.CasinoHttp;
import yourname.cardshop.casino.CasinoManager;
import yourname.cardshop.command.AdminCommand;
import yourname.cardshop.command.CardCommand;
import yourname.cardshop.command.PayCommand;
import yourname.cardshop.command.ShopCommand;
import yourname.cardshop.elytra.ElytraCommand;
import yourname.cardshop.elytra.ElytraListener;
import yourname.cardshop.elytra.ElytraManager;
import yourname.cardshop.entry.EntryNpcCommand;
import yourname.cardshop.entry.EntryNpcManager;
import yourname.cardshop.rail.CompanyCommand;
import yourname.cardshop.rail.CompanyIncomeManager;
import yourname.cardshop.rail.CompanyRegistry;
import yourname.cardshop.rail.GateListener;
import yourname.cardshop.rail.OwnerResolver;
import yourname.cardshop.rail.StationTracker;
import yourname.cardshop.rent.RentCommand;
import yourname.cardshop.rent.RentManager;
import yourname.cardshop.shop.ShopManager;
import yourname.cardshop.shopkeeper.ShopkeeperListener;
import yourname.cardshop.shopkeeper.ShopkeeperManager;
import yourname.cardshop.shopnpc.ShopNpcCommand;
import yourname.cardshop.shopnpc.ShopNpcGui;
import yourname.cardshop.shopnpc.ShopNpcManager;
import yourname.cardshop.tax.LoginTaxManager;
import yourname.cardshop.util.Cmd;
import yourname.cardshop.util.Cmds;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Npc;
import yourname.cardshop.util.Tasks;
import yourname.cardshop.util.Yml;

/** hiyo-plug (CardShopPlugin) の Fabric 版エントリポイント。元の onEnable/onDisable に相当。 */
public class CardShopMod implements ModInitializer {
    private static volatile Yml cfg = new Yml();
    private static Path dir;
    private static volatile boolean running = false;

    public static CardManager cards;
    public static ShopManager shops;
    public static ShopkeeperManager shopkeepers;
    public static CentralBank bank;
    public static RentManager rents;
    public static ElytraManager elytra;
    public static CompanyRegistry companies;
    public static StationTracker stations;
    public static ShopNpcManager shopNpcs;
    public static EntryNpcManager entries;
    public static CashbackNpcManager cashbacks;
    public static CompanyIncomeManager incomes;
    public static ShopNpcGui shopNpcGui;
    public static CashbackNpcGui cashbackGui;
    public static LoginTaxManager loginTax;
    public static BenefitManager benefit;
    public static CasinoManager casino;
    private static CasinoHttp http;
    private static ElytraListener elytraListener;

    public static Yml cfg() { return cfg; }
    public static Path dir() { return dir; }
    public static Path file(String name) { return dir.resolve(name); }
    public static boolean running() { return running; }

    public static void reloadConfig() {
        Yml y = Yml.load(file("config.yml"));
        try (InputStream in = CardShopMod.class.getResourceAsStream("/config.yml")) {
            if (in != null) {
                Path tmp = Files.createTempFile("cardshop-default", ".yml");
                Files.write(tmp, in.readAllBytes());
                y.mergeDefaults(Yml.load(tmp));
                Files.deleteIfExists(tmp);
            }
        } catch (IOException ignored) { }
        cfg = y;
    }

    private static void saveDefaultConfig() {
        Path f = file("config.yml");
        if (Files.exists(f)) return;
        try (InputStream in = CardShopMod.class.getResourceAsStream("/config.yml")) {
            if (in != null) Files.write(f, in.readAllBytes());
        } catch (IOException e) { System.err.println("[CardShop] config.yml の作成に失敗: " + e); }
    }

    private static Cmd lazy(Supplier<Cmd> s) {
        return new Cmd() {
            private Cmd c;
            private Cmd get() { if (c == null) c = s.get(); return c; }
            @Override public boolean run(yourname.cardshop.util.Sender se, String[] a) { return get().run(se, a); }
            @Override public List<String> tab(yourname.cardshop.util.Sender se, String[] a) { return get().tab(se, a); }
        };
    }

    @Override
    public void onInitialize() {
        dir = FabricLoader.getInstance().getConfigDir().resolve("cardshop");
        try { Files.createDirectories(dir); } catch (IOException e) { throw new RuntimeException(e); }
        saveDefaultConfig();
        reloadConfig();
        Tasks.init();
        if (Npc.ROLE == null) throw new IllegalStateException(); // NPCマーカー(Attachment)の登録を確実に実行

        // 駅の検出はチャンク読み込み前から必要なので最初に登録
        stations = new StationTracker();
        stations.register();

        CommandRegistrationCallback.EVENT.register((d, access, env) -> {
            Cmds.register(d, "card", "", false, lazy(() -> new CardCommand(cards, benefit)));
            Cmds.register(d, "pay", "/pay <プレイヤー名> <金額>", false, lazy(() -> new PayCommand(cards)));
            Cmds.register(d, "shop", "", false, lazy(() -> new ShopCommand(shops)));
            Cmds.register(d, "rent", "/rent <registerowner|setprice|setincome|addtenant|removetenant|info|history>", false, lazy(() -> new RentCommand(rents)));
            Cmds.register(d, "elytra", "", false, lazy(() -> new ElytraCommand(elytra)));
            Cmds.register(d, "shopnpc", "", false, lazy(() -> new ShopNpcCommand(shopNpcs)));
            Cmds.register(d, "company", "", false, lazy(() -> new CompanyCommand(companies)));
            Cmds.register(d, "entrynpc", "", false, lazy(() -> new EntryNpcCommand(entries)));
            Cmds.register(d, "cashbacknpc", "", false, lazy(() -> new CashbackNpcCommand(cashbacks, bank)));
            Cmds.register(d, "casino", "/casino <deposit <金額>|redeem|ticket|stats>", false, lazy(() -> new CasinoCommand(casino)));
            Cmds.register(d, "cardadmin", "/cardadmin <summary|balance|list|bank>", true, lazy(AdminCommand::new));
        });

        ServerLifecycleEvents.SERVER_STARTING.register(CardShopMod::enable);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> disable());
    }

    /** 元の onEnable に相当 */
    private static void enable(net.minecraft.server.MinecraftServer server) {
        Mc.setServer(server);
        running = true;
        cards = new CardManager();
        shops = new ShopManager(cards);
        shopkeepers = new ShopkeeperManager();
        bank = new CentralBank();
        rents = new RentManager(cards);
        elytra = new ElytraManager(cards, bank);
        companies = new CompanyRegistry();
        shopNpcs = new ShopNpcManager();
        entries = new EntryNpcManager();
        cashbacks = new CashbackNpcManager();
        incomes = new CompanyIncomeManager(companies, cards);
        shopNpcGui = new ShopNpcGui(shopNpcs, cards);
        cashbackGui = new CashbackNpcGui(cashbacks, cards, bank);
        elytraListener = new ElytraListener(elytra, cards);
        loginTax = new LoginTaxManager(cards, bank);
        benefit = new BenefitManager(cards, rents, bank);
        casino = new CasinoManager(cards, bank);

        // --- イベント(登録順 = 元のイベント優先度の順) ---
        ServerPlayConnectionEvents.JOIN.register((h, s, sv) -> loginTax.onJoin(h.getPlayer()));
        CardListener.register(cards);
        ShopkeeperListener.register();
        new GateListener(stations, companies, cards, shopkeepers, entries, incomes).register();
        ServerPlayConnectionEvents.JOIN.register((h, s, sv) -> {
            ServerPlayer p = h.getPlayer();
            OwnerResolver.remember(p);
            rents.chargeOnLogin(p);
            incomes.processLogin(p);
        });
        ServerPlayConnectionEvents.DISCONNECT.register((h, sv) -> {
            ServerPlayer p = h.getPlayer();
            incomes.recordLogout(p.getUUID());
            loginTax.onQuit(p);
            elytraListener.forget(p.getUUID());
            stations.forget(p.getUUID());
        });

        // --- 定期処理(軽量: 飛行中/乗車中のプレイヤーだけを見る) ---
        ServerTickEvents.END_SERVER_TICK.register(sv -> {
            stations.processPending();
            List<ServerPlayer> players = sv.getPlayerList().getPlayers();
            if (!players.isEmpty()) {
                for (ServerPlayer p : players) elytraListener.tick(p);
                stations.tickVehicles(players);
            }
        });
        long interval = Math.max(1L, cfg().getLong("integrity-check-interval-seconds", 300L)) * 20L;
        int ip = (int) Math.max(1L, interval / 10L);
        final int[] ib = {0};
        Tasks.timer(ip, ip, () -> {
            int bucket = ib[0]++ % 10;
            for (ServerPlayer p : Mc.players()) {
                if (Math.floorMod(p.getUUID().hashCode(), 10) != bucket) continue;
                cards.claimAnyForeignCards(p);
                cards.syncCardDisplay(p);
            }
        });
        Tasks.timer(6000, 6000, () -> loginTax.touchOnline());
        benefit.start();

        http = new CasinoHttp(casino);
        http.start();
        Mc.log("CardShop が有効化されました。(国からの給付金・物件収益の日次処理 / 非ログイン税 / カジノ)");
    }

    /** 元の onDisable に相当 */
    private static void disable() {
        running = false; // 以降の保存は同期で行う
        Tasks.shutdown(); // 先に、溜まっている非同期の書き込みを完了させる
        try {
            if (http != null) http.stop();
            if (casino != null) casino.saveNow();
            if (loginTax != null) loginTax.saveNow();
            if (benefit != null) benefit.saveNow();
            if (cards != null) cards.saveAll();
            if (shops != null) shops.saveAll();
            if (bank != null) bank.save();
            if (rents != null) rents.saveNow();
            if (shopNpcs != null) shopNpcs.saveNow();
            if (entries != null) entries.save();
            if (cashbacks != null) cashbacks.save();
            if (incomes != null) incomes.saveNow();
        } catch (Throwable t) { System.err.println("[CardShop] 終了時の保存でエラー: " + t); }
        Mc.log("CardShop が無効化されました。");
    }
}
