package yourname.cardshop.rent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.util.Cmd;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Sender;

public class RentCommand implements Cmd {
    private static final String NOT_OWNER = "§cその物件のオーナーではありません。";
    private static final String NO_PROPERTY = "§cその物件は存在しません。";
    private static final String PLAYER_ONLY = "§cプレイヤーのみ実行できます。";
    private static final String NOT_TENANT = "§cそのプレイヤーはこの物件のテナントではありません。先に /rent addtenant で追加してください。";
    private static final String BAD_AMOUNT = "§c金額は0以上の数値で指定してください。";

    private final RentManager rm;

    public RentCommand(RentManager rm) { this.rm = rm; }

    @Override
    public boolean run(Sender s, String[] a) {
        if (a.length == 0) { s.msg("§c使い方: /rent <registerowner|setprice|setincome|addtenant|removetenant|info|history> ..."); return true; }
        switch (a[0].toLowerCase()) {
            case "registerowner" -> {
                if (!s.admin()) { s.msg("§c権限がありません。"); return true; }
                if (a.length < 3) { s.msg("§c使い方: /rent registerowner <物件ID> <オーナー>"); return true; }
                UUID u = Mc.uuidOf(a[2]);
                if (u == null) { s.msg("§c" + a[2] + " が見つかりません。"); return true; }
                rm.registerOwner(a[1], u);
                s.msg("§a物件 " + a[1] + " のオーナーを " + a[2] + " に設定しました。");
            }
            case "setprice" -> setPrice(s, a);
            case "setincome" -> {
                if (!s.admin()) { s.msg("§c権限がありません。"); return true; }
                if (a.length < 3) { s.msg("§c使い方: /rent setincome <物件ID> <金額(1日あたり・0で無効)>"); return true; }
                Double d = parseAmount(a[2]);
                if (d == null) { s.msg(BAD_AMOUNT); return true; }
                if (rm.setVirtualIncome(a[1], d)) s.msg("§a物件 " + a[1] + " の仮想収益を 1日 " + CardManager.formatMoney(d) + "円 に設定しました(オーナーがその日最初にログインした時に付与)。");
                else s.msg(NO_PROPERTY);
            }
            case "addtenant" -> {
                if (!s.isPlayer()) { s.msg(PLAYER_ONLY); return true; }
                if (a.length < 3) { s.msg("§c使い方: /rent addtenant <物件ID> <テナント>"); return true; }
                UUID u = Mc.uuidOf(a[2]);
                if (u == null) { s.msg("§c" + a[2] + " が見つかりません。"); return true; }
                s.msg(rm.addTenant(a[1], s.uuid(), u) ? "§a" + a[2] + " をテナントに追加しました。" : NOT_OWNER);
            }
            case "removetenant" -> {
                if (!s.isPlayer()) { s.msg(PLAYER_ONLY); return true; }
                if (a.length < 3) { s.msg("§c使い方: /rent removetenant <物件ID> <テナント>"); return true; }
                UUID u = Mc.uuidOf(a[2]);
                if (u == null) { s.msg("§c" + a[2] + " が見つかりません。"); return true; }
                s.msg(rm.removeTenant(a[1], s.uuid(), u) ? "§a" + a[2] + " をテナントから外しました。" : NOT_OWNER);
            }
            case "info" -> info(s, a);
            case "history" -> history(s, a);
            default -> s.msg("§c不明なサブコマンドです。");
        }
        return true;
    }

    private void setPrice(Sender s, String[] a) {
        if (!s.isPlayer()) { s.msg(PLAYER_ONLY); return; }
        if (a.length < 3) {
            s.msg("§c使い方: /rent setprice <物件ID> <金額> [プレイヤー]");
            s.msg("§7  プレイヤーを付けるとそのテナントだけ個別の家賃になります。解除: /rent setprice <物件ID> reset <プレイヤー>");
            return;
        }
        String id = a[1];
        boolean reset = a[2].equalsIgnoreCase("reset") || a[2].equalsIgnoreCase("default");
        UUID me = s.uuid();
        if (a.length == 3) {
            if (reset) { s.msg("§c使い方: /rent setprice <物件ID> reset <プレイヤー>"); return; }
            Double d = parseAmount(a[2]);
            if (d == null) { s.msg(BAD_AMOUNT); return; }
            s.msg(rm.setPrice(id, me, d) ? "§a家賃を " + CardManager.formatMoney(d) + "円 に設定しました。" : NOT_OWNER);
            return;
        }
        RentProperty p = rm.get(id);
        if (p == null || !me.equals(p.getOwnerUuid())) { s.msg(NOT_OWNER); return; }
        UUID tenant = findTenant(p, a[3]);
        if (tenant == null) { s.msg(NOT_TENANT); return; }
        if (reset) {
            rm.clearTenantPrice(id, me, tenant);
            s.msg("§a" + a[3] + " の個別家賃を解除しました(標準家賃 " + CardManager.formatMoney(p.getPrice()) + "円 が適用されます)。");
            return;
        }
        Double d = parseAmount(a[2]);
        if (d == null) { s.msg(BAD_AMOUNT); return; }
        int r = rm.setTenantPrice(id, me, tenant, d);
        if (r == RentManager.OK) s.msg("§a" + a[3] + " の家賃を " + CardManager.formatMoney(d) + "円 に設定しました(個別設定)。");
        else s.msg(r == RentManager.NOT_TENANT ? NOT_TENANT : NOT_OWNER);
    }

    private void info(Sender s, String[] a) {
        if (a.length < 2) { s.msg("§c使い方: /rent info <物件ID>"); return; }
        RentProperty p = rm.get(a[1]);
        if (p == null) { s.msg(NO_PROPERTY); return; }
        boolean priv = s.admin() || (s.isPlayer() && s.uuid().equals(p.getOwnerUuid()));
        String tenants;
        if (p.getTenants().isEmpty()) tenants = "未設定";
        else {
            List<String> l = new ArrayList<>();
            for (UUID u : p.getTenants()) {
                String n = Mc.nameOf(u);
                if (priv && p.hasTenantPrice(u)) n += "(個別 " + CardManager.formatMoney(p.getPriceFor(u)) + "円)";
                l.add(n);
            }
            tenants = String.join(", ", l);
        }
        s.msg("§6[" + p.getId() + "] オーナー: " + Mc.nameOf(p.getOwnerUuid()) + " / テナント: " + tenants + " / 家賃: " + CardManager.formatMoney(p.getPrice()) + "円(標準・1人あたり)");
        if (s.isPlayer() && p.isTenant(s.uuid()) && !priv) s.msg("§7あなたの家賃: " + CardManager.formatMoney(p.getPriceFor(s.uuid())) + "円");
        if (priv && p.getVirtualIncome() > 0.0) s.msg("§7仮想収益: 1日 " + CardManager.formatMoney(p.getVirtualIncome()) + "円(オーナーがその日最初にログインした時に付与)");
    }

    private void history(Sender s, String[] a) {
        if (!s.isPlayer()) { s.msg(PLAYER_ONLY); return; }
        ServerPlayer pl = s.player();
        if (a.length < 2) { s.msg("§c使い方: /rent history <物件ID>"); return; }
        RentProperty p = rm.get(a[1]);
        if (p == null) { s.msg(NO_PROPERTY); return; }
        boolean owner = p.getOwnerUuid().equals(pl.getUUID());
        boolean tenant = p.isTenant(pl.getUUID());
        if (!owner && !tenant) { s.msg("§cこの物件のオーナーまたはテナントのみ履歴を確認できます。"); return; }
        s.msg("§6==== " + p.getId() + " の家賃履歴(直近) ====");
        int n = 0;
        for (RentProperty.PaymentRecord r : p.getHistory()) {
            if (!owner && !r.tenantUuid.equals(pl.getUUID())) continue;
            String res = r.success ? "§a成功" : "§c失敗(残高不足)";
            s.msg("§7" + r.dateTime + " §f" + Mc.nameOf(r.tenantUuid) + " §7- " + CardManager.formatMoney(r.amount) + "円 " + res);
            if (++n >= 20) break;
        }
        if (n == 0) s.msg("§7まだ引き落とし履歴がありません。");
    }

    @Override
    public List<String> tab(Sender s, String[] a) {
        boolean admin = s.admin();
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            List<String> subs = new ArrayList<>(List.of("setprice", "addtenant", "removetenant", "info", "history"));
            if (admin) { subs.add(0, "registerowner"); subs.add("setincome"); }
            addMatches(out, subs, a[0]);
        } else if (a.length == 2) {
            String sub = a[0].toLowerCase();
            if (List.of("registerowner", "setincome").contains(sub) && !admin) return out;
            if (List.of("registerowner", "setprice", "setincome", "addtenant", "removetenant", "info", "history").contains(sub))
                addMatches(out, rm.getAll().keySet(), a[1]);
        } else if (a.length == 3) {
            switch (a[0].toLowerCase()) {
                case "addtenant" -> addMatches(out, onlineNames(), a[2]);
                case "removetenant" -> addMatches(out, tenantNames(a[1]), a[2]);
                case "registerowner" -> { if (admin) addMatches(out, onlineNames(), a[2]); }
                case "setprice" -> addMatches(out, List.of("reset"), a[2]);
                default -> { }
            }
        } else if (a.length == 4 && a[0].equalsIgnoreCase("setprice")) addMatches(out, tenantNames(a[1]), a[3]);
        return out;
    }

    private static Double parseAmount(String s) {
        try {
            double d = Double.parseDouble(s);
            if (Double.isNaN(d) || Double.isInfinite(d) || d < 0.0) return null;
            return d;
        } catch (NumberFormatException e) { return null; }
    }
    private static UUID findTenant(RentProperty p, String name) {
        for (UUID u : p.getTenants()) if (Mc.nameOf(u).equalsIgnoreCase(name)) return u;
        return null;
    }
    private List<String> tenantNames(String id) {
        List<String> l = new ArrayList<>();
        RentProperty p = rm.get(id);
        if (p != null) for (UUID u : p.getTenants()) l.add(Mc.nameOf(u));
        return l;
    }
    private static List<String> onlineNames() {
        List<String> l = new ArrayList<>();
        for (ServerPlayer p : Mc.online()) l.add(Mc.name(p));
        return l;
    }
    private static void addMatches(List<String> out, Collection<String> c, String prefix) {
        String p = prefix.toLowerCase();
        for (String x : c) if (x.toLowerCase().startsWith(p)) out.add(x);
        Collections.sort(out);
    }
}
