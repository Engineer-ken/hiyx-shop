package yourname.cardshop.rent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class RentProperty {
    private final String id;
    private UUID ownerUuid;
    private double price;
    private double virtualIncome;
    private String lastIncomeDate = "";
    private final Set<UUID> tenants = new HashSet<>();
    private final Map<UUID, Double> tenantPrices = new HashMap<>();
    private final Map<UUID, String> lastChargedDate = new HashMap<>();
    private final List<PaymentRecord> history = new ArrayList<>();
    private int mod = 0;
    private int snapMod = -1;
    private java.util.Map<String, Object> snap;

    /** 保存用の中身。変更が無ければ前回作ったものを使い回す(参加のたびに全物件を作り直さないため)。作った後は書き換えない */
    public java.util.Map<String, Object> snapshot() {
        if (snap != null && snapMod == mod) return snap;
        java.util.Map<String, Object> m = new java.util.LinkedHashMap<>();
        m.put("owner", ownerUuid.toString());
        m.put("price", price);
        m.put("income", virtualIncome);
        m.put("last-income", lastIncomeDate);
        List<String> ts = new ArrayList<>();
        for (UUID u : tenants) ts.add(u.toString());
        m.put("tenants", ts);
        if (!tenantPrices.isEmpty()) {
            java.util.Map<String, Object> tp = new java.util.LinkedHashMap<>();
            for (java.util.Map.Entry<UUID, Double> e : tenantPrices.entrySet()) tp.put(e.getKey().toString(), e.getValue());
            m.put("tenant-prices", tp);
        }
        if (!tenants.isEmpty()) {
            java.util.Map<String, Object> lc = new java.util.LinkedHashMap<>();
            for (UUID u : tenants) lc.put(u.toString(), lastChargedDate.getOrDefault(u, ""));
            m.put("last-charged", lc);
        }
        List<String> hs = new ArrayList<>();
        for (PaymentRecord r : history) hs.add(r.dateTime + "|" + r.tenantUuid + "|" + r.amount + "|" + r.success);
        m.put("history", hs);
        snap = m;
        snapMod = mod;
        return m;
    }

    public RentProperty(String id, UUID ownerUuid, double price) { this.id = id; this.ownerUuid = ownerUuid; this.price = price; }

    public String getId() { return id; }
    public UUID getOwnerUuid() { return ownerUuid; }
    public void setOwnerUuid(UUID u) { ownerUuid = u; mod++; }
    public double getPrice() { return price; }
    public void setPrice(double d) { price = d; mod++; }
    public double getPriceFor(UUID u) { Double d = tenantPrices.get(u); return d != null ? d : price; }
    public boolean hasTenantPrice(UUID u) { return tenantPrices.containsKey(u); }
    public void setTenantPrice(UUID u, double d) { tenantPrices.put(u, d); mod++; }
    public void clearTenantPrice(UUID u) { tenantPrices.remove(u); mod++; }
    public Map<UUID, Double> getTenantPrices() { return Collections.unmodifiableMap(tenantPrices); }
    public double getVirtualIncome() { return virtualIncome; }
    public void setVirtualIncome(double d) { virtualIncome = d; mod++; }
    public String getLastIncomeDate() { return lastIncomeDate; }
    public void setLastIncomeDate(String s) { lastIncomeDate = s == null ? "" : s; mod++; }
    public Set<UUID> getTenants() { return tenants; }
    public void addTenant(UUID u) { tenants.add(u); mod++; }
    public void removeTenant(UUID u) { tenants.remove(u); lastChargedDate.remove(u); tenantPrices.remove(u); mod++; }
    public boolean isTenant(UUID u) { return tenants.contains(u); }
    public String getLastChargedDate(UUID u) { return lastChargedDate.getOrDefault(u, ""); }
    public void setLastChargedDate(UUID u, String s) { lastChargedDate.put(u, s); mod++; }
    public List<PaymentRecord> getHistory() { return history; }
    public void addHistory(PaymentRecord r) {
        mod++;
        history.add(0, r);
        while (history.size() > 50) history.remove(history.size() - 1);
    }

    public static class PaymentRecord {
        public final String dateTime;
        public final UUID tenantUuid;
        public final double amount;
        public final boolean success;
        public PaymentRecord(String dateTime, UUID tenantUuid, double amount, boolean success) {
            this.dateTime = dateTime; this.tenantUuid = tenantUuid; this.amount = amount; this.success = success;
        }
    }
}
