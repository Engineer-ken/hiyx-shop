package yourname.cardshop.rent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class RentProperty {
    private final String id;
    private UUID ownerUuid;
    private double price;
    private double virtualIncome;
    private String lastIncomeDate = "";
    private final Set<UUID> tenants = new HashSet<>();
    private final Map<UUID, Double> tenantPrices = new HashMap<>();
    private final Map<UUID, String> lastChargedDate = new HashMap<>();
    private final List<PaymentRecord> history = new ArrayList<>();

    public RentProperty(String id, UUID ownerUuid, double price) { this.id = id; this.ownerUuid = ownerUuid; this.price = price; }

    public String getId() { return id; }
    public UUID getOwnerUuid() { return ownerUuid; }
    public void setOwnerUuid(UUID u) { ownerUuid = u; }
    public double getPrice() { return price; }
    public void setPrice(double d) { price = d; }
    public double getPriceFor(UUID u) { Double d = tenantPrices.get(u); return d != null ? d : price; }
    public boolean hasTenantPrice(UUID u) { return tenantPrices.containsKey(u); }
    public void setTenantPrice(UUID u, double d) { tenantPrices.put(u, d); }
    public void clearTenantPrice(UUID u) { tenantPrices.remove(u); }
    public Map<UUID, Double> getTenantPrices() { return Collections.unmodifiableMap(tenantPrices); }
    public double getVirtualIncome() { return virtualIncome; }
    public void setVirtualIncome(double d) { virtualIncome = d; }
    public String getLastIncomeDate() { return lastIncomeDate; }
    public void setLastIncomeDate(String s) { lastIncomeDate = s == null ? "" : s; }
    public Set<UUID> getTenants() { return tenants; }
    public void addTenant(UUID u) { tenants.add(u); }
    public void removeTenant(UUID u) { tenants.remove(u); lastChargedDate.remove(u); tenantPrices.remove(u); }
    public boolean isTenant(UUID u) { return tenants.contains(u); }
    public String getLastChargedDate(UUID u) { return lastChargedDate.getOrDefault(u, ""); }
    public void setLastChargedDate(UUID u, String s) { lastChargedDate.put(u, s); }
    public List<PaymentRecord> getHistory() { return history; }
    public void addHistory(PaymentRecord r) {
        history.add(0, r);
        while (history.size() > 50) history.remove(history.size() - 1);
    }

    public static class PaymentRecord {
        public final String dateTime;
        public final UUID tenantUuid;
        public final double amount;
        public final boolean success;
        public PaymentRecord(String dateTime, UUID tenantUuid, double amount, boolean success) {
            this.dateTime = dateTime; this.tenantUuid = tenantUuid; this.amount = amount; this.success = success;
        }
    }
}
