package yourname.cardshop.rent;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.ToDoubleFunction;
import net.minecraft.server.level.ServerPlayer;
import yourname.cardshop.CardShopMod;
import yourname.cardshop.card.CardManager;
import yourname.cardshop.util.Mc;
import yourname.cardshop.util.Tasks;
import yourname.cardshop.util.Yml;

public class RentManager {
    public static final int OK = 0;
    public static final int NOT_OWNER = 1;
    public static final int NOT_TENANT = 2;
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private final CardManager cardManager;
    private final Map<String, RentProperty> properties = new HashMap<>();
    private final Map<UUID, String> checkedDay = new HashMap<>();
    private boolean savePending = false;
    private ZoneId zoneCache;

    public RentManager(CardManager cardManager) { this.cardManager = cardManager; load(); }

    public RentProperty registerOwner(String id, UUID owner) {
        RentProperty p = properties.get(id);
        if (p == null) { p = new RentProperty(id, owner, 0.0); properties.put(id, p); }
        else p.setOwnerUuid(owner);
        checkedDay.remove(owner);
        save();
        return p;
    }
    public boolean setPrice(String id, UUID requester, double price) {
        RentProperty p = properties.get(id);
        if (p == null || !requester.equals(p.getOwnerUuid())) return false;
        p.setPrice(CardManager.round2(price));
        save();
        return true;
    }
    public int setTenantPrice(String id, UUID requester, UUID tenant, double price) {
        RentProperty p = properties.get(id);
        if (p == null || !requester.equals(p.getOwnerUuid())) return NOT_OWNER;
        if (!p.isTenant(tenant)) return NOT_TENANT;
        p.setTenantPrice(tenant, CardManager.round2(price));
        save();
        return OK;
    }
    public int clearTenantPrice(String id, UUID requester, UUID tenant) {
        RentProperty p = properties.get(id);
        if (p == null || !requester.equals(p.getOwnerUuid())) return NOT_OWNER;
        if (!p.isTenant(tenant)) return NOT_TENANT;
        p.clearTenantPrice(tenant);
        save();
        return OK;
    }
    public boolean setVirtualIncome(String id, double income) {
        RentProperty p = properties.get(id);
        if (p == null) return false;
        p.setVirtualIncome(CardManager.round2(income));
        if (p.getOwnerUuid() != null) checkedDay.remove(p.getOwnerUuid());
        save();
        return true;
    }
    public boolean addTenant(String id, UUID requester, UUID tenant) {
        RentProperty p = properties.get(id);
        if (p == null || !requester.equals(p.getOwnerUuid())) return false;
        p.addTenant(tenant);
        checkedDay.remove(tenant);
        save();
        return true;
    }
    public boolean removeTenant(String id, UUID requester, UUID tenant) {
        RentProperty p = properties.get(id);
        if (p == null || !requester.equals(p.getOwnerUuid())) return false;
        p.removeTenant(tenant);
        save();
        return true;
    }
    public RentProperty get(String id) { return properties.get(id); }
    public Map<String, RentProperty> getAll() { return properties; }

    private LocalDate today() {
        if (zoneCache == null) {
            try { zoneCache = ZoneId.of(CardShopMod.cfg().getString("login-tax.timezone", "Asia/Tokyo")); }
            catch (Exception e) { zoneCache = ZoneId.systemDefault(); }
        }
        return LocalDate.now(zoneCache);
    }
    private double onlineMultiplier() {
        double d = CardShopMod.cfg().getDouble("rent.online-income-multiplier", 2.0);
        return d > 0.0 ? d : 1.0;
    }

    public void collectIncomeOwners(Set<UUID> out) {
        for (RentProperty p : properties.values())
            if (p.getOwnerUuid() != null && p.getVirtualIncome() > 0.0) out.add(p.getOwnerUuid());
    }

    /** 毎日0時: 物件の仮想収益をオーナーへ(オンライン時間に応じて倍率) */
    public void payDailyIncome(ToDoubleFunction<UUID> onlineFraction) {
        String today = today().toString();
        List<RentProperty> due = new ArrayList<>();
        for (RentProperty p : properties.values()) {
            if (p.getOwnerUuid() == null || !(p.getVirtualIncome() > 0.0) || today.equals(p.getLastIncomeDate())) continue;
            due.add(p);
        }
        if (due.isEmpty()) return;
        incomeBatch(due, 0, today, onlineMultiplier() - 1.0, onlineFraction, new double[2]);
    }

    private void incomeBatch(List<RentProperty> list, int from, String today, double bonus, ToDoubleFunction<UUID> frac, double[] stats) {
        int to = Math.min(from + 25, list.size());
        for (int i = from; i < to; i++) {
            RentProperty p = list.get(i);
            UUID owner = p.getOwnerUuid();
            if (owner == null || today.equals(p.getLastIncomeDate())) continue;
            double f = Math.max(0.0, Math.min(1.0, frac.applyAsDouble(owner)));
            double amount = CardManager.round2(p.getVirtualIncome() * (1.0 + bonus * f));
            boolean ok = cardManager.addBalance(owner, amount);
            p.setLastIncomeDate(today);
            if (ok) { stats[0] += 1.0; stats[1] += amount; }
            ServerPlayer pl = Mc.player(owner);
            if (pl == null) continue;
            if (ok) {
                long min = Math.round(f * 1440.0);
                Mc.msg(pl, "§6[物件収益] §f" + p.getId() + " §7の仮想収益 §a" + CardManager.formatMoney(amount) + "円 §7が振り込まれました。(オンライン時間 "
                        + min / 60L + "時間" + min % 60L + "分を" + (double) Math.round((1.0 + bonus) * 10.0) / 10.0 + "倍で換算)");
            } else Mc.msg(pl, "§6[物件収益] §f" + p.getId() + " §7の仮想収益が発生しましたが、残高上限のため振り込めませんでした。");
        }
        if (to < list.size()) { Tasks.later(1, () -> incomeBatch(list, to, today, bonus, frac, stats)); return; }
        save();
        Mc.log("[rent-income] " + (int) stats[0] + " properties, total " + CardManager.formatMoney(stats[1]));
    }

    /** ログイン時: 家賃の引き落とし + (日次処理が未実行なら)物件収益の振込 */
    public void chargeOnLogin(ServerPlayer player) {
        UUID id = player.getUUID();
        String today = today().toString();
        if (today.equals(checkedDay.get(id))) return;
        checkedDay.put(id, today);
        String stamp = null;
        boolean changed = false;
        double incomeOk = 0.0, incomeCap = 0.0;
        StringBuilder okIds = new StringBuilder(), capIds = new StringBuilder();
        for (RentProperty p : properties.values()) {
            if (p.isTenant(id) && !today.equals(p.getLastChargedDate(id))) {
                double rent = p.getPriceFor(id);
                if (rent > 0.0) {
                    if (stamp == null) stamp = LocalDateTime.now().format(TIME_FORMAT);
                    boolean paid = cardManager.removeBalance(id, rent);
                    p.addHistory(new RentProperty.PaymentRecord(stamp, id, rent, paid));
                    if (paid) {
                        cardManager.addBalance(p.getOwnerUuid(), rent);
                        Mc.msg(player, "§7家賃 " + CardManager.formatMoney(rent) + "円 が引き落とされました(" + p.getId() + ")。");
                    } else Mc.msg(player, "§c家賃(" + p.getId() + ")の残高が不足しています。");
                    p.setLastChargedDate(id, today);
                    changed = true;
                }
            }
            if (!id.equals(p.getOwnerUuid()) || !(p.getVirtualIncome() > 0.0) || today.equals(p.getLastIncomeDate())) continue;
            double inc = p.getVirtualIncome();
            if (cardManager.addBalance(id, inc)) {
                incomeOk += inc;
                if (okIds.length() > 0) okIds.append(", ");
                okIds.append(p.getId());
            } else {
                incomeCap += inc;
                if (capIds.length() > 0) capIds.append(", ");
                capIds.append(p.getId());
            }
            p.setLastIncomeDate(today);
            changed = true;
        }
        if (incomeOk > 0.0) {
            Mc.msg(player, "§6[物件収益] §f" + okIds + " §7の仮想収益 合計 §a" + CardManager.formatMoney(incomeOk) + "円 §7が振り込まれました。");
            Mc.log("[物件収益] " + Mc.name(player) + " ← " + okIds + " 合計=" + CardManager.formatMoney(incomeOk) + "円");
        }
        if (incomeCap > 0.0) Mc.msg(player, "§6[物件収益] §f" + capIds + " §7の仮想収益(合計 " + CardManager.formatMoney(incomeCap) + "円)が発生しましたが、残高上限のため振り込めませんでした。");
        if (changed) save();
    }

    private void load() {
        Yml y = Yml.load(CardShopMod.file("rent.yml"));
        for (String key : y.keys()) {
            try {
                UUID owner = UUID.fromString(y.getString(key + ".owner"));
                RentProperty p = new RentProperty(key, owner, y.getDouble(key + ".price"));
                p.setVirtualIncome(y.getDouble(key + ".income"));
                p.setLastIncomeDate(y.getString(key + ".last-income"));
                for (String t : y.getStringList(key + ".tenants")) p.addTenant(UUID.fromString(t));
                Yml tp = y.section(key + ".tenant-prices");
                if (tp != null) for (String k : tp.keys()) {
                    UUID u = UUID.fromString(k);
                    if (p.isTenant(u)) p.setTenantPrice(u, y.getDouble(key + ".tenant-prices." + k));
                }
                Yml lc = y.section(key + ".last-charged");
                if (lc != null) for (String k : lc.keys()) p.setLastChargedDate(UUID.fromString(k), y.getString(key + ".last-charged." + k));
                for (String h : y.getStringList(key + ".history")) {
                    String[] a = h.split("\\|");
                    if (a.length < 4) continue;
                    p.getHistory().add(new RentProperty.PaymentRecord(a[0], UUID.fromString(a[1]), Double.parseDouble(a[2]), Boolean.parseBoolean(a[3])));
                }
                properties.put(key, p);
            } catch (Exception e) { Mc.log("rent.yml 読み込みエラー(" + key + "): " + e.getMessage()); }
        }
    }

    public void save() {
        if (!CardShopMod.running()) { saveNow(); return; }
        if (savePending) return;
        savePending = true;
        Tasks.later(100, () -> { savePending = false; saveNow(); });
    }

    public void saveNow() {
        Yml y = new Yml();
        for (RentProperty p : properties.values()) y.set(p.getId(), p.snapshot());
        y.saveAuto(CardShopMod.file("rent.yml"));
    }
}
